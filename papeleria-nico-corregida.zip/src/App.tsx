import React, { useState } from 'react';
import {
  INITIAL_PRODUCTS,
  INITIAL_KITS,
  INITIAL_SALES,
  INITIAL_MOVEMENTS,
  INITIAL_ADMINS,
  INITIAL_CATEGORIES,
  Product,
  Kit,
  Sale,
  InventoryMovement,
  AdminUser,
  Category,
  SaleItem,
  validateCartStock,
  calculateRequiredProductQuantities,
  getBogotaToday
} from './data/mockData';

import { PublicCatalog } from './components/PublicCatalog';
import { AdminAuth } from './components/AdminAuth';
import { AdminLayout, AdminView } from './components/AdminLayout';
import { AdminHome } from './components/AdminHome';
import { AdminProducts } from './components/AdminProducts';
import { AdminInventory } from './components/AdminInventory';
import { AdminPos } from './components/AdminPos';
import { AdminReports } from './components/AdminReports';
import { AdminKits } from './components/AdminKits';
import { AdminAccount } from './components/AdminAccount';

type AppScreen = 'catalogo' | 'login' | 'admin';

export default function App() {
  // Navigation State
  const [currentScreen, setCurrentScreen] = useState<AppScreen>('catalogo');
  const [adminView, setAdminView] = useState<AdminView>('inicio');
  const [selectedSaleDetailId, setSelectedSaleDetailId] = useState<string | undefined>(undefined);
  const [inventoryStatusFilter, setInventoryStatusFilter] = useState<string | undefined>(undefined);
  const [inventorySearch, setInventorySearch] = useState<string | undefined>(undefined);
  const [inventoryNavigationKey, setInventoryNavigationKey] = useState(0);

  // Shared coherent database-like state
  const [products, setProducts] = useState<Product[]>(INITIAL_PRODUCTS);
  const [kits, setKits] = useState<Kit[]>(INITIAL_KITS);
  const [sales, setSales] = useState<Sale[]>(INITIAL_SALES);
  const [movements, setMovements] = useState<InventoryMovement[]>(INITIAL_MOVEMENTS);
  const [admins, setAdmins] = useState<AdminUser[]>(INITIAL_ADMINS);
  const [categories, setCategories] = useState<Category[]>(INITIAL_CATEGORIES);

  // ================= Handlers =================

  // Reabrir Inventario limpia también sus filtros locales y su paginación.
  const handleNavigateToInventory = (productCode?: string) => {
    setSelectedSaleDetailId(undefined);
    setInventoryStatusFilter(undefined);
    setInventorySearch(productCode || '');
    setInventoryNavigationKey((previous) => previous + 1);
    setAdminView('inventario');
  };

  // Navegar a Login
  const handleOpenLogin = () => {
    setCurrentScreen('login');
  };

  // Login exitoso -> Inicio administrativo
  const handleLoginSuccess = () => {
    setCurrentScreen('admin');
    setAdminView('inicio');
  };

  // Regresar al catálogo público
  const handleGoToCatalog = () => {
    setCurrentScreen('catalogo');
  };

  // Cerrar sesión
  const handleLogout = () => {
    setCurrentScreen('catalogo');
  };

  // Registrar venta completada desde POS (validación atómica de existencias y registro de movimientos)
  const handleCompleteSale = (saleData: {
    items: SaleItem[];
    subtotal: number;
    total: number;
    channel: string;
  }): { success: boolean; error?: string } => {
    // 1. Validación estricta previa
    const validation = validateCartStock(saleData.items, products, kits);
    if (!validation.isValid) {
      const err = validation.errors[0];
      return {
        success: false,
        error: `Venta bloqueada: ${err.name} requiere ${err.required} unids., disponible: ${err.available} unids.`
      };
    }

    // 2. Agrupación total de cantidades requeridas por identificador de producto
    const requiredMap = calculateRequiredProductQuantities(saleData.items, kits);

    // 3. Verificación de existencias suficientes para cada producto agrupado
    for (const [code, req] of requiredMap.entries()) {
      const targetProd = products.find((p) => p.code === code);
      const available = targetProd ? targetProd.stock : 0;
      if (req.requiredQty > available) {
        return {
          success: false,
          error: `Venta bloqueada: ${targetProd ? targetProd.name : code} requiere ${req.requiredQty} unids., pero solo hay ${available} disponibles.`
        };
      }
    }

    // 4. Crear venta oficial
    const newSaleId = `#V-${1049 + sales.length}`;
    const { dateString, timeString } = getBogotaToday();

    const newSale: Sale = {
      id: newSaleId,
      date: dateString,
      time: timeString,
      channel: saleData.channel,
      items: saleData.items,
      subtotal: saleData.subtotal,
      total: saleData.total,
      responsible: 'Carlos M. (Administrador)',
      location: 'Torreón El Roble, Ibagué'
    };

    // 5. Descontar cada producto exactamente una vez por la cantidad total requerida (sin stock negativo)
    setProducts((prevProducts) => {
      return prevProducts.map((p) => {
        const req = requiredMap.get(p.code);
        if (!req) return p;
        const remaining = p.stock - req.requiredQty;
        return {
          ...p,
          stock: Math.max(0, remaining)
        };
      });
    });

    // 6. Registrar movimientos detallados correspondientes
    const newMovements: InventoryMovement[] = [];
    let idx = 0;

    saleData.items.forEach((item) => {
      if (item.isKit) {
        const kit = kits.find((k) => k.id === item.code || k.name === item.name);
        if (kit) {
          kit.components.forEach((comp) => {
            newMovements.push({
              id: `MOV-${Date.now().toString().slice(-4)}-${idx++}`,
              dateTime: `${dateString}, ${timeString}`,
              productCode: comp.productCode,
              productName: comp.name,
              type: 'salida_kit',
              typeLabel: 'Salida Kit Escolar',
              quantity: -(comp.quantity * item.quantity),
              reference: `Kit ${item.name} • Descuento vinculado a Venta ${newSaleId}`,
              responsible: 'Carlos M.'
            });
          });
        }
      } else {
        newMovements.push({
          id: `MOV-${Date.now().toString().slice(-4)}-${idx++}`,
          dateTime: `${dateString}, ${timeString}`,
          productCode: item.code,
          productName: item.name,
          type: 'salida_venta',
          typeLabel: 'Salida por venta',
          quantity: -item.quantity,
          reference: `Venta mostrador ${newSaleId}`,
          responsible: 'Carlos M.'
        });
      }
    });

    setSales((prev) => [newSale, ...prev]);
    setMovements((prev) => [...newMovements, ...prev]);

    return { success: true };
  };

  // Agregar stock (Entrada de mercancía)
  const handleAddStock = (productCode: string, quantity: number, reference: string) => {
    setProducts((prev) =>
      prev.map((p) => (p.code === productCode ? { ...p, stock: p.stock + quantity } : p))
    );

    const targetProd = products.find((p) => p.code === productCode);
    const { dateString, timeString } = getBogotaToday();

    const newMov: InventoryMovement = {
      id: `MOV-${Date.now().toString().slice(-4)}`,
      dateTime: `${dateString}, ${timeString}`,
      productCode,
      productName: targetProd ? targetProd.name : productCode,
      type: 'entrada',
      typeLabel: 'Entrada por compra',
      quantity,
      reference,
      responsible: 'Carlos M.'
    };

    setMovements((prev) => [newMov, ...prev]);
  };

  // Ajustar existencias (Merma o Conteo físico)
  const handleAdjustStock = (productCode: string, newStock: number, reason: string) => {
    const targetProd = products.find((p) => p.code === productCode);
    const prevStock = targetProd ? targetProd.stock : 0;
    const diff = newStock - prevStock;

    setProducts((prev) =>
      prev.map((p) => (p.code === productCode ? { ...p, stock: newStock } : p))
    );

    const { dateString, timeString } = getBogotaToday();

    const newMov: InventoryMovement = {
      id: `MOV-${Date.now().toString().slice(-4)}`,
      dateTime: `${dateString}, ${timeString}`,
      productCode,
      productName: targetProd ? targetProd.name : productCode,
      type: diff < 0 ? 'ajuste_merma' : 'entrada',
      typeLabel: diff < 0 ? 'Ajuste por merma' : 'Corrección conteo físico',
      quantity: diff,
      reference: reason,
      responsible: 'Carlos M.'
    };

    setMovements((prev) => [newMov, ...prev]);
  };

  // Gestión de productos
  const handleAddProduct = (newProd: Product) => {
    setProducts((prev) => [newProd, ...prev]);
  };

  const handleUpdateProduct = (updatedProd: Product) => {
    setProducts((prev) =>
      prev.map((p) => (p.code === updatedProd.code ? updatedProd : p))
    );
  };

  const handleDeleteProduct = (code: string) => {
    setProducts((prev) => prev.filter((p) => p.code !== code));
  };

  // Gestión de categorías
  const handleAddCategory = (newCat: Category) => {
    setCategories((prev) => [...prev, newCat]);
  };

  const handleDeleteCategory = (catName: string) => {
    setCategories((prev) => prev.filter((c) => c.name !== catName));
  };

  // Gestión de Kits
  const handleAddKit = (newKit: Kit) => {
    setKits((prev) => [...prev, newKit]);
  };

  const handleUpdateKit = (updatedKit: Kit) => {
    setKits((prev) =>
      prev.map((k) => (k.id === updatedKit.id ? updatedKit : k))
    );
  };

  // Gestión de administradores
  const handleAddAdmin = (newAdmin: AdminUser) => {
    setAdmins((prev) => [...prev, newAdmin]);
  };

  // ================= Renderizado de Pantallas =================

  // 1. PANTALLA INICIAL: Catálogo Público
  if (currentScreen === 'catalogo') {
    return (
      <PublicCatalog
        products={products}
        kits={kits}
        categories={categories}
        onOpenAdminAuth={handleOpenLogin}
      />
    );
  }

  // 2. PANTALLA: Acceso Administrativo y Recuperación de Contraseña
  if (currentScreen === 'login') {
    return (
      <AdminAuth
        onLoginSuccess={handleLoginSuccess}
        onBackToCatalog={handleGoToCatalog}
      />
    );
  }

  // 3-9. PANTALLAS ADMINISTRATIVAS CON SIDEBAR COMPARTIDA
  return (
    <AdminLayout
      currentView={adminView}
      onNavigate={(view) => {
        if (view === 'inventario') {
          handleNavigateToInventory();
          return;
        }
        setSelectedSaleDetailId(undefined);
        setInventoryStatusFilter(undefined);
        setInventorySearch(undefined);
        setAdminView(view);
      }}
      onGoToCatalog={handleGoToCatalog}
      onLogout={handleLogout}
    >
      {/* 3. Inicio Administrativo */}
      {adminView === 'inicio' && (
        <AdminHome
          products={products}
          sales={sales}
          onNavigate={(view, filter) => {
            if (view === 'inventario' && filter) {
              if (['Disponible', 'Stock bajo', 'Agotado'].includes(filter)) {
                setInventoryStatusFilter(filter);
                setInventorySearch(undefined);
              } else {
                setInventorySearch(filter);
                setInventoryStatusFilter(undefined);
              }
            } else {
              setInventoryStatusFilter(undefined);
              setInventorySearch(undefined);
            }
            setAdminView(view);
          }}
          onSelectSaleDetail={(saleId) => {
            setSelectedSaleDetailId(saleId);
            setAdminView('reportes');
          }}
        />
      )}

      {/* 4. Productos y categorías */}
      {adminView === 'productos' && (
        <AdminProducts
          products={products}
          categories={categories}
          onAddProduct={handleAddProduct}
          onUpdateProduct={handleUpdateProduct}
          onDeleteProduct={handleDeleteProduct}
          onAddCategory={handleAddCategory}
          onDeleteCategory={handleDeleteCategory}
          onNavigateToInventory={handleNavigateToInventory}
        />
      )}

      {/* 5. Inventario */}
      {adminView === 'inventario' && (
        <AdminInventory
          key={inventoryNavigationKey}
          products={products}
          movements={movements}
          categories={categories}
          initialStatusFilter={inventoryStatusFilter}
          initialSearch={inventorySearch}
          onAddStock={handleAddStock}
          onAdjustStock={handleAdjustStock}
        />
      )}

      {/* 6. Registrar venta */}
      {adminView === 'ventas' && (
        <AdminPos
          products={products}
          kits={kits}
          categories={categories}
          onCompleteSale={handleCompleteSale}
          onGoToReports={() => setAdminView('reportes')}
        />
      )}

      {/* 7. Historial y reportes */}
      {adminView === 'reportes' && (
        <AdminReports
          sales={sales}
          products={products}
          kits={kits}
          selectedSaleId={selectedSaleDetailId}
        />
      )}

      {/* 8. Kits */}
      {adminView === 'kits' && (
        <AdminKits
          kits={kits}
          products={products}
          onUpdateKit={handleUpdateKit}
          onAddKit={handleAddKit}
        />
      )}

      {/* 9. Administradores y cuenta */}
      {adminView === 'cuenta' && (
        <AdminAccount
          admins={admins}
          onAddAdmin={handleAddAdmin}
        />
      )}
    </AdminLayout>
  );
}
