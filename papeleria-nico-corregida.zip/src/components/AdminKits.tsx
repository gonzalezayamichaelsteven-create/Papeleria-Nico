import React, { useState } from 'react';
import { Kit, Product, KitComponent, formatCOP } from '../data/mockData';

interface AdminKitsProps {
  kits: Kit[];
  products: Product[];
  onUpdateKit: (kit: Kit) => void;
  onAddKit: (kit: Kit) => void;
}

export const AdminKits: React.FC<AdminKitsProps> = ({
  kits,
  products,
  onUpdateKit,
  onAddKit
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'publicado' | 'oculto'>('all');

  // Drawer / Modal state
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [editingKitId, setEditingKitId] = useState<string | null>(null);

  // Form state for Kit
  const [kitName, setKitName] = useState('');
  const [kitDesc, setKitDesc] = useState('');
  const [kitAge, setKitAge] = useState('');
  const [kitImage, setKitImage] = useState('');
  const [kitStatus, setKitStatus] = useState<'publicado' | 'oculto'>('publicado');
  const [kitComponents, setKitComponents] = useState<KitComponent[]>([]);

  // Search product to add to kit
  const [addProdSearch, setAddProdSearch] = useState('');

  const filteredKits = kits.filter((k) => {
    const q = searchQuery.toLowerCase().trim();
    const matchSearch = q === '' || k.name.toLowerCase().includes(q) || k.description.toLowerCase().includes(q);
    const matchStatus = statusFilter === 'all' || k.status === statusFilter;
    return matchSearch && matchStatus;
  });

  const getKitCalculatedPrice = (k: Kit | { components: KitComponent[] }) => {
    return k.components.reduce((acc, c) => {
      const prod = products.find((p) => p.code === c.productCode);
      const unitPrice = prod ? prod.price : c.unitPrice;
      return acc + unitPrice * c.quantity;
    }, 0);
  };

  const getKitBottleneck = (k: Kit | { components: KitComponent[] }): { count: number; limitingComponent: KitComponent | null } => {
    if (k.components.length === 0) return { count: 0, limitingComponent: null };
    let minKits = Infinity;
    let limitingComp: KitComponent | null = null;

    k.components.forEach((c) => {
      const prod = products.find((p) => p.code === c.productCode);
      const stock = prod ? prod.stock : 0;
      const possible = Math.floor(stock / c.quantity);
      if (possible < minKits) {
        minKits = possible;
        limitingComp = c;
      }
    });

    return {
      count: minKits === Infinity ? 0 : minKits,
      limitingComponent: limitingComp
    };
  };

  const openCreateDrawer = () => {
    setEditingKitId(null);
    setKitName('');
    setKitDesc('');
    setKitAge('6 a 12 años');
    setKitImage('https://lh3.googleusercontent.com/aida-public/AB6AXuAC99Wh6tPRAau69CyQlvV9QDUe7IxMxGVwTBreJFnf1bcEKO-r38WimN2qqBjgRQAd5wXFTc7Qq_9BXBmQ4hre5mt9ufzugrdmr1L9WPtieRiQ0P4Upsqe1RjFhL9r2_x0fTmtozsrVABCPT6-HuQIf4Mn58EiPKJKxeyCFItyu9Xwvqq8vX2DgsxRKiDvHR9WzX4aWeD2W7XFD3sRle5NHkQfd1zlPphjV7k4ivOJh-HNul1y1Cqcew');
    setKitStatus('publicado');
    // Pre-populate with 2 default products
    setKitComponents([
      { productCode: 'CUA-100-CD', name: 'Cuaderno Cuadriculado 100h Norma', quantity: 2, unitPrice: 8500 },
      { productCode: 'COL-PEQ-PGA', name: 'Pegante Líquido Colbón 115g', quantity: 1, unitPrice: 3200 }
    ]);
    setDrawerOpen(true);
  };

  const openEditDrawer = (k: Kit) => {
    setEditingKitId(k.id);
    setKitName(k.name);
    setKitDesc(k.description);
    setKitAge(k.targetAge);
    setKitImage(k.image);
    setKitStatus(k.status);
    setKitComponents([...k.components]);
    setDrawerOpen(true);
  };

  const handleAddComponent = (prod: Product) => {
    if (kitComponents.some((c) => c.productCode === prod.code)) return;
    setKitComponents((prev) => [
      ...prev,
      {
        productCode: prod.code,
        name: prod.name,
        quantity: 1,
        unitPrice: prod.price
      }
    ]);
    setAddProdSearch('');
  };

  const handleRemoveComponent = (code: string) => {
    setKitComponents((prev) => prev.filter((c) => c.productCode !== code));
  };

  const handleQuantityChange = (code: string, newQty: number) => {
    if (newQty < 1) return;
    setKitComponents((prev) =>
      prev.map((c) => (c.productCode === code ? { ...c, quantity: newQty } : c))
    );
  };

  const handleSaveKit = () => {
    if (!kitName.trim() || kitComponents.length === 0) {
      alert('Por favor ingresa el nombre del kit y al menos 1 componente.');
      return;
    }

    if (editingKitId) {
      const updated: Kit = {
        id: editingKitId,
        name: kitName.trim(),
        description: kitDesc.trim(),
        targetAge: kitAge.trim(),
        image: kitImage,
        status: kitStatus,
        components: kitComponents
      };
      onUpdateKit(updated);
    } else {
      const newKit: Kit = {
        id: `KIT-${Date.now().toString().slice(-4)}`,
        name: kitName.trim(),
        description: kitDesc.trim(),
        targetAge: kitAge.trim(),
        image: kitImage,
        status: kitStatus,
        components: kitComponents
      };
      onAddKit(newKit);
    }
    setDrawerOpen(false);
  };

  const toggleKitStatus = (k: Kit) => {
    onUpdateKit({
      ...k,
      status: k.status === 'publicado' ? 'oculto' : 'publicado'
    });
  };

  // Drawer current calculated stats
  const drawerPrice = kitComponents.reduce((acc, c) => {
    const prod = products.find((p) => p.code === c.productCode);
    const unitPrice = prod ? prod.price : c.unitPrice;
    return acc + unitPrice * c.quantity;
  }, 0);
  const drawerBottleneck = getKitBottleneck({ components: kitComponents });

  return (
    <div className="flex-1 flex flex-col min-w-0 h-full overflow-hidden bg-background">
      {/* ENCABEZADO SUPERIOR */}
      <header className="h-16 bg-surface-container-lowest border-b border-surface-variant px-6 lg:px-8 flex items-center justify-between shrink-0">
        <div className="flex items-center gap-2 text-xs font-semibold text-on-surface-variant">
          <span className="text-tertiary">Administración</span>
          <span className="material-symbols-outlined text-xs">chevron_right</span>
          <span className="font-bold text-on-surface">Gestión de Kits Escolares y Paquetes</span>
        </div>
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-surface-container text-on-surface-variant text-xs font-medium">
            <span className="material-symbols-outlined text-sm text-secondary">location_on</span>
            Torreón El Roble, Ibagué
          </div>
          <div className="h-4 w-px bg-surface-variant hidden sm:block"></div>
          <div className="hidden sm:flex items-center gap-1.5 text-on-surface-variant text-xs">
            <span className="material-symbols-outlined text-sm">calendar_today</span>
            24 de octubre de 2024
          </div>
        </div>
      </header>

      {/* ÁREA DE CONTENIDO */}
      <main className="flex-1 overflow-y-auto custom-scroll p-6 lg:p-8">
        <div className="max-w-6xl mx-auto space-y-6">
          {/* Título y Subtítulo */}
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <h2 className="text-2xl lg:text-3xl font-bold text-on-surface tracking-tight">Kits escolares y temáticos</h2>
              <p className="text-sm text-on-surface-variant max-w-3xl mt-1">
                Configura agrupaciones de productos del catálogo. La disponibilidad y el precio se calculan automáticamente a partir del stock y precios de sus componentes individuales.
              </p>
            </div>
            <button
              onClick={openCreateDrawer}
              className="inline-flex items-center justify-center gap-2 px-5 py-3 rounded-lg bg-primary-container text-on-surface text-sm font-bold shadow-xs hover:brightness-95 active:scale-98 transition-all shrink-0 cursor-pointer"
            >
              <span className="material-symbols-outlined font-bold text-[20px]">add</span>
              <span>+ Crear kit</span>
            </button>
          </div>

          {/* BANNER DE REGLAS DE NEGOCIO TRANSPARENTE */}
          <div className="bg-surface-container-low border border-surface-variant rounded-xl p-4 flex items-start gap-3.5">
            <span className="material-symbols-outlined text-primary mt-0.5" style={{ fontVariationSettings: "'FILL' 1" }}>
              info
            </span>
            <div className="text-xs text-on-surface-variant space-y-1">
              <span className="font-bold text-on-surface block text-xs">Políticas del sistema de Kits de Papelería Nico:</span>
              <p>1. No tienen precio manual ni descuento arbitrario: el precio final es exactamente la sumatoria de sus componentes activos.</p>
              <p>2. No tienen stock independiente: la disponibilidad máxima la marca el componente con menor existencia proporcional (cuello de botella).</p>
              <p>3. Los kits no se eliminan para resguardar la trazabilidad de ventas históricas; únicamente pueden pasarse a estado "Oculto".</p>
            </div>
          </div>

          {/* HERRAMIENTAS Y BARRA DE FILTROS */}
          <div className="bg-surface-container-lowest border border-surface-variant rounded-xl p-4 flex flex-col md:flex-row items-center justify-between gap-4 shadow-xs">
            <div className="relative w-full md:w-96">
              <span className="material-symbols-outlined absolute left-3.5 top-1/2 -translate-y-1/2 text-outline text-lg">search</span>
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Buscar kit por nombre..."
                className="w-full h-11 pl-10 pr-4 bg-background border border-surface-variant rounded-lg text-sm text-on-surface placeholder:text-outline focus:outline-none focus:border-primary-container focus:ring-1 focus:ring-primary-container transition-all"
              />
            </div>

            {/* Filtros de Estado */}
            <div className="flex items-center gap-1.5 self-start md:self-auto bg-surface-container-low p-1 rounded-lg border border-surface-variant">
              <button
                onClick={() => setStatusFilter('all')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                  statusFilter === 'all'
                    ? 'bg-surface-container-lowest text-on-surface shadow-xs'
                    : 'text-on-surface-variant hover:text-on-surface'
                }`}
              >
                Todos ({kits.length})
              </button>
              <button
                onClick={() => setStatusFilter('publicado')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                  statusFilter === 'publicado'
                    ? 'bg-surface-container-lowest text-on-surface shadow-xs'
                    : 'text-on-surface-variant hover:text-on-surface'
                }`}
              >
                Publicados ({kits.filter(k => k.status === 'publicado').length})
              </button>
              <button
                onClick={() => setStatusFilter('oculto')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                  statusFilter === 'oculto'
                    ? 'bg-surface-container-lowest text-on-surface shadow-xs'
                    : 'text-on-surface-variant hover:text-on-surface'
                }`}
              >
                Ocultos ({kits.filter(k => k.status === 'oculto').length})
              </button>
            </div>
          </div>

          {/* TABLA ADMINISTRATIVA DE KITS */}
          <div className="bg-surface-container-lowest border border-surface-variant rounded-xl shadow-xs overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="bg-surface-container-low/75 border-b border-surface-variant text-xs font-bold text-on-surface-variant uppercase tracking-wider">
                    <th className="py-3.5 px-4 w-20">Foto</th>
                    <th className="py-3.5 px-4">Nombre del kit</th>
                    <th className="py-3.5 px-4">Composición</th>
                    <th className="py-3.5 px-4">Precio calculado</th>
                    <th className="py-3.5 px-4">Kits disponibles</th>
                    <th className="py-3.5 px-4">Estado</th>
                    <th className="py-3.5 px-4 text-right">Acciones</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-surface-variant text-sm">
                  {filteredKits.map((k) => {
                    const price = getKitCalculatedPrice(k);
                    const bottleneck = getKitBottleneck(k);
                    const totalUnits = k.components.reduce((acc, c) => acc + c.quantity, 0);
                    const isOut = bottleneck.count <= 0;

                    return (
                      <tr
                        key={k.id}
                        className={`hover:bg-surface-container-low/40 transition-colors ${
                          k.status === 'oculto' ? 'bg-surface-container-low/20' : ''
                        }`}
                      >
                        <td className="py-4 px-4 align-top">
                          <img
                            src={k.image}
                            alt={k.name}
                            className={`w-16 h-16 rounded-lg object-cover border border-surface-variant bg-surface-container ${
                              k.status === 'oculto' ? 'grayscale-[40%] opacity-70' : ''
                            }`}
                          />
                        </td>
                        <td className="py-4 px-4 align-top">
                          <p className="font-bold text-on-surface text-sm">{k.name}</p>
                          <span className="inline-block mt-0.5 text-xs text-on-surface-variant font-medium">
                            {k.targetAge}
                          </span>
                        </td>
                        <td className="py-4 px-4 align-top max-w-xs">
                          <div className="space-y-1">
                            <span className="inline-flex items-center gap-1 text-xs font-bold text-on-surface">
                              <span className="material-symbols-outlined text-xs text-primary">layers</span>
                              {k.components.length} productos ({totalUnits} unids)
                            </span>
                            <p className="text-xs text-on-surface-variant line-clamp-2">
                              {k.components.map(c => `${c.quantity}x ${c.name}`).join(', ')}
                            </p>
                          </div>
                        </td>
                        <td className="py-4 px-4 align-top whitespace-nowrap">
                          <p className="font-bold text-on-surface">{formatCOP(price)}</p>
                          <span className="inline-flex items-center gap-1 text-[11px] text-outline">
                            <span className="material-symbols-outlined text-xs">sync</span>
                            Calculado automático
                          </span>
                        </td>
                        <td className="py-4 px-4 align-top">
                          <div className="space-y-1">
                            {isOut ? (
                              <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-error-container text-error text-[11px] font-bold">
                                <span className="w-1.5 h-1.5 rounded-full bg-error"></span>
                                0 kits (Agotado)
                              </span>
                            ) : bottleneck.count <= 3 ? (
                              <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-amber-50 text-amber-800 text-[11px] font-bold border border-amber-200">
                                <span className="w-1.5 h-1.5 rounded-full bg-amber-600"></span>
                                Stock limitado: {bottleneck.count} kits
                              </span>
                            ) : (
                              <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-[#E6F4EA] text-[#137333] text-[11px] font-bold">
                                <span className="w-1.5 h-1.5 rounded-full bg-[#137333]"></span>
                                {bottleneck.count} kits listos
                              </span>
                            )}
                            {bottleneck.limitingComponent && (
                              <p className="text-xs text-on-surface-variant">
                                Límite: {bottleneck.limitingComponent.name}
                              </p>
                            )}
                          </div>
                        </td>
                        <td className="py-4 px-4 align-top">
                          {k.status === 'publicado' ? (
                            <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-[#E6F4EA] text-[#137333] text-[11px] font-bold">
                              <span className="w-1.5 h-1.5 rounded-full bg-[#137333]"></span>
                              Publicado
                            </span>
                          ) : (
                            <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-surface-container text-on-surface-variant text-[11px] font-medium border border-surface-variant">
                              <span className="w-1.5 h-1.5 rounded-full bg-outline"></span>
                              Oculto de catálogo
                            </span>
                          )}
                        </td>
                        <td className="py-4 px-4 align-top text-right whitespace-nowrap">
                          <div className="inline-flex items-center gap-1">
                            <button
                              onClick={() => openEditDrawer(k)}
                              className="p-2 rounded-lg hover:bg-surface-container text-on-surface-variant hover:text-on-surface transition-colors cursor-pointer"
                              title="Editar kit"
                            >
                              <span className="material-symbols-outlined text-lg">edit</span>
                            </button>
                            <button
                              onClick={() => toggleKitStatus(k)}
                              className="p-2 rounded-lg hover:bg-surface-container text-on-surface-variant hover:text-secondary transition-colors cursor-pointer"
                              title={k.status === 'publicado' ? 'Ocultar de catálogo' : 'Publicar en catálogo'}
                            >
                              <span className="material-symbols-outlined text-lg">
                                {k.status === 'publicado' ? 'visibility_off' : 'visibility'}
                              </span>
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </main>

      {/* DRAWER / MODAL LATERAL DE CREAR / EDITAR KIT */}
      {drawerOpen && (
        <div className="fixed inset-0 bg-[#202124]/40 z-50 flex justify-end">
          <div className="w-full max-w-2xl bg-surface-container-lowest h-full shadow-2xl flex flex-col justify-between overflow-hidden border-l border-surface-variant">
            {/* Header del Drawer */}
            <div className="p-6 border-b border-surface-variant flex items-center justify-between bg-surface-container-low shrink-0">
              <div className="space-y-0.5">
                <div className="flex items-center gap-2">
                  <span className="material-symbols-outlined text-primary font-bold">auto_stories</span>
                  <h3 className="text-xl font-bold text-on-surface tracking-tight">
                    {editingKitId ? `Editar Kit: ${kitName}` : 'Crear nuevo Kit Escolar'}
                  </h3>
                </div>
                <p className="text-xs text-on-surface-variant">
                  Configuración de componentes, metadatos y cálculo automático
                </p>
              </div>
              <button
                onClick={() => setDrawerOpen(false)}
                className="w-9 h-9 rounded-lg hover:bg-surface-container flex items-center justify-center text-on-surface-variant transition-colors"
              >
                <span className="material-symbols-outlined text-xl">close</span>
              </button>
            </div>

            {/* Contenido scrolleable */}
            <div className="flex-1 overflow-y-auto p-6 space-y-6 custom-scroll">
              <div className="bg-surface-container-low border border-surface-variant rounded-xl p-3.5 flex items-start gap-3">
                <span className="material-symbols-outlined text-outline mt-0.5 text-lg">calculate</span>
                <p className="text-xs text-on-surface-variant">
                  <strong>Los kits no tienen stock ni precio independiente.</strong> El precio es la suma exacta de sus componentes y los kits disponibles corresponden al componente con menor inventario proporcional.
                </p>
              </div>

              {/* Campos Principales */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="md:col-span-2 space-y-1">
                  <label className="block text-xs font-bold text-on-surface">Nombre del kit <span className="text-secondary">*</span></label>
                  <input
                    type="text"
                    required
                    value={kitName}
                    onChange={(e) => setKitName(e.target.value)}
                    placeholder="Ej: Regreso a primaria"
                    className="w-full h-11 px-3.5 bg-background border border-surface-variant rounded-lg text-sm text-on-surface focus:outline-none focus:border-primary-container focus:ring-1 focus:ring-primary-container"
                  />
                </div>
                <div className="md:col-span-2 space-y-1">
                  <div className="flex justify-between items-center">
                    <label className="block text-xs font-bold text-on-surface">Descripción breve</label>
                    <span className="text-[11px] text-outline">Aclaración: No es lista oficial de colegio</span>
                  </div>
                  <textarea
                    rows={2}
                    value={kitDesc}
                    onChange={(e) => setKitDesc(e.target.value)}
                    placeholder="Paquete escolar básico..."
                    className="w-full p-3 bg-background border border-surface-variant rounded-lg text-sm text-on-surface focus:outline-none focus:border-primary-container focus:ring-1 focus:ring-primary-container resize-none"
                  />
                </div>
                <div className="space-y-1">
                  <label className="block text-xs font-bold text-on-surface">Edad o actividad sugerida</label>
                  <input
                    type="text"
                    value={kitAge}
                    onChange={(e) => setKitAge(e.target.value)}
                    placeholder="Ej: 6 a 10 años / Primaria"
                    className="w-full h-11 px-3.5 bg-background border border-surface-variant rounded-lg text-sm text-on-surface focus:outline-none focus:border-primary-container"
                  />
                </div>
                <div className="space-y-1">
                  <label className="block text-xs font-bold text-on-surface">Imagen representativa</label>
                  <div className="flex items-center gap-3">
                    <img
                      src={kitImage || 'https://lh3.googleusercontent.com/aida-public/AB6AXuAC99Wh6tPRAau69CyQlvV9QDUe7IxMxGVwTBreJFnf1bcEKO-r38WimN2qqBjgRQAd5wXFTc7Qq_9BXBmQ4hre5mt9ufzugrdmr1L9WPtieRiQ0P4Upsqe1RjFhL9r2_x0fTmtozsrVABCPT6-HuQIf4Mn58EiPKJKxeyCFItyu9Xwvqq8vX2DgsxRKiDvHR9WzX4aWeD2W7XFD3sRle5NHkQfd1zlPphjV7k4ivOJh-HNul1y1Cqcew'}
                      alt="Kit Preview"
                      className="w-11 h-11 rounded-lg object-cover border border-surface-variant bg-surface-container"
                    />
                    <span className="text-xs text-tertiary">Foto de paquete escolar</span>
                  </div>
                </div>
              </div>

              <div className="h-px bg-surface-variant"></div>

              {/* SECCIÓN DE COMPONENTES DEL KIT */}
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="text-sm font-bold text-on-surface">Componentes del Kit</h4>
                    <p className="text-xs text-on-surface-variant">
                      Define los productos del inventario y la cantidad requerida de cada uno.
                    </p>
                  </div>
                  <span className="px-2.5 py-1 rounded-full bg-surface-container text-xs font-bold text-on-surface">
                    {kitComponents.length} componentes
                  </span>
                </div>

                {/* Buscador para añadir productos */}
                <div className="space-y-2">
                  <div className="relative">
                    <span className="material-symbols-outlined absolute left-3 top-1/2 -translate-y-1/2 text-outline text-lg">
                      search
                    </span>
                    <input
                      type="text"
                      value={addProdSearch}
                      onChange={(e) => setAddProdSearch(e.target.value)}
                      placeholder="Buscar producto para añadir (ej: Colbón, Cuaderno, Tijera)..."
                      className="w-full h-10 pl-9 pr-3 bg-background border border-surface-variant rounded-lg text-xs text-on-surface placeholder:text-outline"
                    />
                  </div>

                  {addProdSearch.trim() && (
                    <div className="max-h-36 overflow-y-auto bg-surface-container-lowest border border-surface-variant rounded-lg p-1 space-y-1 divide-y divide-surface-variant/40">
                      {products
                        .filter(p => p.name.toLowerCase().includes(addProdSearch.toLowerCase()) || p.code.toLowerCase().includes(addProdSearch.toLowerCase()))
                        .map(p => (
                          <div key={p.code} className="pt-1 flex items-center justify-between p-2 hover:bg-surface-container-low rounded text-xs">
                            <div>
                              <span className="font-bold text-on-surface">{p.name}</span>
                              <span className="text-[11px] text-tertiary ml-2">Stock: {p.stock} unids</span>
                            </div>
                            <button
                              type="button"
                              onClick={() => handleAddComponent(p)}
                              className="px-2 py-1 bg-primary-container text-on-surface font-bold rounded hover:bg-[#e5bd1b]"
                            >
                              + Añadir
                            </button>
                          </div>
                        ))}
                    </div>
                  )}
                </div>

                {/* Tabla de componentes del kit */}
                <div className="border border-surface-variant rounded-xl overflow-hidden bg-surface-container-lowest">
                  <table className="w-full text-left border-collapse text-xs">
                    <thead>
                      <tr className="bg-surface-container-low border-b border-surface-variant text-[11px] font-bold text-on-surface-variant uppercase">
                        <th className="py-2.5 px-3">Producto</th>
                        <th className="py-2.5 px-3 text-center">Cant.</th>
                        <th className="py-2.5 px-3 text-right">Precio unid.</th>
                        <th className="py-2.5 px-3 text-right">Subtotal</th>
                        <th className="py-2.5 px-3">Stock / Capacidad</th>
                        <th className="py-2.5 px-2 text-center"></th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-surface-variant">
                      {kitComponents.map((c) => {
                        const prod = products.find((p) => p.code === c.productCode);
                        const currentStock = prod ? prod.stock : 0;
                        const capacity = Math.floor(currentStock / c.quantity);
                        const isLimiting = drawerBottleneck.limitingComponent?.productCode === c.productCode;

                        return (
                          <tr key={c.productCode} className={isLimiting ? 'bg-amber-50/60' : 'hover:bg-surface-container-low/30'}>
                            <td className="py-3 px-3">
                              <div className="flex items-center gap-1.5">
                                {isLimiting && (
                                  <span className="material-symbols-outlined text-amber-600 text-sm">warning</span>
                                )}
                                <span className="font-bold text-on-surface">{c.name}</span>
                              </div>
                              <span className="text-[11px] text-outline font-mono">{c.productCode}</span>
                            </td>
                            <td className="py-3 px-3 text-center">
                              <div className="inline-flex items-center border border-surface-variant rounded bg-surface">
                                <button
                                  type="button"
                                  onClick={() => handleQuantityChange(c.productCode, c.quantity - 1)}
                                  className="px-1.5 py-0.5 hover:bg-surface-container font-bold"
                                >
                                  -
                                </button>
                                <span className="px-2 font-bold">{c.quantity}</span>
                                <button
                                  type="button"
                                  onClick={() => handleQuantityChange(c.productCode, c.quantity + 1)}
                                  className="px-1.5 py-0.5 hover:bg-surface-container font-bold"
                                >
                                  +
                                </button>
                              </div>
                            </td>
                            <td className="py-3 px-3 text-right">{formatCOP(c.unitPrice)}</td>
                            <td className="py-3 px-3 text-right font-bold">{formatCOP(c.unitPrice * c.quantity)}</td>
                            <td className="py-3 px-3">
                              <span className="text-on-surface-variant block">{currentStock} unids en tienda</span>
                              {isLimiting ? (
                                <span className="text-amber-800 text-[11px] font-bold bg-amber-100 px-1.5 py-0.5 rounded">
                                  Cuello de botella: {capacity} kits
                                </span>
                              ) : (
                                <span className="text-emerald-700 text-[11px] font-semibold">
                                  Alcanza para {capacity} kits
                                </span>
                              )}
                            </td>
                            <td className="py-3 px-2 text-center">
                              <button
                                type="button"
                                onClick={() => handleRemoveComponent(c.productCode)}
                                className="p-1 rounded hover:bg-error-container/40 text-on-surface-variant hover:text-error"
                                title="Quitar componente"
                              >
                                <span className="material-symbols-outlined text-lg">delete</span>
                              </button>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>

                {/* Resumen dinámico del kit */}
                <div className="bg-surface-container-high/60 rounded-xl p-4 space-y-3 border border-surface-variant text-xs">
                  <div className="flex items-center justify-between">
                    <span className="text-on-surface-variant">Total productos diferentes:</span>
                    <span className="font-bold text-on-surface">
                      {kitComponents.length} productos (Mínimo requerido: 1)
                    </span>
                  </div>
                  <div className="flex items-center justify-between border-t border-surface-variant/80 pt-2.5">
                    <div>
                      <span className="font-bold text-on-surface block">Precio total calculado:</span>
                      <span className="text-outline text-[11px]">Suma estricta no editable</span>
                    </div>
                    <div className="text-right">
                      <span className="text-xl font-bold text-on-surface block">{formatCOP(drawerPrice)}</span>
                      <span className="text-[11px] text-emerald-700 font-semibold">Sin recargo ni margen oculto</span>
                    </div>
                  </div>
                  <div className="flex items-center justify-between border-t border-surface-variant/80 pt-2.5">
                    <div>
                      <span className="font-bold text-on-surface block">Kits completos armables hoy:</span>
                      <span className="text-outline text-[11px]">
                        Determinado por {drawerBottleneck.limitingComponent?.name || 'inventario'}
                      </span>
                    </div>
                    <span className="px-3 py-1 bg-[#E6F4EA] text-[#137333] rounded-full font-bold flex items-center gap-1.5">
                      <span className="w-2 h-2 rounded-full bg-[#137333]"></span>
                      {drawerBottleneck.count} kits
                    </span>
                  </div>
                </div>

                {/* Selector de visibilidad */}
                <div className="space-y-2 pt-1">
                  <label className="block text-xs font-bold text-on-surface">Estado en tienda</label>
                  <div className="grid grid-cols-2 gap-3">
                    <label
                      onClick={() => setKitStatus('publicado')}
                      className={`flex items-center gap-3 p-3 rounded-lg border-2 cursor-pointer transition-all ${
                        kitStatus === 'publicado'
                          ? 'border-primary-container bg-surface-container-lowest shadow-xs'
                          : 'border-surface-variant bg-surface-container-low'
                      }`}
                    >
                      <input
                        type="radio"
                        name="kitStatus"
                        checked={kitStatus === 'publicado'}
                        onChange={() => setKitStatus('publicado')}
                        className="text-primary focus:ring-primary-container"
                      />
                      <div>
                        <p className="text-xs font-bold text-on-surface">Publicado en catálogo</p>
                        <p className="text-[11px] text-on-surface-variant">Visible para los clientes</p>
                      </div>
                    </label>

                    <label
                      onClick={() => setKitStatus('oculto')}
                      className={`flex items-center gap-3 p-3 rounded-lg border-2 cursor-pointer transition-all ${
                        kitStatus === 'oculto'
                          ? 'border-primary-container bg-surface-container-lowest shadow-xs'
                          : 'border-surface-variant bg-surface-container-low'
                      }`}
                    >
                      <input
                        type="radio"
                        name="kitStatus"
                        checked={kitStatus === 'oculto'}
                        onChange={() => setKitStatus('oculto')}
                        className="text-primary focus:ring-primary-container"
                      />
                      <div>
                        <p className="text-xs font-bold text-on-surface">Oculto</p>
                        <p className="text-[11px] text-on-surface-variant">Pausado temporalmente</p>
                      </div>
                    </label>
                  </div>
                </div>
              </div>
            </div>

            {/* Pie del Drawer */}
            <div className="p-4 border-t border-surface-variant bg-surface-container-low flex items-center justify-end gap-3 shrink-0">
              <button
                type="button"
                onClick={() => setDrawerOpen(false)}
                className="px-5 py-2.5 rounded-lg border border-surface-variant text-xs font-semibold text-on-surface bg-surface-container-lowest hover:bg-surface-container transition-colors"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={handleSaveKit}
                className="px-6 py-2.5 rounded-lg bg-primary-container text-on-surface text-xs font-bold shadow-xs hover:bg-[#e5bd1b] transition-all flex items-center gap-2 cursor-pointer"
              >
                <span className="material-symbols-outlined text-base">save</span>
                <span>Guardar kit</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
