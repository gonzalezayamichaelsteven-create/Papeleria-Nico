import React, { useState } from 'react';

export type AdminView = 
  | 'inicio' 
  | 'productos' 
  | 'inventario' 
  | 'ventas' 
  | 'reportes' 
  | 'kits' 
  | 'cuenta';

interface AdminLayoutProps {
  currentView: AdminView;
  onNavigate: (view: AdminView) => void;
  onGoToCatalog: () => void;
  onLogout: () => void;
  children: React.ReactNode;
}

export const AdminLayout: React.FC<AdminLayoutProps> = ({
  currentView,
  onNavigate,
  onGoToCatalog,
  onLogout,
  children
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navItems: { id: AdminView; label: string; icon: string; badge?: string }[] = [
    { id: 'inicio', label: 'Inicio', icon: 'dashboard' },
    { id: 'productos', label: 'Productos y categorías', icon: 'category' },
    { id: 'inventario', label: 'Inventario', icon: 'inventory_2' },
    { id: 'ventas', label: 'Registrar venta', icon: 'point_of_sale' },
    { id: 'reportes', label: 'Historial y reportes', icon: 'receipt_long' },
    { id: 'kits', label: 'Kits', icon: 'backpack', badge: '4' },
    { id: 'cuenta', label: 'Administradores y cuenta', icon: 'manage_accounts' },
  ];

  const handleNavClick = (view: AdminView) => {
    onNavigate(view);
    setMobileMenuOpen(false);
  };

  return (
    <div className="min-h-screen bg-background flex flex-col md:flex-row antialiased font-sans text-on-surface">
      {/* MOBILE TOP BAR (para celulares y tablets pequeñas) */}
      <div className="md:hidden bg-surface-container-lowest border-b border-surface-variant px-4 py-3 flex items-center justify-between sticky top-0 z-40">
        <div className="flex items-center gap-2.5">
          <img
            src="https://lh3.googleusercontent.com/aida-public/AB6AXuCRSD000prE69m2RVqEsdCqOdNa09w7MXHnDNYoLCpU2D14dxOhIOHIhVo98lkS11cy3ESzLzK_IWPZewu51Po9PJ7iNWT8F6mhR2-2Xozujy49dLjzkW-jTglo-ugRzEpcrsFN4ugsx6rmBAME7xYJA7A0Uk5xny_aifqzioipNnI42AhFE9XQ3tGw-xbMRjniYVykppz1j6b5eL5KnwlRWusxCppT5eSArmdIaQKI0GSGB_SM1nYj815i7j2mVptlswI"
            alt="Papelería Nico"
            className="w-8 h-8 rounded-lg object-cover border border-surface-variant"
          />
          <div>
            <span className="font-bold text-sm text-on-surface leading-tight block">Papelería Nico</span>
            <span className="text-[10px] text-tertiary">Panel Administrativo</span>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="p-2 rounded-lg hover:bg-surface-container text-on-surface transition-colors"
            title="Abrir menú"
            aria-label="Abrir menú de navegación"
          >
            <span className="material-symbols-outlined text-2xl">
              {mobileMenuOpen ? 'close' : 'menu'}
            </span>
          </button>
        </div>
      </div>

      {/* MOBILE DRAWER / OVERLAY */}
      {mobileMenuOpen && (
        <div className="md:hidden fixed inset-0 z-50 bg-inverse-surface/40 backdrop-blur-xs flex">
          <div className="w-72 bg-surface-container-lowest h-full shadow-2xl flex flex-col justify-between p-4">
            <div>
              <div className="flex items-center justify-between pb-4 border-b border-surface-variant">
                <div className="flex items-center gap-2.5">
                  <img
                    src="https://lh3.googleusercontent.com/aida-public/AB6AXuCRSD000prE69m2RVqEsdCqOdNa09w7MXHnDNYoLCpU2D14dxOhIOHIhVo98lkS11cy3ESzLzK_IWPZewu51Po9PJ7iNWT8F6mhR2-2Xozujy49dLjzkW-jTglo-ugRzEpcrsFN4ugsx6rmBAME7xYJA7A0Uk5xny_aifqzioipNnI42AhFE9XQ3tGw-xbMRjniYVykppz1j6b5eL5KnwlRWusxCppT5eSArmdIaQKI0GSGB_SM1nYj815i7j2mVptlswI"
                    alt="Papelería Nico"
                    className="w-9 h-9 rounded-lg object-cover"
                  />
                  <div>
                    <h2 className="font-bold text-sm text-on-surface">Papelería Nico</h2>
                    <span className="text-[11px] text-tertiary">Panel Administrativo</span>
                  </div>
                </div>
                <button
                  onClick={() => setMobileMenuOpen(false)}
                  className="p-1.5 rounded-lg text-tertiary hover:text-on-surface"
                >
                  <span className="material-symbols-outlined text-xl">close</span>
                </button>
              </div>

              <nav className="mt-4 space-y-1.5">
                {navItems.map((item) => {
                  const isActive = currentView === item.id;
                  return (
                    <button
                      key={item.id}
                      onClick={() => handleNavClick(item.id)}
                      className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-lg text-sm font-semibold transition-all ${
                        isActive
                          ? 'bg-primary-container text-on-surface font-bold shadow-xs'
                          : 'text-on-surface-variant hover:bg-surface-container hover:text-on-surface'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <span
                          className="material-symbols-outlined text-[20px]"
                          style={{ fontVariationSettings: isActive ? "'FILL' 1" : "'FILL' 0" }}
                        >
                          {item.icon}
                        </span>
                        <span>{item.label}</span>
                      </div>
                      {item.badge && (
                        <span className="text-xs px-2 py-0.5 rounded-full bg-surface-container font-bold text-on-surface">
                          {item.badge}
                        </span>
                      )}
                    </button>
                  );
                })}
              </nav>
            </div>

            <div className="pt-4 border-t border-surface-variant space-y-2">
              <div className="flex items-center gap-3 px-2 py-1.5">
                <div className="w-8 h-8 rounded-full bg-primary-container text-on-surface font-bold text-xs flex items-center justify-center">
                  CM
                </div>
                <div className="overflow-hidden">
                  <p className="text-xs font-bold text-on-surface truncate">Carlos M.</p>
                  <p className="text-[11px] text-tertiary">Administrador</p>
                </div>
              </div>
              <button
                onClick={onGoToCatalog}
                className="w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-xs font-semibold text-on-surface hover:bg-surface-container transition-colors"
              >
                <span className="material-symbols-outlined text-base text-primary">storefront</span>
                <span>Ver catálogo</span>
              </button>
              <button
                onClick={onLogout}
                className="w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-xs font-semibold text-secondary hover:bg-error-container/40 transition-colors"
              >
                <span className="material-symbols-outlined text-base">logout</span>
                <span>Cerrar sesión</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* DESKTOP SIDEBAR (BARRA LATERAL COMPARTIDA) */}
      <aside className="hidden md:flex w-64 lg:w-72 bg-surface-container-lowest border-r border-surface-variant flex-col justify-between shrink-0 min-h-screen sticky top-0 h-screen select-none z-30">
        <div>
          {/* Logo y Encabezado de Marca */}
          <div className="p-5 border-b border-surface-variant flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg overflow-hidden border border-surface-variant flex-shrink-0 bg-surface shadow-xs flex items-center justify-center">
              <img
                src="https://lh3.googleusercontent.com/aida-public/AB6AXuCRSD000prE69m2RVqEsdCqOdNa09w7MXHnDNYoLCpU2D14dxOhIOHIhVo98lkS11cy3ESzLzK_IWPZewu51Po9PJ7iNWT8F6mhR2-2Xozujy49dLjzkW-jTglo-ugRzEpcrsFN4ugsx6rmBAME7xYJA7A0Uk5xny_aifqzioipNnI42AhFE9XQ3tGw-xbMRjniYVykppz1j6b5eL5KnwlRWusxCppT5eSArmdIaQKI0GSGB_SM1nYj815i7j2mVptlswI"
                alt="Logo Papelería Nico"
                className="w-full h-full object-cover"
              />
            </div>
            <div className="flex flex-col min-w-0">
              <span className="font-bold text-base text-on-surface tracking-tight leading-tight truncate">
                Papelería Nico
              </span>
              <span className="text-xs text-tertiary font-medium flex items-center gap-1.5 mt-0.5">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 inline-block"></span>
                Panel Administrativo
              </span>
            </div>
          </div>

          {/* Menú de Navegación idéntico en todas las pantallas administrativas */}
          <nav aria-label="Navegación administrativa" className="p-3 space-y-1 overflow-y-auto">
            {navItems.map((item) => {
              const isActive = currentView === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => onNavigate(item.id)}
                  className={`w-full flex items-center justify-between px-3 py-2.5 rounded-lg text-sm font-semibold transition-all ${
                    isActive
                      ? 'bg-primary-container text-on-surface font-bold border-l-4 border-primary shadow-xs'
                      : 'text-on-surface-variant hover:bg-surface-container hover:text-on-surface'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <span
                      className={`material-symbols-outlined text-[20px] ${
                        isActive ? 'text-on-surface' : 'text-tertiary'
                      }`}
                      style={{ fontVariationSettings: isActive ? "'FILL' 1" : "'FILL' 0" }}
                    >
                      {item.icon}
                    </span>
                    <span>{item.label}</span>
                  </div>
                  {item.badge && (
                    <span
                      className={`text-xs px-2 py-0.5 rounded-full font-bold ${
                        isActive
                          ? 'bg-surface-container-lowest text-on-surface'
                          : 'bg-surface-container text-on-surface-variant'
                      }`}
                    >
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>
        </div>

        {/* Zona Inferior: Administrador & Acciones */}
        <div className="p-4 border-t border-surface-variant bg-surface-container-low/40 space-y-3">
          <div className="flex items-center gap-3 px-1">
            <div className="w-9 h-9 rounded-full bg-primary-container text-on-surface font-bold text-xs flex items-center justify-center border border-outline-variant/60 shadow-xs flex-shrink-0">
              CM
            </div>
            <div className="overflow-hidden">
              <p className="text-xs font-bold text-on-surface truncate">Carlos M.</p>
              <p className="text-[11px] text-tertiary">Administrador</p>
            </div>
          </div>
          <div className="pt-2 border-t border-surface-variant space-y-1">
            <button
              onClick={onGoToCatalog}
              className="w-full flex items-center gap-2.5 px-2.5 py-1.5 rounded-lg text-xs font-semibold text-on-surface hover:bg-surface-container transition-colors"
            >
              <span className="material-symbols-outlined text-base text-tertiary">storefront</span>
              <span>Ver catálogo digital</span>
            </button>
            <button
              onClick={onLogout}
              className="w-full flex items-center gap-2.5 px-2.5 py-1.5 rounded-lg text-xs font-semibold text-secondary hover:bg-error-container/40 transition-colors"
            >
              <span className="material-symbols-outlined text-base">logout</span>
              <span>Cerrar sesión</span>
            </button>
          </div>
        </div>
      </aside>

      {/* ÁREA DE CONTENIDO */}
      <div className="flex-1 flex flex-col min-w-0 bg-background overflow-x-hidden">
        {children}
      </div>
    </div>
  );
};
