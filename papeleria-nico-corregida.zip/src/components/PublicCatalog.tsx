import React, { useState, useMemo, useEffect } from 'react';
import {
  Product,
  Kit,
  Category,
  formatCOP,
  matchesCategoryFilter,
  getKitCurrentPrice,
  getKitAvailableUnits
} from '../data/mockData';

interface PublicCatalogProps {
  products: Product[];
  kits: Kit[];
  categories?: Category[];
  onOpenAdminAuth: () => void;
}

interface CatalogCardItem {
  id: string;
  name: string;
  category: string;
  price: number;
  isAvailable: boolean;
  isKit: boolean;
  image: string;
  description: string;
  itemsList?: string[];
}

export const PublicCatalog: React.FC<PublicCatalogProps> = ({
  products,
  kits,
  categories,
  onOpenAdminAuth
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('Todas');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [onlyAvailable, setOnlyAvailable] = useState<boolean>(false);
  const [modalItem, setModalItem] = useState<CatalogCardItem | null>(null);

  // Kits ocultos no deben quedar visibles en un detalle público abierto
  useEffect(() => {
    if (modalItem && modalItem.isKit) {
      const activeKit = kits.find((k) => k.id === modalItem.id);
      if (!activeKit || activeKit.status !== 'publicado') {
        setModalItem(null);
      } else {
        const currentPrice = getKitCurrentPrice(activeKit, products);
        const availableUnits = getKitAvailableUnits(activeKit, products);
        const currentAvailable = availableUnits > 0;
        if (modalItem.price !== currentPrice || modalItem.isAvailable !== currentAvailable) {
          setModalItem((prev) => (prev ? { ...prev, price: currentPrice, isAvailable: currentAvailable } : null));
        }
      }
    }
  }, [kits, products, modalItem]);

  // Generamos la lista de productos y kits disponibles para el catálogo público
  const catalogItems: CatalogCardItem[] = useMemo(() => {
    // Kits escolares: SOLO los que tienen estado 'publicado'. Los 'oculto' jamás se muestran en catálogo público.
    const publishedKits = kits.filter((k) => k.status === 'publicado');

    const kitCards: CatalogCardItem[] = publishedKits.map((k) => {
      // Precio calculado dinámicamente sumando precio actual de cada producto × cantidad requerida
      const calculatedPrice = getKitCurrentPrice(k, products);

      // Disponibilidad calculada como el mínimo de floor(stock / cantidad requerida)
      const availableUnits = getKitAvailableUnits(k, products);
      const isAvailable = availableUnits > 0;

      return {
        id: k.id,
        name: k.name,
        category: 'Kits escolares',
        price: calculatedPrice,
        isAvailable,
        isKit: true,
        image: k.image,
        description: k.description,
        itemsList: k.components.map((c) => `${c.quantity}x ${c.name}`)
      };
    });

    // Productos físicos individuales completos
    const regularProducts: CatalogCardItem[] = products.map((p) => ({
      id: p.code,
      name: p.name,
      category: p.category,
      price: p.price,
      isAvailable: p.stock > 0,
      isKit: false,
      image: p.image,
      description: p.description
    }));

    return [...kitCards, ...regularProducts];
  }, [kits, products]);

  // Lista de categorías compartidas y consistentes con administración
  const categoryList = useMemo(() => {
    if (categories && categories.length > 0) {
      return ['Todas', 'Kits escolares', ...categories.map((c) => c.name)];
    }
    return [
      'Todas',
      'Kits escolares',
      'Cuadernos',
      'Lápices y Bolígrafos',
      'Colores y Arte',
      'Borradores',
      'Adhesivos y pegantes',
      'Escolar'
    ];
  }, [categories]);

  const filteredItems = useMemo(() => {
    return catalogItems.filter((item) => {
      // Filtrado estricto y coherente por categoría
      let matchCat = false;
      if (selectedCategory === 'Todas') {
        matchCat = true;
      } else if (selectedCategory === 'Kits escolares') {
        matchCat = item.isKit;
      } else {
        // Categorías individuales: no deben coincidir kits ni productos de otras categorías
        matchCat = !item.isKit && matchesCategoryFilter(item.category, selectedCategory);
      }

      // Filtrado por texto
      const q = searchQuery.toLowerCase().trim();
      const matchSearch = q === '' || item.name.toLowerCase().includes(q) || item.description.toLowerCase().includes(q);

      // Solo disponibles
      const matchAvailable = !onlyAvailable || item.isAvailable;

      return matchCat && matchSearch && matchAvailable;
    });
  }, [catalogItems, selectedCategory, searchQuery, onlyAvailable]);

  const resetAllFilters = () => {
    setSelectedCategory('Todas');
    setSearchQuery('');
    setOnlyAvailable(false);
  };

  return (
    <div className="min-h-screen bg-background text-on-surface font-sans antialiased flex flex-col justify-between selection:bg-primary-container selection:text-on-primary-fixed">
      {/* 1. ENCABEZADO COMPACTO */}
      <header className="sticky top-0 z-30 bg-surface-container-lowest/95 backdrop-blur-md border-b border-surface-variant py-2.5">
        <div className="max-w-7xl mx-auto px-4 md:px-8 min-h-16 flex items-center justify-between gap-4">
          {/* Identidad de marca */}
          <div className="flex items-center gap-3 shrink-0">
            <div className="w-10 h-10 rounded-xl overflow-hidden border border-surface-variant flex items-center justify-center bg-white shadow-xs shrink-0">
              <img
                src="https://lh3.googleusercontent.com/aida-public/AB6AXuCRSD000prE69m2RVqEsdCqOdNa09w7MXHnDNYoLCpU2D14dxOhIOHIhVo98lkS11cy3ESzLzK_IWPZewu51Po9PJ7iNWT8F6mhR2-2Xozujy49dLjzkW-jTglo-ugRzEpcrsFN4ugsx6rmBAME7xYJA7A0Uk5xny_aifqzioipNnI42AhFE9XQ3tGw-xbMRjniYVykppz1j6b5eL5KnwlRWusxCppT5eSArmdIaQKI0GSGB_SM1nYj815i7j2mVptlswI"
                alt="Papelería Nico"
                className="w-full h-full object-cover"
              />
            </div>
            <div className="flex flex-col min-w-0">
              <span className="text-base font-bold text-[#202124] leading-tight tracking-tight">Papelería Nico</span>
              <span className="text-xs text-on-surface-variant font-medium">Consulta en línea. Compra en la papelería</span>
              <span className="text-[11px] sm:text-xs text-on-surface-variant leading-snug mt-0.5 max-w-sm sm:max-w-md">
                Carrera 7 bis 129-115, Torreón El Roble, Torre 7 Apartamento 102
              </span>
            </div>
          </div>

          {/* Botón discreto de Acceso Administrativo */}
          <button
            onClick={onOpenAdminAuth}
            className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-lg border border-surface-variant hover:bg-surface-container-low text-on-surface-variant hover:text-[#202124] transition-all text-xs font-semibold shrink-0 cursor-pointer"
          >
            <span className="material-symbols-outlined text-[17px]">lock</span>
            <span>Acceso administrativo</span>
          </button>
        </div>
      </header>

      {/* CONTENIDO PRINCIPAL */}
      <main className="flex-1 w-full max-w-7xl mx-auto px-4 md:px-8 pt-6 pb-16 space-y-6">
        {/* 2. Buscador destacado */}
        <section className="w-full">
          <div className="relative w-full">
            <span className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none text-on-surface-variant">
              <span className="material-symbols-outlined text-[24px]">search</span>
            </span>
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="¿Qué producto estás buscando?"
              className="w-full h-14 pl-12 pr-12 rounded-xl bg-surface-container-lowest border border-surface-variant shadow-xs text-[#202124] placeholder:text-on-surface-variant/80 text-[15px] focus:outline-none focus:border-[#725c00] focus:ring-2 focus:ring-primary-container/40 transition-all"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute inset-y-0 right-0 pr-4 flex items-center text-on-surface-variant hover:text-[#202124] transition-colors"
                title="Borrar texto"
              >
                <span className="material-symbols-outlined text-[20px]">close</span>
              </button>
            )}
          </div>
        </section>

        {/* 3. Filtros compactos en una sola barra horizontal */}
        <section className="bg-surface-container-lowest border border-surface-variant rounded-xl p-2.5 px-3 flex flex-wrap lg:flex-nowrap items-center justify-between gap-3 shadow-xs">
          {/* Categorías pills con scroll horizontal */}
          <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar py-0.5">
            {categoryList.map((cat) => {
              const active = selectedCategory === cat;
              return (
                <button
                  key={cat}
                  onClick={() => setSelectedCategory(cat)}
                  className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-all ${
                    active
                      ? 'bg-[#202124] text-white'
                      : 'text-on-surface-variant hover:bg-surface-container-low'
                  }`}
                >
                  {cat}
                </button>
              );
            })}
          </div>

          {/* Acciones de filtro secundario (Solo disponibles + Limpiar) */}
          <div className="flex items-center gap-4 shrink-0 pl-1 border-t lg:border-t-0 border-surface-variant/60 pt-2 lg:pt-0 w-full lg:w-auto justify-between lg:justify-end">
            <label className="inline-flex items-center gap-2 cursor-pointer select-none text-xs font-medium text-[#202124]">
              <input
                type="checkbox"
                checked={onlyAvailable}
                onChange={(e) => setOnlyAvailable(e.target.checked)}
                className="rounded border-surface-variant text-[#202124] focus:ring-0 focus:ring-offset-0 w-4 h-4 cursor-pointer"
              />
              <span>Solo disponibles</span>
            </label>
            <button
              onClick={resetAllFilters}
              className="text-xs font-semibold text-on-surface-variant hover:text-[#202124] underline underline-offset-4 transition-colors"
            >
              Limpiar filtros
            </button>
          </div>
        </section>

        {/* Estado y conteo sutil */}
        <div className="flex items-center justify-between px-1 text-xs text-on-surface-variant">
          <span>
            Mostrando <strong className="text-[#202124] font-bold">{filteredItems.length}</strong> {filteredItems.length === 1 ? 'producto' : 'productos'} en catálogo
          </span>
          <span>Precios en Pesos Colombianos (COP)</span>
        </div>

        {/* 4. Cuadrícula de productos y kits adaptable (2 cols mobile, 3 tablet, 4 desktop) */}
        {filteredItems.length > 0 ? (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-5">
            {filteredItems.map((item) => (
              <article
                key={item.id}
                className="group bg-surface-container-lowest rounded-xl border border-surface-variant hover:border-outline hover:shadow-sm transition-all flex flex-col overflow-hidden"
              >
                <div className="relative bg-surface-container-low aspect-[4/3] w-full flex items-center justify-center overflow-hidden">
                  <div className="absolute top-2 left-2 z-10">
                    {item.isAvailable ? (
                      <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-800 text-[11px] font-semibold border border-emerald-200/70">
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-600"></span>
                        Disponible
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-surface-variant text-on-surface-variant text-[11px] font-semibold">
                        <span className="w-1.5 h-1.5 rounded-full bg-outline"></span>
                        Agotado
                      </span>
                    )}
                  </div>
                  {item.isKit && (
                    <span className="absolute top-2 right-2 z-10 px-2 py-0.5 rounded-md bg-[#ffd21f]/30 text-[#705b00] text-[10px] font-bold tracking-wide uppercase border border-[#ffd21f]/60">
                      Kit
                    </span>
                  )}
                  <img
                    src={item.image}
                    alt={item.name}
                    className={`w-full h-full object-cover group-hover:scale-105 transition-transform duration-200 ${
                      !item.isAvailable ? 'grayscale-[35%]' : ''
                    }`}
                  />
                </div>
                <div className="p-3 flex flex-col flex-1 justify-between gap-2.5">
                  <div className="space-y-0.5">
                    <h3 className="text-sm font-semibold text-[#202124] line-clamp-2 leading-snug min-h-[2.5rem]" title={item.name}>
                      {item.name}
                    </h3>
                    <p className="text-sm font-bold text-[#202124]">{formatCOP(item.price)}</p>
                  </div>
                  <button
                    onClick={() => setModalItem(item)}
                    className="w-full py-1.5 px-3 rounded-lg bg-surface-container-low border border-surface-variant text-on-surface-variant hover:text-[#202124] hover:bg-surface-container font-semibold text-xs transition-colors flex items-center justify-center gap-1.5"
                  >
                    <span className="material-symbols-outlined text-[16px]">visibility</span>
                    <span>Ver detalle</span>
                  </button>
                </div>
              </article>
            ))}
          </div>
        ) : (
          /* ESTADO VACÍO */
          <div className="bg-surface-container-lowest rounded-xl border border-surface-variant p-12 text-center max-w-md mx-auto space-y-3">
            <div className="w-12 h-12 rounded-full bg-surface-container-low flex items-center justify-center mx-auto text-on-surface-variant">
              <span className="material-symbols-outlined text-2xl">search_off</span>
            </div>
            <h3 className="text-base font-bold text-[#202124]">No se encontraron productos</h3>
            <p className="text-xs text-on-surface-variant leading-relaxed">
              No hay artículos que coincidan con los filtros o término de búsqueda seleccionado.
            </p>
            <div className="pt-2">
              <button
                onClick={resetAllFilters}
                className="px-4 py-2 rounded-lg bg-surface-container border border-surface-variant text-[#202124] hover:bg-surface-container-high text-xs font-semibold transition-all"
              >
                Limpiar todos los filtros
              </button>
            </div>
          </div>
        )}
      </main>

      {/* 5. VENTANA MODAL INTERACTIVA DE DETALLE */}
      {modalItem && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-inverse-surface/40 backdrop-blur-xs">
          <div className="bg-surface-container-lowest rounded-2xl border border-surface-variant shadow-xl max-w-lg w-full overflow-hidden flex flex-col max-h-[90vh]">
            {/* Header modal */}
            <div className="px-5 py-3.5 border-b border-surface-variant flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="text-xs font-semibold uppercase tracking-wider text-on-surface-variant">
                  {modalItem.category}
                </span>
                {modalItem.isKit && (
                  <span className="px-2 py-0.5 rounded bg-[#ffd21f]/30 text-[#705b00] text-[10px] font-bold uppercase border border-[#ffd21f]/60">
                    Kit Escolar
                  </span>
                )}
              </div>
              <button
                onClick={() => setModalItem(null)}
                className="w-8 h-8 rounded-lg hover:bg-surface-container flex items-center justify-center text-on-surface-variant hover:text-[#202124] transition-colors"
                title="Cerrar ventana"
              >
                <span className="material-symbols-outlined text-[19px]">close</span>
              </button>
            </div>

            {/* Contenido scrollable */}
            <div className="p-5 sm:p-6 overflow-y-auto space-y-4">
              <div className="flex flex-col sm:flex-row gap-4 items-center sm:items-start">
                <div className="w-36 h-36 shrink-0 bg-surface-container-low rounded-xl border border-surface-variant flex items-center justify-center p-2 overflow-hidden">
                  <img
                    src={modalItem.image}
                    alt={modalItem.name}
                    className="w-full h-full object-contain"
                  />
                </div>
                <div className="flex-1 space-y-2 text-center sm:text-left">
                  <h2 className="text-base sm:text-lg font-bold text-[#202124] leading-snug break-words">{modalItem.name}</h2>
                  <p className="text-lg font-bold text-[#202124]">{formatCOP(modalItem.price)}</p>
                  <div>
                    {modalItem.isAvailable ? (
                      <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-50 text-emerald-800 border border-emerald-200">
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-600"></span>
                        <span>Disponible en tienda</span>
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-surface-variant text-on-surface-variant border border-surface-variant">
                        <span className="w-1.5 h-1.5 rounded-full bg-outline"></span>
                        <span>Agotado</span>
                      </span>
                    )}
                  </div>
                </div>
              </div>

              <div className="space-y-1 text-xs">
                <h4 className="font-bold text-[#202124]">Descripción:</h4>
                <p className="text-on-surface-variant leading-relaxed">{modalItem.description}</p>
              </div>

              {/* Sección especial para Kits (Lista de productos incluidos con su cantidad) */}
              {modalItem.isKit && modalItem.itemsList && modalItem.itemsList.length > 0 && (
                <div className="space-y-2 pt-2 border-t border-surface-variant">
                  <h4 className="text-xs font-bold text-[#202124] flex items-center gap-1.5">
                    <span className="material-symbols-outlined text-[16px] text-[#705b00]">checklist</span>
                    <span>Útiles y componentes incluidos en este kit:</span>
                  </h4>
                  <ul className="bg-surface-container-low rounded-xl p-3 border border-surface-variant text-xs text-[#202124] space-y-1.5">
                    {modalItem.itemsList.map((item, idx) => (
                      <li key={idx} className="flex items-center gap-2">
                        <span className="w-1.5 h-1.5 rounded-full bg-[#ffd21f] shrink-0 border border-[#705b00]"></span>
                        <span>{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {/* Nota informativa sobre compra física */}
              <div className="p-3 rounded-lg bg-[#f7f8fa] border border-surface-variant flex items-start gap-2.5 text-xs text-on-surface-variant">
                <span className="material-symbols-outlined text-base text-[#725c00] shrink-0 mt-0.5">storefront</span>
                <p>
                  Artículo disponible para compra directa en nuestro local físico en{' '}
                  <strong>Torreón El Roble, Ibagué</strong>. Consulta en línea y acércate al mostrador.
                </p>
              </div>
            </div>

            {/* Footer modal */}
            <div className="px-5 py-3 bg-surface-container-low border-t border-surface-variant flex justify-end">
              <button
                onClick={() => setModalItem(null)}
                className="px-4 py-1.5 rounded-lg border border-surface-variant bg-surface-container-lowest hover:bg-surface-container text-xs font-semibold text-[#202124] transition-colors shadow-xs"
              >
                Cerrar
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 8. PIE DE PÁGINA MINIMALISTA */}
      <footer className="mt-auto border-t border-surface-variant bg-surface-container-lowest py-6">
        <div className="max-w-7xl mx-auto px-4 md:px-8 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-on-surface-variant">
          <p className="text-center sm:text-left">
            Papelería Nico • Carrera 7 bis 129-115, Torreón El Roble, Torre 7 Apartamento 102, Ibagué • © 2024 Papelería Nico
          </p>
          <button
            onClick={onOpenAdminAuth}
            className="hover:text-[#202124] transition-colors font-medium underline underline-offset-4"
          >
            Acceso administrativo
          </button>
        </div>
      </footer>
    </div>
  );
};
