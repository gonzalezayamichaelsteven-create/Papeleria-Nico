import React from 'react';
import { AdminView } from './AdminLayout';
import { Product, Sale, formatCOP, getBogotaToday } from '../data/mockData';

interface AdminHomeProps {
  products: Product[];
  sales: Sale[];
  onNavigate: (view: AdminView, filter?: string) => void;
  onSelectSaleDetail?: (saleId: string) => void;
}

export const AdminHome: React.FC<AdminHomeProps> = ({
  products,
  sales,
  onNavigate,
  onSelectSaleDetail
}) => {
  const { dateString, formattedLong } = getBogotaToday();

  // Ventas de hoy en zona horaria America/Bogota
  const todaySales = sales.filter((s) => s.date === dateString);
  const totalVendidoHoy = todaySales.reduce((acc, s) => acc + s.total, 0);
  const numeroVentasHoy = todaySales.length;
  const ticketPromedio = numeroVentasHoy > 0 ? Math.round(totalVendidoHoy / numeroVentasHoy) : 0;

  // Reglas de inventario idénticas:
  // Agotados: stock === 0
  // Stock bajo: stock > 0 && stock <= minStock (no incluye agotados)
  const outOfStockProducts = products.filter((p) => p.stock === 0);
  const lowStockProducts = products.filter((p) => p.stock > 0 && p.stock <= p.minStock);

  // Lista de productos por reponer (stock <= minStock, ordenados por severidad: agotados primero)
  const productosPorReponer = products
    .filter((p) => p.stock <= p.minStock)
    .sort((a, b) => {
      if (a.stock === 0 && b.stock > 0) return -1;
      if (b.stock === 0 && a.stock > 0) return 1;
      return a.stock - b.stock;
    });

  // Ventas recientes (ordenadas de más nueva a más antigua)
  const recentSales = sales.slice(0, 5);

  return (
    <div className="flex-1 flex flex-col bg-background min-w-0">
      {/* Encabezado superior / Título y Fecha dinámica de Bogotá */}
      <header className="bg-surface-container-lowest border-b border-surface-variant px-6 py-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-on-surface">Inicio</h2>
          <p className="text-sm text-tertiary mt-0.5">
            Resumen del día • Hoy, {formattedLong}
          </p>
        </div>
        {/* Fila de 3 Botones de Acción Rápida */}
        <div className="flex flex-wrap items-center gap-3">
          {/* Botón Principal: Registrar venta */}
          <button
            onClick={() => onNavigate('ventas')}
            className="inline-flex items-center gap-2 bg-primary-container text-on-surface text-sm font-bold px-4 py-2.5 rounded-lg hover:bg-amber-400 active:scale-95 transition-all shadow-xs cursor-pointer"
            type="button"
          >
            <span className="material-symbols-outlined text-xl" style={{ fontVariationSettings: "'FILL' 1" }}>
              add_circle
            </span>
            <span>Registrar venta</span>
          </button>
          {/* Botón Secundario: Agregar stock */}
          <button
            onClick={() => onNavigate('inventario')}
            className="inline-flex items-center gap-2 bg-surface-container-lowest text-on-surface text-sm font-semibold border border-surface-variant px-4 py-2.5 rounded-lg hover:bg-surface-container-low active:scale-95 transition-all cursor-pointer"
            type="button"
          >
            <span className="material-symbols-outlined text-xl text-tertiary">move_to_inbox</span>
            <span>Agregar stock</span>
          </button>
          {/* Botón Secundario: Nuevo producto */}
          <button
            onClick={() => onNavigate('productos')}
            className="inline-flex items-center gap-2 bg-surface-container-lowest text-on-surface text-sm font-semibold border border-surface-variant px-4 py-2.5 rounded-lg hover:bg-surface-container-low active:scale-95 transition-all cursor-pointer"
            type="button"
          >
            <span className="material-symbols-outlined text-xl text-tertiary">add_box</span>
            <span>Nuevo producto</span>
          </button>
        </div>
      </header>

      {/* Contenedor con Scroll de Métricas y Tablas */}
      <div className="p-6 space-y-6 max-w-7xl">
        {/* Cuadrícula de 4 Indicadores Clave (KPI Cards) calculados */}
        <section className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {/* KPI 1: Total vendido hoy */}
          <div className="bg-surface-container-lowest border border-surface-variant p-5 rounded-xl shadow-xs">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs text-tertiary uppercase tracking-wider font-semibold">Total vendido hoy</span>
              <span className="material-symbols-outlined text-primary text-xl">payments</span>
            </div>
            <div className="text-xl font-extrabold text-on-surface mb-1">{formatCOP(totalVendidoHoy)}</div>
            <p className="text-xs text-tertiary flex items-center gap-1">
              <span className="text-green-700 font-bold">{numeroVentasHoy} {numeroVentasHoy === 1 ? 'transacción' : 'transacciones'}</span> acumuladas
            </p>
          </div>

          {/* KPI 2: Número de ventas de hoy */}
          <div className="bg-surface-container-lowest border border-surface-variant p-5 rounded-xl shadow-xs">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs text-tertiary uppercase tracking-wider font-semibold">Ventas de hoy</span>
              <span className="material-symbols-outlined text-tertiary text-xl">receipt</span>
            </div>
            <div className="text-xl font-extrabold text-on-surface mb-1">
              {numeroVentasHoy} {numeroVentasHoy === 1 ? 'venta' : 'ventas'}
            </div>
            <p className="text-xs text-tertiary">
              Promedio ticket: <span className="font-semibold text-on-surface">{formatCOP(ticketPromedio)}</span>
            </p>
          </div>

          {/* KPI 3: Productos con stock bajo */}
          <button
            onClick={() => onNavigate('inventario', 'Stock bajo')}
            className="bg-surface-container-lowest border border-surface-variant p-5 rounded-xl shadow-xs hover:border-amber-400 transition-colors block text-left group cursor-pointer"
          >
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs text-tertiary uppercase tracking-wider font-semibold">Stock bajo</span>
              <span className="material-symbols-outlined text-amber-600 text-xl">warning</span>
            </div>
            <div className="flex items-baseline justify-between mb-1">
              <span className="text-xl font-extrabold text-on-surface">
                {lowStockProducts.length} {lowStockProducts.length === 1 ? 'producto' : 'productos'}
              </span>
              <span className="bg-amber-100 text-amber-800 text-xs px-2 py-0.5 rounded-full font-bold">Por revisar</span>
            </div>
            <p className="text-xs text-tertiary flex items-center gap-1 group-hover:text-primary transition-colors">
              <span>Ver inventario filtrado</span>
              <span className="material-symbols-outlined text-sm">arrow_forward</span>
            </p>
          </button>

          {/* KPI 4: Productos agotados */}
          <button
            onClick={() => onNavigate('inventario', 'Agotado')}
            className="bg-surface-container-lowest border border-surface-variant p-5 rounded-xl shadow-xs hover:border-secondary transition-colors block text-left group cursor-pointer"
          >
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs text-tertiary uppercase tracking-wider font-semibold">Productos agotados</span>
              <span className="material-symbols-outlined text-secondary text-xl">error_outline</span>
            </div>
            <div className="flex items-baseline justify-between mb-1">
              <span className="text-xl font-extrabold text-on-surface">
                {outOfStockProducts.length} {outOfStockProducts.length === 1 ? 'producto' : 'productos'}
              </span>
              <span className="bg-red-100 text-secondary text-xs px-2 py-0.5 rounded-full font-bold">Sin existencias</span>
            </div>
            <p className="text-xs text-tertiary flex items-center gap-1 group-hover:text-secondary transition-colors">
              <span>Ver inventario agotado</span>
              <span className="material-symbols-outlined text-sm">arrow_forward</span>
            </p>
          </button>
        </section>

        {/* DOS SECCIONES ESTRUCTURADAS (GRID A 2 COLUMNAS) */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Columna Izquierda (7 cols): Productos por reponer */}
          <section className="lg:col-span-7 bg-surface-container-lowest border border-surface-variant rounded-xl p-5 shadow-xs flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between pb-4 border-b border-surface-variant mb-4">
                <div>
                  <h3 className="text-lg font-bold text-on-surface">Productos por reponer</h3>
                  <p className="text-xs text-tertiary">
                    {productosPorReponer.length} {productosPorReponer.length === 1 ? 'artículo' : 'artículos'} con inventario en nivel de alerta
                  </p>
                </div>
                <button
                  onClick={() => onNavigate('inventario')}
                  className="text-xs text-primary font-bold hover:underline flex items-center gap-1 cursor-pointer"
                >
                  <span>Gestionar en inventario</span>
                  <span className="material-symbols-outlined text-base">chevron_right</span>
                </button>
              </div>

              {/* Tabla de reposición dinámica */}
              <div className="overflow-x-auto">
                {productosPorReponer.length === 0 ? (
                  <div className="py-8 text-center text-tertiary">
                    <span className="material-symbols-outlined text-3xl text-emerald-600 mb-1">check_circle</span>
                    <p className="text-sm font-semibold">Inventario en niveles óptimos</p>
                    <p className="text-xs">No hay productos agotados ni por debajo del mínimo de seguridad.</p>
                  </div>
                ) : (
                  <table className="w-full text-left border-collapse">
                    <thead>
                      <tr className="border-b border-surface-variant">
                        <th className="py-2.5 px-3 text-xs text-tertiary font-semibold">Producto</th>
                        <th className="py-2.5 px-3 text-xs text-tertiary font-semibold text-center">Disponible</th>
                        <th className="py-2.5 px-3 text-xs text-tertiary font-semibold text-center">Mínimo</th>
                        <th className="py-2.5 px-3 text-xs text-tertiary font-semibold text-right">Estado</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-surface-variant">
                      {productosPorReponer.map((p) => {
                        const isOut = p.stock === 0;
                        return (
                          <tr
                            key={p.code}
                            onClick={() => onNavigate('inventario', p.code)}
                            className="hover:bg-surface-container-low transition-colors cursor-pointer"
                            title="Ver en inventario"
                          >
                            <td className="py-3 px-3">
                              <div className="text-sm font-bold text-on-surface">{p.name}</div>
                              <div className="text-xs text-tertiary font-mono">{p.code} • {p.category}</div>
                            </td>
                            <td className={`py-3 px-3 text-center font-bold ${isOut ? 'text-secondary' : 'text-amber-700'}`}>
                              {p.stock} unids.
                            </td>
                            <td className="py-3 px-3 text-center text-tertiary text-sm">
                              {p.minStock} unids.
                            </td>
                            <td className="py-3 px-3 text-right">
                              {isOut ? (
                                <span className="inline-flex items-center gap-1 bg-red-50 text-secondary border border-red-200 px-2 py-0.5 rounded-full text-[11px] font-bold">
                                  <span className="w-1.5 h-1.5 rounded-full bg-secondary"></span> Agotado
                                </span>
                              ) : (
                                <span className="inline-flex items-center gap-1 bg-amber-50 text-amber-800 border border-amber-200 px-2 py-0.5 rounded-full text-[11px] font-bold">
                                  <span className="w-1.5 h-1.5 rounded-full bg-amber-500"></span> Stock bajo
                                </span>
                              )}
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                )}
              </div>
            </div>
          </section>

          {/* Columna Derecha (5 cols): Ventas recientes dinámicas */}
          <section className="lg:col-span-5 bg-surface-container-lowest border border-surface-variant rounded-xl p-5 shadow-xs flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between pb-4 border-b border-surface-variant mb-4">
                <div>
                  <h3 className="text-lg font-bold text-on-surface">Ventas recientes</h3>
                  <p className="text-xs text-tertiary">Últimos comprobantes de caja</p>
                </div>
                <button
                  onClick={() => onNavigate('reportes')}
                  className="text-xs text-primary font-bold hover:underline cursor-pointer"
                >
                  Ver todas
                </button>
              </div>

              {/* Lista de Ventas Recientes */}
              <div className="divide-y divide-surface-variant">
                {recentSales.length === 0 ? (
                  <div className="py-8 text-center text-tertiary">
                    <span className="material-symbols-outlined text-3xl mb-1">receipt_long</span>
                    <p className="text-sm font-semibold">Sin ventas registradas</p>
                  </div>
                ) : (
                  recentSales.map((sale) => (
                    <div
                      key={sale.id}
                      className="py-3.5 flex items-center justify-between hover:bg-surface-container-low px-2 rounded-lg transition-colors"
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-full bg-surface-container-low flex items-center justify-center text-tertiary font-bold text-xs">
                          #V
                        </div>
                        <div>
                          <span className="text-sm font-bold text-on-surface">{sale.id}</span>
                          <span className="block text-xs text-tertiary">
                            {sale.date} {sale.time} • {sale.channel}
                          </span>
                        </div>
                      </div>
                      <div className="text-right flex items-center gap-3">
                        <span className="text-sm font-bold text-on-surface">{formatCOP(sale.total)}</span>
                        <button
                          onClick={() => {
                            if (onSelectSaleDetail) onSelectSaleDetail(sale.id);
                            onNavigate('reportes');
                          }}
                          className="p-1.5 text-tertiary hover:text-on-surface hover:bg-surface-variant rounded-lg transition-colors cursor-pointer"
                          title="Ver comprobante de venta"
                        >
                          <span className="material-symbols-outlined text-lg">visibility</span>
                        </button>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          </section>
        </div>
      </div>
    </div>
  );
};
