import React, { useState, useMemo, useEffect } from 'react';
import {
  Product,
  Kit,
  Category,
  SaleItem,
  formatCOP,
  getBogotaToday,
  matchesCategoryFilter,
  getKitCurrentPrice,
  getKitAvailableUnits,
  validateCartStock
} from '../data/mockData';

interface AdminPosProps {
  products: Product[];
  kits: Kit[];
  categories?: Category[];
  onCompleteSale: (saleData: {
    items: SaleItem[];
    subtotal: number;
    total: number;
    channel: string;
  }) => { success: boolean; error?: string };
  onGoToReports: () => void;
}

export const AdminPos: React.FC<AdminPosProps> = ({
  products,
  kits,
  categories,
  onCompleteSale,
  onGoToReports
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [filterType, setFilterType] = useState<'all' | 'products' | 'kits'>('all');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  // El ticket inicia vacío para nuevas ventas
  const [cartItems, setCartItems] = useState<SaleItem[]>([]);
  const [cartWarning, setCartWarning] = useState<string | null>(null);
  const [priceChangeAlert, setPriceChangeAlert] = useState<string | null>(null);

  const [clearModalOpen, setClearModalOpen] = useState(false);
  const [successModalOpen, setSuccessModalOpen] = useState(false);
  const [lastSaleReceipt, setLastSaleReceipt] = useState<string>('');
  const [lastSaleTotal, setLastSaleTotal] = useState<number>(0);
  const [processing, setProcessing] = useState(false);

  const { formattedLong, timeString, dateString } = getBogotaToday();

  // Recalcular precios de ítems sin confirmar si cambian en productos o kits
  useEffect(() => {
    setCartItems((prevItems) => {
      if (prevItems.length === 0) return prevItems;
      let priceChanged = false;
      const updated = prevItems.map((item) => {
        let currentUnitPrice = item.unitPrice;
        if (item.isKit) {
          const kit = kits.find((k) => k.id === item.code);
          if (kit) {
            currentUnitPrice = getKitCurrentPrice(kit, products);
          }
        } else {
          const prod = products.find((p) => p.code === item.code);
          if (prod) {
            currentUnitPrice = prod.price;
          }
        }

        if (currentUnitPrice !== item.unitPrice) {
          priceChanged = true;
          return {
            ...item,
            unitPrice: currentUnitPrice,
            subtotal: item.quantity * currentUnitPrice
          };
        }
        return item;
      });

      if (priceChanged) {
        setPriceChangeAlert('El total del ticket se actualizó automáticamente debido a cambios en los precios de los productos.');
      }
      return updated;
    });
  }, [products, kits]);

  // Totales
  const totalArticulos = cartItems.length;
  const totalUnidades = cartItems.reduce((acc, it) => acc + it.quantity, 0);
  const totalPagar = cartItems.reduce((acc, it) => acc + it.subtotal, 0);

  // Validación de stock en vivo para todo el ticket agrupado
  const cartValidation = useMemo(() => {
    return validateCartStock(cartItems, products, kits);
  }, [cartItems, products, kits]);

  // Lista de categorías compartidas
  const categoryChips = useMemo(() => {
    if (categories && categories.length > 0) {
      return ['all', ...categories.map((c) => c.name)];
    }
    return ['all', 'Cuadernos', 'Lápices y Bolígrafos', 'Colores y Arte', 'Borradores', 'Adhesivos y pegantes', 'Escolar'];
  }, [categories]);

  // Lista de artículos del catálogo para seleccionar
  const catalogList = useMemo(() => {
    const list: {
      code: string;
      name: string;
      category: string;
      price: number;
      stock: number;
      isKit: boolean;
      components?: { name: string; quantity: number }[];
    }[] = [];

    // Productos individuales
    if (filterType === 'all' || filterType === 'products') {
      products.forEach((p) => {
        list.push({
          code: p.code,
          name: p.name,
          category: p.category,
          price: p.price,
          stock: p.stock,
          isKit: false
        });
      });
    }

    // Kits escolares (solo kits vigentes con disponibilidad calculada según stock de sus componentes)
    if (filterType === 'all' || filterType === 'kits') {
      kits.forEach((k) => {
        const calculatedPrice = getKitCurrentPrice(k, products);
        const availableKits = getKitAvailableUnits(k, products);

        list.push({
          code: k.id,
          name: k.name,
          category: 'Kits escolares',
          price: calculatedPrice,
          stock: availableKits,
          isKit: true,
          components: k.components.map((c) => ({ name: c.name, quantity: c.quantity }))
        });
      });
    }

    return list.filter((item) => {
      const q = searchQuery.toLowerCase().trim();
      const matchSearch = q === '' || item.name.toLowerCase().includes(q) || item.code.toLowerCase().includes(q);
      const matchCat = selectedCategory === 'all' || matchesCategoryFilter(item.category, selectedCategory);
      return matchSearch && matchCat;
    });
  }, [products, kits, filterType, searchQuery, selectedCategory]);

  // Agregar ítem con validación previa de stock
  const handleAddItem = (item: {
    code: string;
    name: string;
    price: number;
    stock: number;
    isKit: boolean;
    components?: { name: string; quantity: number }[];
  }) => {
    setCartWarning(null);

    const existing = cartItems.find((it) => it.code === item.code);
    const candidateCart: SaleItem[] = existing
      ? cartItems.map((it) =>
          it.code === item.code
            ? { ...it, quantity: it.quantity + 1, subtotal: (it.quantity + 1) * it.unitPrice }
            : it
        )
      : [
          ...cartItems,
          {
            code: item.code,
            name: item.name,
            quantity: 1,
            unitPrice: item.price,
            subtotal: item.price,
            isKit: item.isKit,
            components: item.components
          }
        ];

    const validation = validateCartStock(candidateCart, products, kits);
    if (!validation.isValid) {
      const err = validation.errors[0];
      setCartWarning(
        `Existencias insuficientes para agregar "${item.name}": requiere ${err.required} unids., disponible: ${err.available} unids.`
      );
      return;
    }

    setCartItems(candidateCart);
  };

  // Modificar cantidad directamente o mediante incremento con validación estricta de stock
  const handleSetQuantity = (code: string, newQtyRaw: number) => {
    setCartWarning(null);
    const newQty = Math.floor(newQtyRaw);
    if (!Number.isInteger(newQty) || newQty <= 0) {
      setCartWarning('La cantidad debe ser un número entero positivo mayor a cero.');
      return;
    }

    const candidateCart = cartItems.map((it) => {
      if (it.code === code) {
        return { ...it, quantity: newQty, subtotal: newQty * it.unitPrice };
      }
      return it;
    });

    const validation = validateCartStock(candidateCart, products, kits);
    if (!validation.isValid) {
      const err = validation.errors[0];
      setCartWarning(
        `Existencias insuficientes para "${err.name}": requiere ${err.required} unids., disponible: ${err.available} unids.`
      );
      return;
    }

    setCartItems(candidateCart);
  };

  const handleUpdateQuantity = (code: string, delta: number) => {
    setCartWarning(null);
    const item = cartItems.find((it) => it.code === code);
    if (!item) return;

    const newQty = item.quantity + delta;
    if (newQty <= 0) {
      handleRemoveItem(code);
      return;
    }

    handleSetQuantity(code, newQty);
  };

  const handleRemoveItem = (code: string) => {
    setCartWarning(null);
    setCartItems((prev) => prev.filter((it) => it.code !== code));
  };

  const handleClearCart = () => {
    setCartItems([]);
    setCartWarning(null);
    setPriceChangeAlert(null);
    setClearModalOpen(false);
  };

  // Confirmar venta: validación estricta y protección contra doble clic
  const handleConfirmSale = () => {
    if (processing || cartItems.length === 0) return;

    const validation = validateCartStock(cartItems, products, kits);
    if (!validation.isValid) {
      const err = validation.errors[0];
      setCartWarning(
        `Venta bloqueada: no hay existencias suficientes. "${err.name}" requiere ${err.required} unids. (disponible: ${err.available} unids.).`
      );
      return;
    }

    setProcessing(true);

    const result = onCompleteSale({
      items: [...cartItems],
      subtotal: totalPagar,
      total: totalPagar,
      channel: 'Mostrador'
    });

    if (result && !result.success) {
      setCartWarning(result.error || 'No se pudo completar la venta: existencias insuficientes.');
      setProcessing(false);
      return;
    }

    setLastSaleTotal(totalPagar);
    setLastSaleReceipt(`#V-${Date.now().toString().slice(-4)}`);
    setProcessing(false);
    setSuccessModalOpen(true);
  };

  const startNewSale = () => {
    setCartItems([]);
    setCartWarning(null);
    setPriceChangeAlert(null);
    setSuccessModalOpen(false);
  };

  return (
    <div className="flex-1 flex flex-col min-w-0 h-full overflow-hidden bg-surface">
      {/* Encabezado Superior */}
      <header className="h-16 border-b border-surface-variant bg-surface-container-lowest px-6 flex items-center justify-between shrink-0">
        <div className="flex items-center gap-3">
          <span className="material-symbols-outlined text-tertiary text-[20px]">store</span>
          <div className="flex items-center gap-2 text-on-surface-variant text-xs font-semibold">
            <span>Administración</span>
            <span className="text-tertiary">/</span>
            <span className="font-bold text-on-surface">Registrar venta de mostrador</span>
          </div>
        </div>
        <div className="flex items-center gap-6">
          <div className="flex items-center gap-2 text-tertiary text-xs">
            <span className="material-symbols-outlined text-[18px]">location_on</span>
            <span>Torreón El Roble, Ibagué</span>
          </div>
          <div className="h-4 w-px bg-surface-variant hidden sm:block"></div>
          <div className="hidden sm:flex items-center gap-2 text-tertiary text-xs">
            <span className="material-symbols-outlined text-[18px]">calendar_today</span>
            <span>{formattedLong}</span>
          </div>
        </div>
      </header>

      {/* ÁREA PRINCIPAL DIVIDIDA EN 2 COLUMNAS (Responsive) */}
      <main className="flex-1 overflow-y-auto lg:overflow-hidden p-4 lg:p-6 flex flex-col lg:flex-row gap-6">
        {/* COLUMNA IZQUIERDA: Búsqueda y Selección Rápida */}
        <section className="flex-1 flex flex-col min-w-0 bg-surface-container-lowest rounded-xl border border-surface-variant shadow-xs overflow-hidden">
          <div className="p-5 border-b border-surface-variant space-y-4 shrink-0">
            <div className="flex justify-between items-start">
              <div>
                <h1 className="text-xl lg:text-2xl font-bold text-on-surface tracking-tight">Registrar venta</h1>
                <p className="text-xs text-tertiary mt-0.5">
                  Venta presencial de mostrador. Selecciona productos o kits escolares para armar el ticket.
                </p>
              </div>
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#E6F4EA] text-[#137333] text-[11px] font-bold border border-[#ceebd4]">
                <span className="w-2 h-2 rounded-full bg-[#137333] animate-pulse"></span>
                Caja activa #01
              </span>
            </div>

            {/* Barra de Búsqueda Grande */}
            <div className="relative">
              <span className="material-symbols-outlined absolute left-3.5 top-1/2 -translate-y-1/2 text-tertiary text-[22px]">
                search
              </span>
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Buscar por código o nombre de producto / kit..."
                className="w-full pl-11 pr-4 py-2.5 bg-surface-container-low border border-surface-variant rounded-full text-on-surface text-sm focus:outline-none focus:border-primary-container focus:ring-2 focus:ring-primary-container/30 transition-all placeholder:text-tertiary"
              />
            </div>

            {/* Filtros de Tipo y Categorías */}
            <div className="space-y-2.5 pt-1">
              <div className="flex flex-wrap items-center gap-2">
                <button
                  onClick={() => setFilterType('all')}
                  className={`px-3.5 py-1.5 rounded-full text-xs font-bold transition-all cursor-pointer ${
                    filterType === 'all'
                      ? 'bg-primary-container text-on-surface'
                      : 'bg-surface-container-low border border-surface-variant text-on-surface hover:bg-surface-container'
                  }`}
                >
                  Todos ({catalogList.length})
                </button>
                <button
                  onClick={() => setFilterType('products')}
                  className={`px-3.5 py-1.5 rounded-full text-xs font-bold transition-all cursor-pointer ${
                    filterType === 'products'
                      ? 'bg-primary-container text-on-surface'
                      : 'bg-surface-container-low border border-surface-variant text-on-surface hover:bg-surface-container'
                  }`}
                >
                  Productos sueltos
                </button>
                <button
                  onClick={() => setFilterType('kits')}
                  className={`px-3.5 py-1.5 rounded-full text-xs font-bold transition-all cursor-pointer ${
                    filterType === 'kits'
                      ? 'bg-primary-container text-on-surface'
                      : 'bg-surface-container-low border border-surface-variant text-on-surface hover:bg-surface-container'
                  }`}
                >
                  Kits escolares
                </button>
              </div>

              {/* Chips de categorías dinámicos */}
              <div role="group" aria-label="Categorías de venta" className="flex flex-wrap items-center gap-1.5 pb-1 text-tertiary text-xs">
                <span className="text-[11px] uppercase tracking-wider text-outline pr-1 font-bold">Categorías:</span>
                {categoryChips.map((cat) => (
                  <button
                    key={cat}
                    onClick={() => setSelectedCategory(cat)}
                    aria-pressed={selectedCategory === cat}
                    className={`max-w-full shrink-0 whitespace-normal break-words text-left px-2.5 py-1 rounded-lg text-xs font-medium transition-colors cursor-pointer ${
                      selectedCategory === cat
                        ? 'bg-surface-container-highest text-on-surface font-bold border border-outline'
                        : 'bg-surface border border-surface-variant text-on-surface hover:border-outline'
                    }`}
                  >
                    {cat === 'all' ? 'Todas' : cat}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Catálogo Rápido / Grid de Selección (Scrollable) */}
          <div className="flex-1 overflow-y-auto p-4 grid grid-cols-1 sm:grid-cols-2 gap-3.5 content-start bg-surface/30">
            {catalogList.length === 0 ? (
              <div className="col-span-full py-12 text-center text-tertiary space-y-2">
                <span className="material-symbols-outlined text-4xl text-outline">search_off</span>
                <p className="text-sm font-semibold">No se encontraron artículos</p>
                <p className="text-xs">Prueba con otro término de búsqueda o cambia el filtro de categoría.</p>
              </div>
            ) : (
              catalogList.map((item) => {
                const isOut = item.stock <= 0;
                return (
                  <div
                    key={item.code}
                    className={`bg-surface-container-lowest border rounded-xl p-3.5 flex flex-col justify-between hover:shadow-xs transition-shadow ${
                      item.isKit ? 'border-2 border-primary-fixed' : 'border-surface-variant'
                    } ${isOut ? 'opacity-70 bg-surface-container-low/50' : ''}`}
                  >
                    <div>
                      <div className="flex items-start justify-between gap-2 mb-1">
                        <span className="text-xs text-tertiary font-mono">{item.code}</span>
                        {item.isKit ? (
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-[#ffd21f]/30 text-[#705b00] border border-[#ffd21f]/60">
                            KIT
                          </span>
                        ) : (
                          <span className="text-[11px] text-tertiary truncate max-w-[120px]">{item.category}</span>
                        )}
                      </div>
                      <h3 className="font-bold text-sm text-on-surface line-clamp-2 leading-snug">{item.name}</h3>

                      {item.isKit && item.components && (
                        <p className="text-[11px] text-tertiary mt-1 line-clamp-1">
                          Incluye: {item.components.map((c) => `${c.quantity}x ${c.name}`).join(', ')}
                        </p>
                      )}
                    </div>

                    <div className="mt-3 pt-2.5 border-t border-surface-variant/70 flex items-center justify-between">
                      <div>
                        <div className="text-sm font-extrabold text-on-surface">{formatCOP(item.price)}</div>
                        <div className="text-[11px] font-medium">
                          {isOut ? (
                            <span className="text-secondary font-bold">Sin stock</span>
                          ) : (
                            <span className="text-tertiary">Disp: <strong className="text-on-surface">{item.stock} unids.</strong></span>
                          )}
                        </div>
                      </div>

                      <button
                        onClick={() => handleAddItem(item)}
                        disabled={isOut}
                        className={`px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1 transition-all cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed ${
                          isOut
                            ? 'bg-surface-container text-tertiary'
                            : 'bg-primary-container text-on-surface hover:bg-[#e5bd1b] active:scale-95'
                        }`}
                      >
                        <span className="material-symbols-outlined text-[16px]">add</span>
                        <span>{isOut ? 'Agotado' : 'Agregar'}</span>
                      </button>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </section>

        {/* COLUMNA DERECHA: Resumen de la Venta / Ticket de Mostrador */}
        <section className="w-full lg:w-[460px] shrink-0 flex flex-col bg-surface-container-lowest rounded-xl border border-surface-variant shadow-md overflow-hidden">
          {/* Encabezado del Ticket */}
          <div className="p-4 bg-surface-container-low border-b border-surface-variant flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="material-symbols-outlined text-on-surface text-[22px]">receipt</span>
              <h2 className="text-base font-bold text-on-surface">Resumen de venta</h2>
              <span className="px-2.5 py-0.5 rounded-full bg-primary-container text-on-surface text-[11px] font-bold">
                {totalArticulos} artículos ({totalUnidades} unidades)
              </span>
            </div>
            {cartItems.length > 0 && (
              <button
                onClick={() => setClearModalOpen(true)}
                className="text-secondary hover:bg-error-container/40 p-1.5 rounded-lg flex items-center gap-1 text-xs font-semibold transition-colors cursor-pointer"
                title="Limpiar venta"
              >
                <span className="material-symbols-outlined text-[18px]">delete_sweep</span>
                <span>Limpiar</span>
              </button>
            )}
          </div>

          {/* Notificación de actualización de precios */}
          {priceChangeAlert && (
            <div className="bg-amber-50 border-b border-amber-200 px-4 py-2 flex items-center justify-between text-amber-800 text-xs">
              <div className="flex items-center gap-1.5">
                <span className="material-symbols-outlined text-base text-amber-700">info</span>
                <span>{priceChangeAlert}</span>
              </div>
              <button onClick={() => setPriceChangeAlert(null)} className="text-amber-700 hover:text-amber-900 font-bold ml-2">
                ✕
              </button>
            </div>
          )}

          {/* Aviso dinámico de existencias: solo aparece cuando hay artículos y es correcta */}
          {cartItems.length > 0 && cartValidation.isValid && (
            <div className="bg-[#E6F4EA] border-b border-[#ceebd4] px-4 py-2 flex items-center gap-2 text-[#137333]">
              <span className="material-symbols-outlined text-[18px]" style={{ fontVariationSettings: "'FILL' 1" }}>
                check_circle
              </span>
              <span className="text-xs font-semibold">
                Existencias validadas: todos los productos cuentan con inventario suficiente.
              </span>
            </div>
          )}

          {/* Alerta de bloqueo por stock insuficiente en el ticket */}
          {cartItems.length > 0 && !cartValidation.isValid && (
            <div className="bg-rose-50 border-b border-rose-200 px-4 py-2.5 text-rose-800 text-xs space-y-1">
              <div className="flex items-center gap-1.5 font-bold text-rose-900">
                <span className="material-symbols-outlined text-base text-rose-700">error</span>
                <span>Venta bloqueada: existencias insuficientes en inventario</span>
              </div>
              <ul className="list-disc list-inside text-[11px] space-y-0.5 text-rose-800">
                {cartValidation.errors.map((err) => (
                  <li key={err.productCode}>
                    <strong className="font-semibold">{err.name}:</strong> requiere {err.required} unids., disponible: {err.available} unids.
                  </li>
                ))}
              </ul>
            </div>
          )}

          {/* Advertencia temporal de acción */}
          {cartWarning && (
            <div className="bg-amber-50 border-b border-amber-200 px-4 py-2 flex items-center justify-between text-amber-900 text-xs">
              <div className="flex items-center gap-1.5">
                <span className="material-symbols-outlined text-base text-amber-700">warning</span>
                <span>{cartWarning}</span>
              </div>
              <button onClick={() => setCartWarning(null)} className="text-amber-800 font-bold ml-2">
                ✕
              </button>
            </div>
          )}

          {/* Lista de Artículos en el Ticket */}
          <div className="flex-1 overflow-y-auto p-4 space-y-3 divide-y divide-surface-variant/70 min-h-[220px]">
            {cartItems.length === 0 ? (
              <div className="py-12 text-center text-tertiary space-y-2">
                <span className="material-symbols-outlined text-4xl text-outline">shopping_basket</span>
                <p className="text-sm font-semibold">El ticket está vacío</p>
                <p className="text-xs">Selecciona productos o kits escolares a la izquierda para armar la venta.</p>
              </div>
            ) : (
              cartItems.map((item) => (
                <div key={item.code} className="pt-2 first:pt-0 space-y-2">
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <div className="flex items-center gap-1.5">
                        {item.isKit && (
                          <span className="px-1.5 py-0.2 rounded bg-primary-fixed text-on-primary-fixed-variant text-[10px] font-bold">
                            KIT
                          </span>
                        )}
                        <h4 className="text-sm font-bold text-on-surface">{item.name}</h4>
                      </div>
                      <div className="text-tertiary text-xs">{formatCOP(item.unitPrice)} c/u</div>
                    </div>
                    <button
                      onClick={() => handleRemoveItem(item.code)}
                      className="text-tertiary hover:text-secondary p-1 rounded hover:bg-surface-container transition-colors cursor-pointer"
                      title="Retirar ítem"
                    >
                      <span className="material-symbols-outlined text-[18px]">close</span>
                    </button>
                  </div>

                  {/* Componentes incluidos si es Kit */}
                  {item.isKit && item.components && (
                    <div className="p-2.5 rounded-lg bg-surface-container-low border border-surface-variant text-xs space-y-1">
                      <span className="text-xs font-bold text-on-surface block mb-1">
                        Componentes incluidos en el kit (no suman al precio):
                      </span>
                      <ul className="space-y-0.5 text-on-surface-variant text-[11px] leading-relaxed">
                        {item.components.map((comp, idx) => (
                          <li key={idx} className="flex items-center justify-between">
                            <span>• {comp.quantity}x {comp.name}</span>
                            <span className="text-tertiary italic text-[10px]">
                              descuenta {comp.quantity * item.quantity} de inv.
                            </span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}

                  <div className="flex items-center justify-between pt-1">
                    {/* Selector Cantidad */}
                    <div className="flex items-center border border-surface-variant rounded-lg bg-surface overflow-hidden">
                      <button
                        onClick={() => handleUpdateQuantity(item.code, -1)}
                        className="w-8 h-8 flex items-center justify-center hover:bg-surface-container active:bg-surface-variant text-on-surface transition-colors cursor-pointer"
                        title="Disminuir unidad"
                      >
                        <span className="material-symbols-outlined text-[16px]">remove</span>
                      </button>
                      <input
                        type="number"
                        min="1"
                        step="1"
                        value={item.quantity}
                        onChange={(e) => handleSetQuantity(item.code, parseInt(e.target.value, 10) || 1)}
                        className="w-12 h-8 text-center font-bold text-xs text-on-surface bg-transparent outline-none [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none"
                      />
                      <button
                        onClick={() => handleUpdateQuantity(item.code, 1)}
                        className="w-8 h-8 flex items-center justify-center hover:bg-surface-container active:bg-surface-variant text-on-surface transition-colors cursor-pointer"
                        title="Aumentar unidad"
                      >
                        <span className="material-symbols-outlined text-[16px]">add</span>
                      </button>
                    </div>

                    <div className="text-right">
                      <span className="text-xs text-tertiary block leading-none">Subtotal</span>
                      <span className="text-base font-bold text-on-surface">{formatCOP(item.subtotal)}</span>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>

          {/* PIE DEL TICKET */}
          <div className="p-5 bg-surface-container-low border-t border-surface-variant space-y-4">
            <div className="flex items-baseline justify-between">
              <div>
                <span className="text-[11px] text-tertiary uppercase tracking-wider block font-bold">TOTAL A PAGAR</span>
                <span className="text-xs text-tertiary">Efectivo o transacción en mostrador</span>
              </div>
              <div className="text-right">
                <span className="text-2xl font-extrabold text-on-surface">{formatCOP(totalPagar)}</span>
              </div>
            </div>

            <button
              onClick={handleConfirmSale}
              disabled={cartItems.length === 0 || !cartValidation.isValid || processing}
              className="w-full h-12 bg-primary-container hover:bg-[#e5bd1b] active:scale-[0.98] text-on-surface rounded-xl text-base font-bold flex items-center justify-center gap-2 shadow-sm transition-all duration-150 cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed"
            >
              {processing ? (
                <span className="material-symbols-outlined animate-spin text-[22px]">progress_activity</span>
              ) : (
                <>
                  <span className="material-symbols-outlined text-[22px]" style={{ fontVariationSettings: "'FILL' 1" }}>
                    check_circle
                  </span>
                  <span>Confirmar venta</span>
                </>
              )}
            </button>
          </div>
        </section>
      </main>

      {/* MODAL DE CONFIRMACIÓN DE LIMPIEZA */}
      {clearModalOpen && (
        <div className="fixed inset-0 z-50 bg-[#202124]/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-surface-container-lowest max-w-sm w-full rounded-2xl border border-surface-variant p-6 shadow-2xl space-y-4">
            <div className="w-12 h-12 rounded-full bg-error-container text-secondary flex items-center justify-center mx-auto">
              <span className="material-symbols-outlined text-[28px]">delete_sweep</span>
            </div>
            <div className="text-center space-y-1">
              <h3 className="text-base font-bold text-on-surface">¿Vaciar el ticket actual?</h3>
              <p className="text-xs text-tertiary">Se retirarán los artículos agregados. Esta acción no se puede deshacer.</p>
            </div>
            <div className="flex items-center gap-3 pt-2">
              <button
                onClick={() => setClearModalOpen(false)}
                className="flex-1 py-2.5 rounded-lg border border-surface-variant text-on-surface text-xs font-semibold hover:bg-surface-container cursor-pointer"
              >
                Cancelar
              </button>
              <button
                onClick={handleClearCart}
                className="flex-1 py-2.5 rounded-lg bg-secondary text-white text-xs font-bold hover:bg-[#961215] cursor-pointer"
              >
                Sí, vaciar
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL DE ÉXITO DE VENTA */}
      {successModalOpen && (
        <div className="fixed inset-0 z-50 bg-[#202124]/45 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-surface-container-lowest max-w-md w-full rounded-2xl border border-surface-variant shadow-2xl overflow-hidden">
            <div className="bg-primary-container p-6 text-center border-b border-[#e5bd1b]">
              <div className="w-14 h-14 rounded-full bg-surface-container-lowest text-primary shadow-xs flex items-center justify-center mx-auto mb-3">
                <span className="material-symbols-outlined text-[36px]" style={{ fontVariationSettings: "'FILL' 1" }}>
                  verified
                </span>
              </div>
              <h2 className="text-xl font-bold text-on-surface leading-tight">¡Venta registrada con éxito!</h2>
              <p className="text-xs text-on-surface-variant mt-1">El inventario se ha descontado correctamente en el sistema.</p>
            </div>

            <div className="p-6 space-y-4">
              <div className="bg-surface-container-low rounded-xl p-4 border border-surface-variant space-y-2.5 text-xs">
                <div className="flex justify-between items-center">
                  <span className="text-tertiary">Comprobante de mostrador:</span>
                  <span className="font-bold text-on-surface font-mono bg-surface-container-lowest px-2 py-0.5 rounded border border-surface-variant">
                    {lastSaleReceipt}
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-tertiary">Fecha y hora:</span>
                  <span className="font-semibold text-on-surface">Hoy, {dateString} · {timeString}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-tertiary">Atendido por:</span>
                  <span className="font-semibold text-on-surface">Carlos M. (Administrador)</span>
                </div>
                <div className="pt-2 border-t border-surface-variant flex justify-between items-baseline">
                  <span className="text-sm font-bold text-on-surface">Total pagado:</span>
                  <span className="text-lg font-black text-on-surface">{formatCOP(lastSaleTotal)}</span>
                </div>
              </div>

              <div className="flex flex-col gap-2.5 pt-2">
                <button
                  onClick={startNewSale}
                  className="w-full h-11 rounded-xl bg-primary-container hover:bg-[#e5bd1b] text-on-surface font-bold text-sm flex items-center justify-center gap-2 shadow-xs transition-all cursor-pointer"
                >
                  <span className="material-symbols-outlined text-[20px]">add_circle</span>
                  <span>Nueva venta</span>
                </button>
                <button
                  onClick={() => {
                    startNewSale();
                    onGoToReports();
                  }}
                  className="w-full h-11 rounded-xl border border-surface-variant bg-surface-container-lowest hover:bg-surface-container text-on-surface text-sm font-semibold flex items-center justify-center gap-2 transition-colors cursor-pointer"
                >
                  <span className="material-symbols-outlined text-[20px]">receipt_long</span>
                  <span>Ver detalle en Historial y reportes</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
