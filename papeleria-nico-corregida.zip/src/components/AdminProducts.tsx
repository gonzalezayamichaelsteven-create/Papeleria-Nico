import React, { useState } from 'react';
import { Product, Category, formatCOP, matchesCategoryFilter } from '../data/mockData';
import { AdminNotifications } from './AdminNotifications';

interface AdminProductsProps {
  products: Product[];
  categories: Category[];
  onAddProduct: (prod: Product) => void;
  onUpdateProduct: (prod: Product) => void;
  onDeleteProduct: (code: string) => void;
  onAddCategory: (cat: Category) => void;
  onDeleteCategory: (name: string) => void;
  onNavigateToInventory: (productCode?: string) => void;
}

export const AdminProducts: React.FC<AdminProductsProps> = ({
  products,
  categories,
  onAddProduct,
  onUpdateProduct,
  onDeleteProduct,
  onAddCategory,
  onDeleteCategory,
  onNavigateToInventory
}) => {
  const [activeTab, setActiveTab] = useState<'products' | 'categories'>('products');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCatFilter, setSelectedCatFilter] = useState('');

  // Modales
  const [formModalOpen, setFormModalOpen] = useState(false);
  const [formMode, setFormMode] = useState<'create' | 'edit'>('create');
  
  // Form fields
  const [prodCode, setProdCode] = useState('');
  const [prodCategory, setProdCategory] = useState('');
  const [prodName, setProdName] = useState('');
  const [prodDesc, setProdDesc] = useState('');
  const [prodPrice, setProdPrice] = useState<number | ''>('');
  const [prodMinStock, setProdMinStock] = useState<number | ''>(10);
  const [prodInitialStock, setProdInitialStock] = useState<number | ''>(0);
  const [currentEditStock, setCurrentEditStock] = useState<number>(0);

  // Detail Modal
  const [detailProduct, setDetailProduct] = useState<Product | null>(null);

  // Delete Modal
  const [deleteProductTarget, setDeleteProductTarget] = useState<Product | null>(null);
  const [deleteIsBlocked, setDeleteIsBlocked] = useState(false);

  // Category restriction modal
  const [categoryRestrictionMsg, setCategoryRestrictionMsg] = useState<string | null>(null);

  // New Category Modal
  const [newCatModalOpen, setNewCatModalOpen] = useState(false);
  const [newCatName, setNewCatName] = useState('');
  const [newCatDesc, setNewCatDesc] = useState('');

  const filteredProducts = products.filter((p) => {
    const q = searchQuery.toLowerCase().trim();
    const matchSearch = q === '' || p.code.toLowerCase().includes(q) || p.name.toLowerCase().includes(q);
    const matchCat = selectedCatFilter === '' || p.category === selectedCatFilter;
    return matchSearch && matchCat;
  });

  const openCreateModal = () => {
    setFormMode('create');
    setProdCode('');
    setProdCategory(categories[0]?.name || 'Escolar');
    setProdName('');
    setProdDesc('');
    setProdPrice('');
    setProdMinStock(10);
    setProdInitialStock(0);
    setFormModalOpen(true);
  };

  const openEditModal = (p: Product) => {
    setFormMode('edit');
    setProdCode(p.code);
    setProdCategory(p.category);
    setProdName(p.name);
    setProdDesc(p.description);
    setProdPrice(p.price);
    setProdMinStock(p.minStock);
    setCurrentEditStock(p.stock);
    setFormModalOpen(true);
  };

  const handleSaveProduct = (e: React.FormEvent) => {
    e.preventDefault();
    if (!prodCode || !prodName || prodPrice === '') return;

    if (formMode === 'create') {
      const newP: Product = {
        code: prodCode.toUpperCase().trim(),
        name: prodName.trim(),
        category: prodCategory,
        price: Number(prodPrice),
        stock: Number(prodInitialStock) || 0,
        minStock: Number(prodMinStock) || 10,
        description: prodDesc,
        image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBbYQIlJIGi0a4bvq9sLUHLK0AUU0gMs4LQWqvTbNzDraRemd0_VE6t8BX4W4SiPqgSyJCgYKPbpxlJfE1IsJ4NIAsu3B_UbmKU3D9JTMTf67nI1beewaCtlUZ4Hg9G1VeEcgg13yEvvMMHR1gEfbvyNz7gl0rBFWJVweASz1tNkM996O6YzciX7u9juX7ztYgresUCD3XPYfyCCxf9gJwTTTN1IGPSRJKS4qj0Q097sKuEbWl9Dd3kZg'
      };
      onAddProduct(newP);
    } else {
      const updatedP: Product = {
        code: prodCode,
        name: prodName.trim(),
        category: prodCategory,
        price: Number(prodPrice),
        stock: currentEditStock,
        minStock: Number(prodMinStock) || 10,
        description: prodDesc,
        image: products.find(p => p.code === prodCode)?.image || ''
      };
      onUpdateProduct(updatedP);
    }
    setFormModalOpen(false);
  };

  const handleDeleteClick = (p: Product) => {
    // If it's linked to Kits or core sales, show the blocked warning as seen in the HTML template
    const isCore = ['CUA-100-CD', 'COL-PEQ-PGA', 'COL-MAD-12C', 'REG-MET-30'].includes(p.code);
    setDeleteProductTarget(p);
    setDeleteIsBlocked(isCore);
  };

  const handleConfirmDelete = () => {
    if (deleteProductTarget && !deleteIsBlocked) {
      onDeleteProduct(deleteProductTarget.code);
    }
    setDeleteProductTarget(null);
  };

  const handleCategoryDeleteAttempt = (cat: Category) => {
    const realCount = products.filter((p) => matchesCategoryFilter(p.category, cat.name)).length;
    if (realCount > 0) {
      setCategoryRestrictionMsg(
        `No se puede eliminar la categoría "${cat.name}" porque contiene ${realCount} ${realCount === 1 ? 'producto asociado' : 'productos asociados'} en el inventario comercial.`
      );
    } else {
      if (confirm(`¿Deseas eliminar la categoría vacía "${cat.name}"?`)) {
        onDeleteCategory(cat.name);
      }
    }
  };

  const handleCreateCategory = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCatName.trim()) return;
    onAddCategory({
      name: newCatName.trim(),
      description: newCatDesc.trim() || 'Categoría de papelería',
      productCount: 0,
      icon: 'folder'
    });
    setNewCatName('');
    setNewCatDesc('');
    setNewCatModalOpen(false);
  };

  return (
    <div className="flex-1 flex flex-col min-w-0 h-full overflow-hidden bg-surface">
      {/* Top Administrative Header */}
      <header className="h-16 px-6 lg:px-8 bg-surface-container-lowest border-b border-surface-variant flex items-center justify-between flex-shrink-0">
        <div className="flex items-center gap-3">
          <div className="flex items-center text-on-surface-variant text-xs font-semibold gap-1.5">
            <span>Administración</span>
            <span className="material-symbols-outlined text-[14px]">chevron_right</span>
            <span className="font-bold text-on-surface">Catálogo de productos</span>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <div className="hidden lg:flex items-center gap-2 px-3 py-1 rounded-full bg-surface-container border border-surface-variant text-xs text-on-surface">
            <span className="w-2 h-2 rounded-full bg-primary"></span>
            <span>Sede: <strong>Torreón El Roble, Ibagué</strong></span>
          </div>
          <div className="h-6 w-px bg-surface-variant hidden lg:block"></div>
          <AdminNotifications products={products} onNavigateToProduct={onNavigateToInventory} />
        </div>
      </header>

      {/* Catalog Content Canvas */}
      <div className="flex-1 overflow-y-auto custom-scroll p-6 lg:p-8 space-y-6">
        {/* Page Title & Primary Segment Switcher */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-primary-fixed text-on-primary-fixed border border-outline-variant">
                Control maestro
              </span>
              <span className="text-xs text-on-surface-variant">Actualizado hoy, 04:30 PM</span>
            </div>
            <h1 className="text-2xl lg:text-3xl font-bold text-on-surface tracking-tight">Productos y categorías</h1>
            <p className="text-sm text-on-surface-variant mt-0.5">
              Administra el inventario comercial, referencias escolares, precios en COP y agrupación por secciones.
            </p>
          </div>

          {/* Dynamic Primary Tabs */}
          <div className="inline-flex p-1 bg-surface-container-high rounded-xl border border-surface-variant self-start md:self-auto shadow-inner">
            <button
              onClick={() => setActiveTab('products')}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-bold transition-all cursor-pointer ${
                activeTab === 'products'
                  ? 'bg-surface-container-lowest text-on-surface shadow-xs'
                  : 'text-on-surface-variant hover:text-on-surface'
              }`}
            >
              <span className="material-symbols-outlined text-[18px]">inventory</span>
              <span>Productos</span>
              <span className="ml-1 px-2 py-0.5 rounded-full text-xs bg-primary-container text-on-surface font-extrabold">
                {products.length}
              </span>
            </button>
            <button
              onClick={() => setActiveTab('categories')}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-bold transition-all cursor-pointer ${
                activeTab === 'categories'
                  ? 'bg-surface-container-lowest text-on-surface shadow-xs'
                  : 'text-on-surface-variant hover:text-on-surface'
              }`}
            >
              <span className="material-symbols-outlined text-[18px]">folder_copy</span>
              <span>Categorías</span>
              <span className="ml-1 px-2 py-0.5 rounded-full text-xs bg-surface-variant text-on-surface-variant font-bold">
                {categories.length}
              </span>
            </button>
          </div>
        </div>

        {/* ===================================================================== */}
        {/* TAB 1: PRODUCTOS VIEW                                                 */}
        {/* ===================================================================== */}
        {activeTab === 'products' && (
          <section className="space-y-4">
            {/* Products Toolbar */}
            <div className="bg-surface-container-lowest p-4 rounded-xl border border-surface-variant shadow-xs flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
              <div className="flex flex-1 flex-col sm:flex-row items-stretch sm:items-center gap-3 min-w-0">
                {/* Search bar with clear button */}
                <div className="relative flex-1 max-w-md">
                  <span className="material-symbols-outlined absolute left-3.5 top-1/2 -translate-y-1/2 text-outline text-[20px]">search</span>
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Buscar por nombre o código único..."
                    className="w-full pl-10 pr-9 py-2.5 text-sm text-on-surface bg-surface-container-lowest border border-surface-variant rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-container focus:border-on-surface transition-all placeholder:text-outline"
                  />
                  {searchQuery && (
                    <button
                      onClick={() => setSearchQuery('')}
                      className="absolute right-2.5 top-1/2 -translate-y-1/2 text-outline hover:text-on-surface p-1 rounded"
                      type="button"
                    >
                      <span className="material-symbols-outlined text-[16px]">close</span>
                    </button>
                  )}
                </div>

                {/* Category filter dropdown */}
                <div className="relative w-full sm:w-56">
                  <select
                    value={selectedCatFilter}
                    onChange={(e) => setSelectedCatFilter(e.target.value)}
                    className="w-full py-2.5 pl-3.5 pr-10 text-sm font-medium text-on-surface bg-surface-container-lowest border border-surface-variant rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-container focus:border-on-surface transition-all appearance-none cursor-pointer"
                  >
                    <option value="">Todas las categorías</option>
                    {categories.map((c) => (
                      <option key={c.name} value={c.name}>{c.name}</option>
                    ))}
                  </select>
                  <span className="material-symbols-outlined pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-outline text-[20px]">expand_more</span>
                </div>
              </div>

              {/* Add Product Primary Button */}
              <button
                onClick={openCreateModal}
                className="flex items-center justify-center gap-2 px-5 py-2.5 rounded-lg bg-primary-container text-on-surface hover:bg-[#e5bd1b] active:scale-[0.98] text-sm font-bold shadow-xs transition-all flex-shrink-0 cursor-pointer"
                type="button"
              >
                <span className="material-symbols-outlined text-[20px] font-bold">add_circle</span>
                <span>+ Nuevo producto</span>
              </button>
            </div>

            {/* Products Table Card */}
            <div className="bg-surface-container-lowest rounded-xl border border-surface-variant shadow-xs overflow-hidden flex flex-col">
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="bg-surface-container-low border-b border-surface-variant text-xs font-semibold text-on-surface-variant">
                      <th className="py-3 px-4 w-14 text-center">Foto</th>
                      <th className="py-3 px-4 font-bold">Código único</th>
                      <th className="py-3 px-4 font-bold">Nombre del producto</th>
                      <th className="py-3 px-4 font-bold">Categoría</th>
                      <th className="py-3 px-4 font-bold text-right">Precio venta</th>
                      <th className="py-3 px-4 font-bold text-center">Stock / Mínimo</th>
                      <th className="py-3 px-4 font-bold text-center">Estado</th>
                      <th className="py-3 px-4 font-bold text-right">Acciones</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-surface-variant text-sm">
                    {filteredProducts.map((p) => {
                      const isLow = p.stock > 0 && p.stock <= p.minStock;
                      const isOut = p.stock === 0;

                      return (
                        <tr key={p.code} className="hover:bg-surface-container-low/60 transition-colors">
                          <td className="py-3.5 px-4 text-center">
                            <div className="w-12 h-12 rounded-lg bg-surface border border-surface-variant p-1 flex items-center justify-center overflow-hidden mx-auto shadow-xs">
                              <img src={p.image} alt={p.name} className="w-full h-full object-cover rounded" />
                            </div>
                          </td>
                          <td className="py-3.5 px-4 font-semibold text-on-surface font-mono text-xs">
                            {p.code}
                          </td>
                          <td className="py-3.5 px-4">
                            <span className="font-bold text-on-surface block">{p.name}</span>
                            <span className="text-xs text-on-surface-variant line-clamp-1">{p.description}</span>
                          </td>
                          <td className="py-3.5 px-4">
                            <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold bg-surface-container-high text-on-surface border border-surface-variant">
                              {p.category}
                            </span>
                          </td>
                          <td className="py-3.5 px-4 text-right font-bold text-on-surface">
                            {formatCOP(p.price)}
                          </td>
                          <td className="py-3.5 px-4 text-center">
                            <div className="inline-flex items-center gap-1.5 font-semibold text-xs">
                              <span className={isOut ? 'text-secondary font-bold' : isLow ? 'text-amber-800 font-bold' : 'text-on-surface'}>
                                {p.stock} unids
                              </span>
                              <span className="text-on-surface-variant text-[11px] font-normal">/ Mín: {p.minStock}</span>
                            </div>
                          </td>
                          <td className="py-3.5 px-4 text-center">
                            {isOut ? (
                              <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-[#F1F3F4] text-[#5F6368]">
                                <span className="w-1.5 h-1.5 rounded-full bg-[#5F6368]"></span>
                                Agotado
                              </span>
                            ) : isLow ? (
                              <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-[#FDE8E8] text-[#C62828]">
                                <span className="w-1.5 h-1.5 rounded-full bg-[#C62828]"></span>
                                Bajo stock
                              </span>
                            ) : (
                              <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-[#E6F4EA] text-[#137333]">
                                <span className="w-1.5 h-1.5 rounded-full bg-[#137333]"></span>
                                Disponible
                              </span>
                            )}
                          </td>
                          <td className="py-3.5 px-4 text-right">
                            <div className="flex items-center justify-end gap-1">
                              <button
                                onClick={() => setDetailProduct(p)}
                                className="p-1.5 text-on-surface-variant hover:text-on-surface hover:bg-surface-container rounded-lg transition-colors cursor-pointer"
                                title="Ver detalle"
                                type="button"
                              >
                                <span className="material-symbols-outlined text-[20px]">visibility</span>
                              </button>
                              <button
                                onClick={() => openEditModal(p)}
                                className="p-1.5 text-on-surface-variant hover:text-primary hover:bg-surface-container rounded-lg transition-colors cursor-pointer"
                                title="Editar"
                                type="button"
                              >
                                <span className="material-symbols-outlined text-[20px]">edit</span>
                              </button>
                              <button
                                onClick={() => handleDeleteClick(p)}
                                className="p-1.5 text-on-surface-variant hover:text-secondary hover:bg-surface-container rounded-lg transition-colors cursor-pointer"
                                title="Eliminar"
                                type="button"
                              >
                                <span className="material-symbols-outlined text-[20px]">delete</span>
                              </button>
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>

              {/* Pagination Footer */}
              <div className="p-4 bg-surface-container-low/50 border-t border-surface-variant flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-on-surface-variant">
                <div className="flex items-center gap-2">
                  <span>Mostrando <strong>1-{filteredProducts.length}</strong> de <strong>{products.length}</strong> productos registrados</span>
                  <span className="text-outline">•</span>
                  <span>Sede Torreón El Roble, Ibagué</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <button className="w-8 h-8 rounded-lg bg-primary-container text-on-surface font-bold text-xs flex items-center justify-center shadow-xs">1</button>
                  <button className="w-8 h-8 rounded-lg bg-surface-container-lowest border border-surface-variant text-on-surface hover:bg-surface transition-colors flex items-center justify-center">2</button>
                </div>
              </div>
            </div>
          </section>
        )}

        {/* ===================================================================== */}
        {/* TAB 2: CATEGORÍAS VIEW                                                */}
        {/* ===================================================================== */}
        {activeTab === 'categories' && (
          <section className="space-y-4">
            <div className="bg-surface-container-lowest p-4 rounded-xl border border-surface-variant shadow-xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <span className="material-symbols-outlined text-primary text-[28px]">folder_special</span>
                <div>
                  <h2 className="text-lg font-bold text-on-surface">Categorías del catálogo</h2>
                  <p className="text-xs text-on-surface-variant">Clasificación oficial para organización en vitrina y búsquedas rápidas.</p>
                </div>
              </div>
              <button
                onClick={() => setNewCatModalOpen(true)}
                className="flex items-center gap-2 px-5 py-2.5 rounded-lg bg-primary-container text-on-surface hover:bg-[#e5bd1b] active:scale-[0.98] text-sm font-bold shadow-xs transition-all cursor-pointer"
                type="button"
              >
                <span className="material-symbols-outlined text-[20px] font-bold">create_new_folder</span>
                <span>+ Nueva categoría</span>
              </button>
            </div>

            <div className="bg-surface-container-lowest rounded-xl border border-surface-variant shadow-xs overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="bg-surface-container-low border-b border-surface-variant text-xs font-semibold text-on-surface-variant">
                      <th className="py-3.5 px-5 font-bold">Nombre de la categoría</th>
                      <th className="py-3.5 px-5 font-bold">Descripción</th>
                      <th className="py-3.5 px-5 font-bold text-center">Productos asociados</th>
                      <th className="py-3.5 px-5 font-bold text-right">Acciones</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-surface-variant text-sm">
                    {categories.map((cat) => (
                      <tr key={cat.name} className="hover:bg-surface-container-low/60 transition-colors">
                        <td className="py-4 px-5">
                          <div className="flex items-center gap-2.5">
                            <span className="p-2 rounded-lg bg-surface-container text-primary">
                              <span className="material-symbols-outlined text-[20px]">{cat.icon || 'folder'}</span>
                            </span>
                            <span className="font-bold text-on-surface">{cat.name}</span>
                          </div>
                        </td>
                        <td className="py-4 px-5 text-on-surface-variant max-w-md text-xs">
                          {cat.description}
                        </td>
                        <td className="py-4 px-5 text-center">
                          {(() => {
                            const count = products.filter((p) => matchesCategoryFilter(p.category, cat.name)).length;
                            return (
                              <span className={`inline-flex items-center px-3 py-1 rounded-full text-xs font-bold ${
                                count > 0 ? 'bg-primary-container text-on-surface' : 'bg-surface-container-high text-on-surface'
                              }`}>
                                {count} {count === 1 ? 'producto' : 'productos'}
                              </span>
                            );
                          })()}
                        </td>
                        <td className="py-4 px-5 text-right">
                          <div className="flex items-center justify-end gap-1">
                            <button
                              onClick={() => handleCategoryDeleteAttempt(cat)}
                              className="p-2 text-on-surface-variant hover:text-secondary rounded-lg hover:bg-surface-container transition-colors cursor-pointer"
                              title="Eliminar categoría"
                              type="button"
                            >
                              <span className="material-symbols-outlined text-[20px]">delete</span>
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </section>
        )}
      </div>

      {/* ========================================================================= */}
      {/* MODAL 1: CREAR / EDITAR PRODUCTO                                          */}
      {/* ========================================================================= */}
      {formModalOpen && (
        <div className="fixed inset-0 z-50 overflow-y-auto flex items-center justify-center p-4 bg-inverse-surface/40 backdrop-blur-xs">
          <div className="relative w-full max-w-2xl bg-surface-container-lowest rounded-2xl border border-surface-variant shadow-2xl overflow-hidden">
            {/* Modal Header */}
            <div className="px-6 py-4 border-b border-surface-variant flex items-center justify-between bg-surface-container-low/50">
              <div className="flex items-center gap-2.5">
                <span className="p-2 rounded-lg bg-primary-container text-on-surface">
                  <span className="material-symbols-outlined text-[22px]">
                    {formMode === 'create' ? 'add_box' : 'edit_note'}
                  </span>
                </span>
                <div>
                  <h3 className="text-lg font-bold text-on-surface">
                    {formMode === 'create' ? 'Crear nuevo producto' : 'Editar producto'}
                  </h3>
                  <p className="text-xs text-on-surface-variant">
                    {formMode === 'create'
                      ? 'Ingresa la información detallada para registrar la referencia en catálogo.'
                      : 'Modifica precios, descripción y umbrales de alerta.'}
                  </p>
                </div>
              </div>
              <button
                onClick={() => setFormModalOpen(false)}
                className="p-1.5 rounded-lg text-outline hover:text-on-surface hover:bg-surface-container transition-colors"
                type="button"
              >
                <span className="material-symbols-outlined text-[22px]">close</span>
              </button>
            </div>

            {/* Form Body */}
            <form onSubmit={handleSaveProduct} className="p-6 space-y-4 max-h-[75vh] overflow-y-auto custom-scroll">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Código único */}
                <div>
                  <label className="block text-sm font-bold text-on-surface mb-1">
                    Código único de referencia <span className="text-secondary">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    readOnly={formMode === 'edit'}
                    value={prodCode}
                    onChange={(e) => setProdCode(e.target.value)}
                    placeholder="Ej: CUA-100-CD"
                    className={`w-full h-11 px-3 bg-surface-container-lowest border border-surface-variant rounded-lg font-mono text-sm focus:ring-2 focus:ring-primary-container focus:border-on-surface outline-none transition-all uppercase ${
                      formMode === 'edit' ? 'bg-surface-container-low cursor-not-allowed' : ''
                    }`}
                  />
                  <span className="text-[11px] text-on-surface-variant mt-1 block">Debe ser único en el sistema de ventas.</span>
                </div>

                {/* Categoría */}
                <div>
                  <label className="block text-sm font-bold text-on-surface mb-1">
                    Categoría <span className="text-secondary">*</span>
                  </label>
                  <div className="relative">
                    <select
                      required
                      value={prodCategory}
                      onChange={(e) => setProdCategory(e.target.value)}
                      className="w-full h-11 px-3 bg-surface-container-lowest border border-surface-variant rounded-lg text-sm focus:ring-2 focus:ring-primary-container focus:border-on-surface outline-none transition-all appearance-none cursor-pointer"
                    >
                      {categories.map((c) => (
                        <option key={c.name} value={c.name}>{c.name}</option>
                      ))}
                    </select>
                    <span className="material-symbols-outlined pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-outline text-[18px]">expand_more</span>
                  </div>
                </div>
              </div>

              {/* Nombre del producto */}
              <div>
                <label className="block text-sm font-bold text-on-surface mb-1">
                  Nombre comercial del producto <span className="text-secondary">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={prodName}
                  onChange={(e) => setProdName(e.target.value)}
                  placeholder="Ej: Cuaderno Cuadriculado 100 Hojas Norma Kiut"
                  className="w-full h-11 px-3 bg-surface-container-lowest border border-surface-variant rounded-lg text-sm focus:ring-2 focus:ring-primary-container focus:border-on-surface outline-none transition-all"
                />
              </div>

              {/* Descripción breve */}
              <div>
                <label className="block text-sm font-bold text-on-surface mb-1">
                  Descripción breve <span className="text-secondary">*</span>
                </label>
                <textarea
                  required
                  rows={2}
                  value={prodDesc}
                  onChange={(e) => setProdDesc(e.target.value)}
                  placeholder="Especificaciones, marca, presentación o detalles para los clientes..."
                  className="w-full p-3 bg-surface-container-lowest border border-surface-variant rounded-lg text-sm focus:ring-2 focus:ring-primary-container focus:border-on-surface outline-none transition-all resize-none"
                />
              </div>

              {/* Precio y Stock Mínimo */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Precio COP */}
                <div>
                  <label className="block text-sm font-bold text-on-surface mb-1">
                    Precio de venta al público <span className="text-secondary">*</span>
                  </label>
                  <div className="relative">
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 font-bold text-on-surface-variant text-sm">$</span>
                    <input
                      type="number"
                      required
                      min={50}
                      step={50}
                      value={prodPrice}
                      onChange={(e) => setProdPrice(e.target.value ? Number(e.target.value) : '')}
                      placeholder="8500"
                      className="w-full h-11 pl-7 pr-14 bg-surface-container-lowest border border-surface-variant rounded-lg text-sm font-bold focus:ring-2 focus:ring-primary-container focus:border-on-surface outline-none transition-all"
                    />
                    <span className="absolute right-3 top-1/2 -translate-y-1/2 font-bold text-xs text-on-surface-variant">COP</span>
                  </div>
                </div>

                {/* Stock mínimo */}
                <div>
                  <label className="block text-sm font-bold text-on-surface mb-1">
                    Stock mínimo de alerta <span className="text-secondary">*</span>
                  </label>
                  <input
                    type="number"
                    required
                    min={0}
                    value={prodMinStock}
                    onChange={(e) => setProdMinStock(e.target.value ? Number(e.target.value) : '')}
                    placeholder="10"
                    className="w-full h-11 px-3 bg-surface-container-lowest border border-surface-variant rounded-lg text-sm focus:ring-2 focus:ring-primary-container focus:border-on-surface outline-none transition-all"
                  />
                </div>
              </div>

              {/* Stock Inicial (CREACIÓN) vs Solo Lectura (EDICIÓN) */}
              {formMode === 'create' ? (
                <div className="p-4 rounded-xl bg-surface-container-low border border-surface-variant space-y-1.5">
                  <label className="block text-sm font-bold text-on-surface">
                    Cantidad inicial ingresada a bodega <span className="text-secondary">*</span>
                  </label>
                  <input
                    type="number"
                    min={0}
                    value={prodInitialStock}
                    onChange={(e) => setProdInitialStock(e.target.value ? Number(e.target.value) : 0)}
                    className="w-full h-11 px-3 bg-surface-container-lowest border border-surface-variant rounded-lg text-sm focus:ring-2 focus:ring-primary-container focus:border-on-surface outline-none transition-all"
                  />
                  <p className="text-[12px] text-on-surface-variant">
                    Se registrará automáticamente como el primer asiento de entrada en el módulo de Inventario.
                  </p>
                </div>
              ) : (
                <div className="p-4 rounded-xl bg-surface-container border border-surface-variant space-y-2">
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="text-xs text-on-surface-variant">Existencias actuales registradas:</span>
                      <p className="text-lg font-bold text-on-surface">{currentEditStock} unidades</p>
                    </div>
                    <span className="px-2.5 py-1 rounded bg-surface-variant text-[11px] font-bold text-on-surface uppercase">
                      Solo lectura
                    </span>
                  </div>
                  <p className="text-xs text-on-surface-variant border-t border-surface-variant pt-2">
                    Por integridad contable y trazabilidad, los ajustes físicos deben realizarse en Inventario.
                  </p>
                </div>
              )}

              {/* Dialog Footer Actions */}
              <div className="pt-4 border-t border-surface-variant flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setFormModalOpen(false)}
                  className="px-5 py-2.5 rounded-lg border border-surface-variant bg-surface-container-lowest text-on-surface text-sm font-semibold hover:bg-surface-container transition-colors"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 rounded-lg bg-primary-container text-on-surface hover:bg-[#e5bd1b] active:scale-[0.98] text-sm font-bold shadow-xs transition-all flex items-center gap-2 cursor-pointer"
                >
                  <span className="material-symbols-outlined text-[18px]">check_circle</span>
                  <span>{formMode === 'create' ? 'Guardar producto' : 'Actualizar cambios'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 2: DETALLE COMPLETO DE PRODUCTO                                     */}
      {/* ========================================================================= */}
      {detailProduct && (
        <div className="fixed inset-0 z-50 overflow-y-auto flex items-center justify-center p-4 bg-inverse-surface/40 backdrop-blur-xs">
          <div className="relative w-full max-w-lg bg-surface-container-lowest rounded-2xl border border-surface-variant shadow-2xl overflow-hidden p-6 space-y-5">
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-2">
                <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-primary-container text-on-surface font-mono">
                  {detailProduct.code}
                </span>
                <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-surface-container text-on-surface-variant">
                  {detailProduct.category}
                </span>
              </div>
              <button
                onClick={() => setDetailProduct(null)}
                className="p-1 rounded-lg text-outline hover:text-on-surface"
                type="button"
              >
                <span className="material-symbols-outlined text-[20px]">close</span>
              </button>
            </div>

            <div className="w-full h-48 rounded-xl bg-surface border border-surface-variant flex items-center justify-center overflow-hidden">
              <img src={detailProduct.image} alt={detailProduct.name} className="w-full h-full object-contain" />
            </div>

            <div>
              <h3 className="text-xl font-bold text-on-surface">{detailProduct.name}</h3>
              <p className="text-sm text-on-surface-variant mt-1.5">{detailProduct.description}</p>
            </div>

            <div className="grid grid-cols-2 gap-3 p-4 rounded-xl bg-surface-container-low border border-surface-variant">
              <div>
                <span className="text-xs text-on-surface-variant block">Precio sugerido venta:</span>
                <span className="text-lg font-bold text-on-surface">{formatCOP(detailProduct.price)}</span>
              </div>
              <div>
                <span className="text-xs text-on-surface-variant block">Disponibilidad en vitrina:</span>
                <div className="flex items-center gap-1.5 mt-0.5">
                  <span className={`w-2 h-2 rounded-full ${detailProduct.stock > 0 ? 'bg-emerald-500' : 'bg-red-500'}`}></span>
                  <span className="font-bold text-on-surface text-sm">{detailProduct.stock} unidades</span>
                </div>
                <span className="text-[11px] text-on-surface-variant">Umbral mínimo: {detailProduct.minStock} unids</span>
              </div>
            </div>

            <div className="flex justify-end pt-2">
              <button
                onClick={() => setDetailProduct(null)}
                className="w-full py-2.5 rounded-lg bg-surface-container text-on-surface text-sm font-bold hover:bg-surface-variant transition-colors"
                type="button"
              >
                Cerrar detalle
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 3: CONFIRMACIÓN DE ELIMINACIÓN DE PRODUCTO                          */}
      {/* ========================================================================= */}
      {deleteProductTarget && (
        <div className="fixed inset-0 z-50 overflow-y-auto flex items-center justify-center p-4 bg-inverse-surface/40 backdrop-blur-xs">
          <div className="relative w-full max-w-md bg-surface-container-lowest rounded-2xl border border-surface-variant shadow-2xl p-6 space-y-4">
            <div className="w-12 h-12 rounded-xl bg-error-container text-error flex items-center justify-center">
              <span className="material-symbols-outlined text-[28px]">warning</span>
            </div>
            <div>
              <h3 className="text-lg font-bold text-on-surface">¿Eliminar producto del catálogo?</h3>
              <p className="text-sm text-on-surface-variant mt-1">
                Referencia: [{deleteProductTarget.code}] - {deleteProductTarget.name}
              </p>
            </div>

            {deleteIsBlocked ? (
              <div className="p-3.5 rounded-xl bg-error-container/40 border border-error/20 text-xs space-y-2">
                <div className="flex gap-2">
                  <span className="material-symbols-outlined text-secondary text-[20px] flex-shrink-0">block</span>
                  <p className="text-on-surface font-medium leading-snug">
                    No es posible eliminar este producto porque está vinculado a registros de venta o kits escolares activos. Para mantener la integridad histórica, debes deshabilitarlo o retirarlo del kit correspondiente.
                  </p>
                </div>
              </div>
            ) : (
              <div className="text-sm text-on-surface-variant">
                Esta acción removerá la referencia permanentemente del inventario comercial y de las listas de precios.
              </div>
            )}

            <div className="pt-3 flex items-center justify-end gap-3">
              <button
                onClick={() => setDeleteProductTarget(null)}
                className="px-4 py-2.5 rounded-lg border border-surface-variant bg-surface-container-lowest text-on-surface text-sm font-semibold hover:bg-surface-container transition-colors"
                type="button"
              >
                {deleteIsBlocked ? 'Entendido, volver' : 'Cancelar'}
              </button>
              {!deleteIsBlocked && (
                <button
                  onClick={handleConfirmDelete}
                  className="px-4 py-2.5 rounded-lg bg-secondary text-white text-sm font-bold hover:bg-[#961215] transition-colors shadow-xs"
                  type="button"
                >
                  Confirmar eliminación
                </button>
              )}
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 4: ALERTA DE RESTRICCIÓN DE ELIMINACIÓN DE CATEGORÍA               */}
      {/* ========================================================================= */}
      {categoryRestrictionMsg && (
        <div className="fixed inset-0 z-50 overflow-y-auto flex items-center justify-center p-4 bg-inverse-surface/40 backdrop-blur-xs">
          <div className="relative w-full max-w-md bg-surface-container-lowest rounded-2xl border border-surface-variant shadow-2xl p-6 space-y-4">
            <div className="w-12 h-12 rounded-xl bg-error-container text-error flex items-center justify-center">
              <span className="material-symbols-outlined text-[28px]">folder_off</span>
            </div>
            <div>
              <h3 className="text-lg font-bold text-on-surface">Operación no permitida</h3>
              <p className="text-sm text-on-surface-variant mt-2">
                {categoryRestrictionMsg}
              </p>
            </div>
            <div className="p-3 bg-surface-container rounded-xl text-xs text-on-surface-variant">
              Para eliminar una categoría, primero debes reasignar o eliminar todos los productos vinculados a otra categoría del catálogo.
            </div>
            <div className="pt-2 flex justify-end">
              <button
                onClick={() => setCategoryRestrictionMsg(null)}
                className="px-5 py-2.5 rounded-lg bg-primary-container text-on-surface text-sm font-bold hover:bg-[#e5bd1b] transition-colors"
                type="button"
              >
                Comprendido
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 5: NUEVA CATEGORÍA                                                  */}
      {/* ========================================================================= */}
      {newCatModalOpen && (
        <div className="fixed inset-0 z-50 overflow-y-auto flex items-center justify-center p-4 bg-inverse-surface/40 backdrop-blur-xs">
          <div className="relative w-full max-w-md bg-surface-container-lowest rounded-2xl border border-surface-variant shadow-2xl p-6 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-bold text-on-surface">Crear nueva categoría</h3>
              <button onClick={() => setNewCatModalOpen(false)} className="p-1 rounded-lg text-outline">
                <span className="material-symbols-outlined text-xl">close</span>
              </button>
            </div>
            <form onSubmit={handleCreateCategory} className="space-y-4">
              <div>
                <label className="block text-sm font-bold text-on-surface mb-1">Nombre de la categoría *</label>
                <input
                  type="text"
                  required
                  value={newCatName}
                  onChange={(e) => setNewCatName(e.target.value)}
                  placeholder="Ej: Archivo y carpetas"
                  className="w-full h-11 px-3 bg-surface-container-lowest border border-surface-variant rounded-lg text-sm focus:ring-2 focus:ring-primary-container outline-none"
                />
              </div>
              <div>
                <label className="block text-sm font-bold text-on-surface mb-1">Descripción</label>
                <textarea
                  rows={2}
                  value={newCatDesc}
                  onChange={(e) => setNewCatDesc(e.target.value)}
                  placeholder="Detalles de los productos incluidos..."
                  className="w-full p-3 bg-surface-container-lowest border border-surface-variant rounded-lg text-sm focus:ring-2 focus:ring-primary-container outline-none resize-none"
                />
              </div>
              <div className="pt-3 flex justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setNewCatModalOpen(false)}
                  className="px-4 py-2 rounded-lg border border-surface-variant text-sm font-semibold"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-lg bg-primary-container text-on-surface font-bold text-sm hover:bg-[#e5bd1b]"
                >
                  Guardar categoría
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
