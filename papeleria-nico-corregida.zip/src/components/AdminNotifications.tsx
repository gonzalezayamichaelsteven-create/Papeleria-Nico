import React, { useState, useRef, useEffect } from 'react';
import { Product } from '../data/mockData';

interface AdminNotificationsProps {
  products: Product[];
  onNavigateToProduct: (productCode?: string) => void;
}

export const AdminNotifications: React.FC<AdminNotificationsProps> = ({
  products,
  onNavigateToProduct
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  // Alertas de inventario: productos agotados (stock === 0) y stock bajo (0 < stock <= minStock)
  const agotados = products.filter((p) => p.stock === 0);
  const stockBajo = products.filter((p) => p.stock > 0 && p.stock <= p.minStock);
  const totalAlertas = agotados.length + stockBajo.length;
  const alertProducts = [...agotados, ...stockBajo];

  // Cerrar al hacer clic fuera
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };
    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    }
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [isOpen]);

  const handleSelectAlert = (productCode: string) => {
    setIsOpen(false);
    onNavigateToProduct(productCode);
  };

  return (
    <div className="relative inline-block" ref={containerRef}>
      {/* Botón Campana */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="p-2 text-on-surface-variant hover:text-on-surface hover:bg-surface-container rounded-lg transition-colors relative cursor-pointer"
        title="Alertas y notificaciones de inventario"
        aria-label="Notificaciones de stock"
        type="button"
      >
        <span className="material-symbols-outlined text-[22px]">notifications</span>
        {/* El punto rojo depende estrictamente de la existencia de alertas */}
        {totalAlertas > 0 && (
          <span className="absolute top-1.5 right-1.5 w-2.5 h-2.5 bg-secondary rounded-full ring-2 ring-surface-container-lowest animate-pulse"></span>
        )}
      </button>

      {/* Panel Desplegable de Notificaciones */}
      {isOpen && (
        <div className="fixed sm:absolute right-4 sm:right-0 top-16 sm:top-full mt-2 w-[calc(100vw-32px)] sm:w-96 bg-surface-container-lowest border border-surface-variant rounded-2xl shadow-2xl z-50 overflow-hidden text-left animate-in fade-in zoom-in-95 duration-150">
          {/* Cabecera del Panel */}
          <div className="p-4 bg-surface-container-low border-b border-surface-variant flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="material-symbols-outlined text-primary text-xl">notifications_active</span>
              <h3 className="text-sm font-bold text-on-surface">Alertas de inventario</h3>
            </div>
            <div className="flex items-center gap-2">
              {totalAlertas > 0 && (
                <span className="px-2 py-0.5 rounded-full text-[11px] font-bold bg-amber-100 text-amber-900 border border-amber-300">
                  {totalAlertas} {totalAlertas === 1 ? 'alerta' : 'alertas'}
                </span>
              )}
              <button
                onClick={() => setIsOpen(false)}
                className="p-1 rounded-lg text-on-surface-variant hover:text-on-surface hover:bg-surface-container transition-colors cursor-pointer"
                title="Cerrar panel"
                type="button"
              >
                <span className="material-symbols-outlined text-lg">close</span>
              </button>
            </div>
          </div>

          {/* Lista de Alertas */}
          <div className="max-h-80 overflow-y-auto divide-y divide-surface-variant/60">
            {totalAlertas === 0 ? (
              <div className="py-8 px-6 text-center text-on-surface-variant space-y-2">
                <div className="w-12 h-12 rounded-full bg-emerald-50 text-emerald-600 flex items-center justify-center mx-auto border border-emerald-200">
                  <span className="material-symbols-outlined text-2xl" style={{ fontVariationSettings: "'FILL' 1" }}>
                    check_circle
                  </span>
                </div>
                <h4 className="text-sm font-bold text-on-surface">No hay alertas de inventario</h4>
                <p className="text-xs text-tertiary">
                  Todas las referencias en catálogo cuentan con existencias por encima del mínimo de seguridad.
                </p>
              </div>
            ) : (
              alertProducts.map((p) => {
                const isOut = p.stock === 0;
                return (
                  <button
                    key={p.code}
                    onClick={() => handleSelectAlert(p.code)}
                    className="w-full p-3.5 flex items-start gap-3 hover:bg-surface-container-low transition-colors text-left group cursor-pointer"
                    type="button"
                  >
                    <span
                      className={`material-symbols-outlined text-lg shrink-0 mt-0.5 ${
                        isOut ? 'text-secondary' : 'text-amber-600'
                      }`}
                    >
                      {isOut ? 'error' : 'warning'}
                    </span>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between gap-2 mb-0.5">
                        <span className="text-xs font-bold text-on-surface truncate group-hover:text-primary transition-colors">
                          {p.name}
                        </span>
                        {isOut ? (
                          <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-error-container text-on-error-container shrink-0">
                            Agotado
                          </span>
                        ) : (
                          <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-50 text-amber-800 border border-amber-200 shrink-0">
                            Stock bajo
                          </span>
                        )}
                      </div>

                      <div className="flex items-center justify-between text-[11px] text-tertiary">
                        <span>Cód: <strong className="font-mono text-on-surface">{p.code}</strong></span>
                        <span>
                          Disponible: <strong className={isOut ? 'text-secondary font-bold' : 'text-amber-800 font-bold'}>{p.stock}</strong> / Mín: {p.minStock}
                        </span>
                      </div>

                      <span className="inline-flex items-center gap-1 text-[11px] text-primary font-semibold mt-1 group-hover:underline">
                        <span>Ver en Inventario</span>
                        <span className="material-symbols-outlined text-xs">arrow_forward</span>
                      </span>
                    </div>
                  </button>
                );
              })
            )}
          </div>

          {/* Pie del Panel */}
          {totalAlertas > 0 && (
            <div className="p-3 bg-surface-container-low border-t border-surface-variant text-center">
              <button
                onClick={() => {
                  setIsOpen(false);
                  onNavigateToProduct();
                }}
                className="w-full py-2 rounded-lg bg-surface-container hover:bg-surface-container-high text-xs font-bold text-on-surface transition-colors cursor-pointer"
                type="button"
              >
                Abrir vista general de Inventario
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
