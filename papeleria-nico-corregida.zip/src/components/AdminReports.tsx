import React, { useState, useMemo } from 'react';
import { Sale, Product, Kit, formatCOP } from '../data/mockData';

interface AdminReportsProps {
  sales: Sale[];
  products?: Product[];
  kits?: Kit[];
  selectedSaleId?: string;
}

export const AdminReports: React.FC<AdminReportsProps> = ({
  sales,
  products = [],
  kits = [],
  selectedSaleId
}) => {
  const [activeTab, setActiveTab] = useState<'ventas' | 'reportes'>('ventas');
  const [fechaInicio, setFechaInicio] = useState('01/10/2024');
  const [fechaFin, setFechaFin] = useState('24/10/2024');
  const [modalSale, setModalSale] = useState<Sale | null>(
    selectedSaleId ? sales.find(s => s.id === selectedSaleId) || sales[0] : null
  );

  // Cálculos dinámicos globales de ventas
  const totalVendido = useMemo(() => sales.reduce((acc, s) => acc + s.total, 0), [sales]);
  const numeroVentas = sales.length;
  const ticketPromedio = numeroVentas > 0 ? Math.round(totalVendido / numeroVentas) : 0;

  // Distribución real de ventas por categoría
  const categoryDistribution = useMemo(() => {
    const catMap = new Map<string, number>();

    sales.forEach((s) => {
      s.items.forEach((item) => {
        let cat = 'Papelería general';
        if (item.isKit) {
          cat = 'Kits escolares y temáticos';
        } else {
          const prod = products.find((p) => p.code === item.code);
          if (prod) {
            cat = prod.category;
          }
        }
        const current = catMap.get(cat) || 0;
        catMap.set(cat, current + item.subtotal);
      });
    });

    const list: { category: string; total: number; percentage: number }[] = [];
    catMap.forEach((catTotal, category) => {
      const percentage = totalVendido > 0 ? (catTotal / totalVendido) * 100 : 0;
      list.push({ category, total: catTotal, percentage });
    });

    return list.sort((a, b) => b.total - a.total);
  }, [sales, products, totalVendido]);

  // Rotación y ventas acumuladas por producto (unidades sueltas + dentro de kits)
  const productPerformance = useMemo(() => {
    return products.map((prod) => {
      let looseUnits = 0;
      let kitUnits = 0;

      sales.forEach((s) => {
        s.items.forEach((it) => {
          if (!it.isKit && it.code === prod.code) {
            looseUnits += it.quantity;
          } else if (it.isKit) {
            const kit = kits.find((k) => k.id === it.code || k.name === it.name);
            if (kit) {
              const comp = kit.components.find((c) => c.productCode === prod.code);
              if (comp) {
                kitUnits += comp.quantity * it.quantity;
              }
            }
          }
        });
      });

      const totalUnits = looseUnits + kitUnits;
      const totalAmount = totalUnits * prod.price;

      return {
        product: prod,
        looseUnits,
        kitUnits,
        totalUnits,
        totalAmount
      };
    });
  }, [products, kits, sales]);

  const topSellingProducts = useMemo(() => {
    return [...productPerformance]
      .filter((p) => p.totalUnits > 0)
      .sort((a, b) => b.totalUnits - a.totalUnits)
      .slice(0, 4);
  }, [productPerformance]);

  const lowMovingProducts = useMemo(() => {
    return [...productPerformance]
      .sort((a, b) => a.totalUnits - b.totalUnits)
      .slice(0, 3);
  }, [productPerformance]);

  const handleExport = () => {
    alert("✓ Descarga simulada: El resumen oficial de ventas en formato CSV se ha generado correctamente.");
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="flex-1 flex flex-col min-w-0 h-full overflow-hidden bg-surface">
      {/* BARRA SUPERIOR DE CONTEXTO */}
      <header className="h-16 bg-surface-container-lowest border-b border-surface-variant px-6 lg:px-8 flex items-center justify-between shrink-0 z-10">
        <div className="flex items-center gap-2 text-xs font-semibold text-on-surface-variant">
          <span className="text-tertiary">Administración</span>
          <span className="text-outline-variant">/</span>
          <span className="font-bold text-on-surface">Historial y reportes</span>
        </div>
        <div className="flex items-center gap-6">
          <div className="flex items-center gap-2 text-on-surface-variant text-xs bg-surface-container px-3 py-1.5 rounded-full border border-surface-variant">
            <span className="material-symbols-outlined text-[16px] text-secondary">location_on</span>
            <span>Torreón El Roble, Ibagué</span>
          </div>
          <div className="hidden sm:flex items-center gap-2 text-on-surface-variant text-xs">
            <span className="material-symbols-outlined text-[18px]">calendar_today</span>
            <span>24 de octubre de 2024</span>
          </div>
        </div>
      </header>

      {/* NAVEGACIÓN POR PESTAÑAS */}
      <div className="bg-surface-container-lowest border-b border-surface-variant px-6 lg:px-8 flex items-center justify-between">
        <div className="flex gap-8">
          <button
            onClick={() => setActiveTab('ventas')}
            className={`py-3.5 px-1 text-sm font-bold border-b-2 flex items-center gap-2 transition-all cursor-pointer ${
              activeTab === 'ventas'
                ? 'text-on-surface border-primary-container'
                : 'text-tertiary hover:text-on-surface border-transparent font-medium'
            }`}
          >
            <span className="material-symbols-outlined text-[20px]" style={{ fontVariationSettings: activeTab === 'ventas' ? "'FILL' 1" : "'FILL' 0" }}>
              receipt_long
            </span>
            <span>Historial de ventas</span>
            <span className="ml-1 bg-surface-container text-tertiary text-xs font-bold px-2 py-0.5 rounded-full">
              {sales.length}
            </span>
          </button>
          <button
            onClick={() => setActiveTab('reportes')}
            className={`py-3.5 px-1 text-sm font-bold border-b-2 flex items-center gap-2 transition-all cursor-pointer ${
              activeTab === 'reportes'
                ? 'text-on-surface border-primary-container'
                : 'text-tertiary hover:text-on-surface border-transparent font-medium'
            }`}
          >
            <span className="material-symbols-outlined text-[20px]">query_stats</span>
            <span>Reportes y estadísticas</span>
          </button>
        </div>
        {/* Acción rápida de exportación */}
        <button
          onClick={handleExport}
          className="hidden sm:inline-flex items-center gap-2 px-3.5 py-1.5 rounded-lg border border-surface-variant bg-surface-container-lowest hover:bg-surface-container text-on-surface text-xs font-semibold transition-colors cursor-pointer"
        >
          <span className="material-symbols-outlined text-[18px] text-tertiary">download</span>
          <span>Exportar resumen (CSV / PDF)</span>
        </button>
      </div>

      {/* ÁREA DE CONTENIDO PRINCIPAL */}
      <div className="flex-1 overflow-y-auto custom-scroll p-6 lg:p-8 space-y-6">
        {/* ==================== PESTAÑA 1: HISTORIAL DE VENTAS ==================== */}
        {activeTab === 'ventas' && (
          <div className="space-y-4">
            {/* BARRA DE FILTROS */}
            <div className="bg-surface-container-lowest p-4 rounded-xl border border-surface-variant flex flex-wrap items-center justify-between gap-4 shadow-xs">
              <div className="flex flex-wrap items-center gap-3">
                <div className="flex items-center gap-2">
                  <label className="text-[11px] text-tertiary uppercase tracking-wider font-bold" htmlFor="fecha-inicio">
                    Fecha inicial:
                  </label>
                  <input
                    id="fecha-inicio"
                    type="text"
                    value={fechaInicio}
                    onChange={(e) => setFechaInicio(e.target.value)}
                    className="h-10 text-xs font-medium border border-surface-variant rounded-lg px-3 py-1.5 focus:border-primary-container focus:ring-1 focus:ring-primary-container bg-surface-container-lowest w-32 text-center text-on-surface"
                  />
                </div>
                <span className="text-tertiary">→</span>
                <div className="flex items-center gap-2">
                  <label className="text-[11px] text-tertiary uppercase tracking-wider font-bold" htmlFor="fecha-fin">
                    Fecha final:
                  </label>
                  <input
                    id="fecha-fin"
                    type="text"
                    value={fechaFin}
                    onChange={(e) => setFechaFin(e.target.value)}
                    className="h-10 text-xs font-medium border border-surface-variant rounded-lg px-3 py-1.5 focus:border-primary-container focus:ring-1 focus:ring-primary-container bg-surface-container-lowest w-32 text-center text-on-surface"
                  />
                </div>
                <button
                  type="button"
                  className="h-10 px-4 rounded-lg bg-primary-container hover:bg-primary-fixed-dim text-on-surface text-xs font-bold transition-all shadow-xs cursor-pointer"
                >
                  Aplicar
                </button>
              </div>

              <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-surface-container-low border border-surface-variant text-tertiary text-xs">
                <span className="w-2 h-2 rounded-full bg-primary-container"></span>
                <span>Período: <strong className="text-on-surface">Del {fechaInicio} al {fechaFin}</strong> (24 días)</span>
              </div>
            </div>

            {/* TABLA DE VENTAS HISTÓRICAS */}
            <div className="bg-surface-container-lowest rounded-xl border border-surface-variant shadow-xs overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="bg-surface-container-low border-b border-surface-variant text-tertiary text-xs font-bold">
                      <th className="py-3.5 px-4 font-bold"># Venta</th>
                      <th className="py-3.5 px-4 font-bold">Fecha</th>
                      <th className="py-3.5 px-4 font-bold">Hora</th>
                      <th className="py-3.5 px-6 font-bold">Tipo / Artículos</th>
                      <th className="py-3.5 px-4 font-bold text-right">Total en COP</th>
                      <th className="py-3.5 px-4 font-bold text-center">Acciones</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-surface-variant text-sm">
                    {sales.map((sale) => {
                      const itemCount = sale.items.length;
                      const unitsCount = sale.items.reduce((acc, it) => acc + it.quantity, 0);

                      return (
                        <tr key={sale.id} className="hover:bg-surface-container-low/60 transition-colors">
                          <td className="py-3.5 px-4 font-bold text-on-surface">
                            <span className="px-2 py-0.5 bg-primary-container/40 text-on-surface rounded font-mono text-xs font-bold border border-primary-fixed-dim">
                              {sale.id}
                            </span>
                          </td>
                          <td className="py-3.5 px-4 text-on-surface font-medium">{sale.date}</td>
                          <td className="py-3.5 px-4 text-tertiary text-xs">{sale.time}</td>
                          <td className="py-3.5 px-6 text-on-surface">
                            <div className="font-medium text-xs">
                              {itemCount} producto{itemCount > 1 ? 's' : ''} ({unitsCount} unidad{unitsCount > 1 ? 'es' : ''})
                            </div>
                            <div className="text-[11px] text-tertiary truncate max-w-xs">
                              {sale.items.map(it => it.name).join(', ')}
                            </div>
                          </td>
                          <td className="py-3.5 px-4 text-right font-bold text-on-surface">
                            {formatCOP(sale.total)}
                          </td>
                          <td className="py-3.5 px-4 text-center">
                            <button
                              onClick={() => setModalSale(sale)}
                              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-surface-container-lowest border border-outline-variant hover:bg-surface-container text-on-surface text-xs font-bold shadow-xs transition-all cursor-pointer"
                            >
                              <span className="material-symbols-outlined text-[16px] text-primary">visibility</span>
                              <span>Ver detalle</span>
                            </button>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>

              {/* Paginador */}
              <div className="p-4 bg-surface-container-low border-t border-surface-variant flex items-center justify-between text-xs text-on-surface-variant">
                <span>
                  Mostrando <strong className="text-on-surface font-semibold">{sales.length}</strong> ventas registradas
                </span>
                <div className="flex items-center gap-2">
                  <span className="px-3 py-1 text-xs font-bold text-on-surface bg-surface-container rounded-lg">
                    Página 1 de 1
                  </span>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ==================== PESTAÑA 2: REPORTES Y ESTADÍSTICAS ==================== */}
        {activeTab === 'reportes' && (
          <div className="space-y-6">
            {/* TARJETAS DE RESUMEN COMERCIAL (KPIs) */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {/* Total Vendido */}
              <div className="bg-surface-container-lowest p-5 rounded-xl border border-surface-variant shadow-xs flex items-start justify-between">
                <div>
                  <span className="text-xs text-tertiary block mb-1 font-semibold uppercase tracking-wider">Total vendido</span>
                  <div className="text-2xl font-extrabold text-on-surface">{formatCOP(totalVendido)}</div>
                  <span className="text-xs text-tertiary mt-2 inline-flex items-center gap-1">
                    <span className="material-symbols-outlined text-[16px] text-primary" style={{ fontVariationSettings: "'FILL' 1" }}>
                      verified
                    </span>
                    Facturación neta acumulada
                  </span>
                </div>
                <div className="w-12 h-12 rounded-xl bg-primary-container/30 flex items-center justify-center text-primary">
                  <span className="material-symbols-outlined text-[28px]">payments</span>
                </div>
              </div>

              {/* Número de Ventas */}
              <div className="bg-surface-container-lowest p-5 rounded-xl border border-surface-variant shadow-xs flex items-start justify-between">
                <div>
                  <span className="text-xs text-tertiary block mb-1 font-semibold uppercase tracking-wider">Número de ventas</span>
                  <div className="text-2xl font-extrabold text-on-surface">
                    {numeroVentas} <span className="text-base font-normal text-tertiary">{numeroVentas === 1 ? 'venta' : 'ventas'}</span>
                  </div>
                  <span className="text-xs text-tertiary mt-2 inline-flex items-center gap-1">
                    <span className="material-symbols-outlined text-[16px] text-tertiary">receipt</span>
                    Transacciones completadas
                  </span>
                </div>
                <div className="w-12 h-12 rounded-xl bg-surface-container flex items-center justify-center text-on-surface">
                  <span className="material-symbols-outlined text-[28px]">point_of_sale</span>
                </div>
              </div>

              {/* Ticket Promedio */}
              <div className="bg-surface-container-lowest p-5 rounded-xl border border-surface-variant shadow-xs flex items-start justify-between">
                <div>
                  <span className="text-xs text-tertiary block mb-1 font-semibold uppercase tracking-wider">Ticket promedio</span>
                  <div className="text-2xl font-extrabold text-on-surface">{formatCOP(ticketPromedio)}</div>
                  <span className="text-xs text-tertiary mt-2 inline-flex items-center gap-1">
                    <span className="material-symbols-outlined text-[16px] text-tertiary">analytics</span>
                    Promedio por cliente atendido
                  </span>
                </div>
                <div className="w-12 h-12 rounded-xl bg-surface-container flex items-center justify-center text-on-surface">
                  <span className="material-symbols-outlined text-[28px]">stacked_line_chart</span>
                </div>
              </div>
            </div>

            {/* GRÁFICO DE BARRAS DE VENTAS POR CATEGORÍA */}
            <div className="bg-surface-container-lowest p-6 rounded-xl border border-surface-variant shadow-xs">
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h2 className="text-lg font-bold text-on-surface">Distribución de ventas por categoría</h2>
                  <p className="text-xs text-tertiary">Monto acumulado facturado según registros de ventas en el sistema</p>
                </div>
                <span className="text-xs bg-surface-container px-2.5 py-1 rounded-full text-tertiary font-bold">
                  Datos en COP
                </span>
              </div>

              <div className="space-y-4">
                {categoryDistribution.length === 0 ? (
                  <p className="text-xs text-tertiary py-4 text-center">No hay ventas registradas para generar la distribución.</p>
                ) : (
                  categoryDistribution.map((item, idx) => {
                    const barColors = [
                      'bg-primary-container',
                      'bg-amber-600 opacity-80',
                      'bg-secondary opacity-70',
                      'bg-outline opacity-60',
                      'bg-tertiary opacity-40',
                      'bg-emerald-600 opacity-70'
                    ];
                    const colorClass = barColors[idx % barColors.length];

                    return (
                      <div key={item.category}>
                        <div className="flex justify-between text-xs mb-1.5">
                          <span className="font-bold text-on-surface">{item.category}</span>
                          <span className="font-bold text-on-surface">
                            {formatCOP(item.total)}{' '}
                            <span className="font-normal text-tertiary">({item.percentage.toFixed(1)}%)</span>
                          </span>
                        </div>
                        <div className="w-full bg-surface-container rounded-full h-3.5 overflow-hidden">
                          <div
                            className={`h-full rounded-full ${colorClass}`}
                            style={{ width: `${Math.min(100, Math.max(item.percentage, 3))}%` }}
                          ></div>
                        </div>
                      </div>
                    );
                  })
                )}
              </div>
            </div>

            {/* DOS TABLAS DE RANKING OPERATIVO */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* TABLA 1: Productos Más Vendidos */}
              <div className="bg-surface-container-lowest rounded-xl border border-surface-variant shadow-xs overflow-hidden flex flex-col">
                <div className="p-4 border-b border-surface-variant bg-surface-container-low flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="material-symbols-outlined text-[20px] text-primary" style={{ fontVariationSettings: "'FILL' 1" }}>
                      trending_up
                    </span>
                    <h3 className="text-sm font-bold text-on-surface">Productos más vendidos (por unidades)</h3>
                  </div>
                  <span className="text-[11px] text-tertiary font-bold">Unidades totales</span>
                </div>
                <div className="p-4 flex-1">
                  <p className="text-xs text-tertiary mb-3">Incluye unidades vendidas sueltas y consumidas dentro de kits escolares.</p>
                  <ul className="divide-y divide-surface-variant text-sm">
                    {topSellingProducts.length === 0 ? (
                      <li className="py-4 text-center text-xs text-tertiary">Sin datos de unidades vendidas.</li>
                    ) : (
                      topSellingProducts.map((p, idx) => (
                        <li key={p.product.code} className="py-3 flex items-center justify-between">
                          <div className="flex items-center gap-3">
                            <span
                              className={`w-6 h-6 rounded-full font-bold text-xs flex items-center justify-center ${
                                idx === 0 ? 'bg-primary-container text-on-surface' : 'bg-surface-container text-on-surface'
                              }`}
                            >
                              {idx + 1}
                            </span>
                            <div>
                              <div className="font-bold text-on-surface text-xs">{p.product.name}</div>
                              <div className="text-[11px] text-tertiary">
                                {p.looseUnits} sueltas {p.kitUnits > 0 ? `+ ${p.kitUnits} en kits` : ''}
                              </div>
                            </div>
                          </div>
                          <div className="text-right">
                            <div className="font-bold text-on-surface text-xs">{p.totalUnits} unidades</div>
                            <div className="text-[11px] text-tertiary">{formatCOP(p.totalAmount)}</div>
                          </div>
                        </li>
                      ))
                    )}
                  </ul>
                </div>
              </div>

              {/* TABLA 2: Productos con Menor Movimiento */}
              <div className="bg-surface-container-lowest rounded-xl border border-surface-variant shadow-xs overflow-hidden flex flex-col">
                <div className="p-4 border-b border-surface-variant bg-surface-container-low flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="material-symbols-outlined text-[20px] text-secondary">trending_down</span>
                    <h3 className="text-sm font-bold text-on-surface">Productos con menor movimiento</h3>
                  </div>
                  <span className="text-[11px] text-secondary font-bold">Atención stock</span>
                </div>
                <div className="p-4 flex-1">
                  <p className="text-xs text-tertiary mb-3">Artículos con menor rotación según el historial de ventas.</p>
                  <ul className="divide-y divide-surface-variant text-sm">
                    {lowMovingProducts.length === 0 ? (
                      <li className="py-4 text-center text-xs text-tertiary">Sin datos disponibles.</li>
                    ) : (
                      lowMovingProducts.map((p) => {
                        const isZero = p.totalUnits === 0;
                        return (
                          <li key={p.product.code} className="py-3 flex items-center justify-between">
                            <div className="flex items-center gap-3">
                              <span className="material-symbols-outlined text-outline text-[20px]">
                                {isZero ? 'warning' : 'info'}
                              </span>
                              <div>
                                <div className="font-bold text-on-surface text-xs">{p.product.name}</div>
                                <div className="text-[11px] text-tertiary">Categoría: {p.product.category}</div>
                              </div>
                            </div>
                            <div className="text-right">
                              <span
                                className={`px-2.5 py-1 rounded text-[11px] font-bold ${
                                  isZero
                                    ? 'bg-error-container text-on-error-container'
                                    : 'bg-surface-container text-tertiary'
                                }`}
                              >
                                {p.totalUnits} {p.totalUnits === 1 ? 'unidad vendida' : 'unidades vendidas'}
                              </span>
                            </div>
                          </li>
                        );
                      })
                    )}
                  </ul>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* ==================== MODAL / VENTANA DE DETALLE DE VENTA ==================== */}
      {modalSale && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-inverse-surface/40 backdrop-blur-xs">
          <div className="bg-surface-container-lowest w-full max-w-2xl rounded-2xl border border-surface-variant shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
            {/* Encabezado Modal */}
            <div className="p-5 border-b border-surface-variant bg-surface-container-low flex items-center justify-between shrink-0">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-primary-container text-on-surface flex items-center justify-center font-bold">
                  <span className="material-symbols-outlined text-[24px]">receipt</span>
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h2 className="text-base font-bold text-on-surface">Detalle de venta {modalSale.id}</h2>
                    <span className="px-2 py-0.5 rounded-full bg-surface-container text-tertiary text-[11px] font-bold border border-surface-variant">
                      Completada / Solo lectura
                    </span>
                  </div>
                  <p className="text-xs text-tertiary">Registro histórico guardado en caja central</p>
                </div>
              </div>
              <button
                onClick={() => setModalSale(null)}
                className="w-8 h-8 rounded-full flex items-center justify-center text-tertiary hover:text-on-surface hover:bg-surface-container transition-colors"
                type="button"
              >
                <span className="material-symbols-outlined text-[20px]">close</span>
              </button>
            </div>

            {/* Cuerpo del Modal (Scrollable) */}
            <div className="p-6 overflow-y-auto custom-scroll space-y-5">
              {/* Metadatos de la Venta */}
              <div className="grid grid-cols-3 gap-3 p-3.5 rounded-xl bg-surface-container-low border border-surface-variant text-xs">
                <div>
                  <span className="block text-tertiary font-bold">Fecha y Hora:</span>
                  <span className="font-bold text-on-surface">{modalSale.date} - {modalSale.time}</span>
                </div>
                <div>
                  <span className="block text-tertiary font-bold">Registrada por:</span>
                  <span className="font-bold text-on-surface">{modalSale.responsible}</span>
                </div>
                <div>
                  <span className="block text-tertiary font-bold">Sede:</span>
                  <span className="font-bold text-on-surface">{modalSale.location}</span>
                </div>
              </div>

              {/* Tabla de Artículos Vendidos */}
              <div>
                <div className="text-sm font-bold text-on-surface mb-2">Artículos cobrados</div>
                <div className="border border-surface-variant rounded-xl overflow-hidden">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-surface-container-low border-b border-surface-variant text-tertiary font-bold">
                      <tr>
                        <th className="py-2.5 px-3">Artículo / Descripción</th>
                        <th className="py-2.5 px-2 text-center">Cant.</th>
                        <th className="py-2.5 px-3 text-right">Precio unitario</th>
                        <th className="py-2.5 px-3 text-right">Subtotal</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-surface-variant">
                      {modalSale.items.map((it, idx) => (
                        <tr key={idx} className="bg-surface-container-lowest">
                          <td className="py-3 px-3">
                            <div className="flex items-center gap-1.5">
                              {it.isKit && (
                                <span className="px-1.5 py-0.5 rounded bg-primary-fixed text-on-primary-fixed-variant text-[10px] font-bold">
                                  KIT
                                </span>
                              )}
                              <div className="font-bold text-on-surface">{it.name}</div>
                            </div>
                            <span className="text-tertiary text-[11px]">SKU: {it.code}</span>

                            {/* Componentes incluidos en el kit */}
                            {it.isKit && it.components && (
                              <div className="mt-2.5 ml-2 pl-3 border-l-2 border-primary-container space-y-1 bg-surface-container-low p-2 rounded-r-lg">
                                <div className="text-[11px] font-bold text-tertiary flex items-center justify-between">
                                  <span>Componentes incluidos en paquete:</span>
                                  <span className="text-on-surface bg-primary-fixed px-1.5 py-0.5 rounded text-[10px] font-bold">
                                    Incluido en kit - $0 adicional
                                  </span>
                                </div>
                                <ul className="text-[11px] text-on-surface-variant space-y-0.5">
                                  {it.components.map((comp, ci) => (
                                    <li key={ci} className="flex items-center gap-1.5">
                                      <span className="material-symbols-outlined text-[13px] text-primary" style={{ fontVariationSettings: "'FILL' 1" }}>
                                        check_circle
                                      </span>
                                      <span>{comp.quantity}x {comp.name}</span>
                                    </li>
                                  ))}
                                </ul>
                              </div>
                            )}
                          </td>
                          <td className="py-3 px-2 text-center font-bold text-on-surface">{it.quantity}</td>
                          <td className="py-3 px-3 text-right text-on-surface">{formatCOP(it.unitPrice)}</td>
                          <td className="py-3 px-3 text-right font-bold text-on-surface">{formatCOP(it.subtotal)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Resumen Financiero */}
              <div className="bg-surface-container-low p-4 rounded-xl border border-surface-variant space-y-2 text-xs">
                <div className="flex justify-between text-tertiary">
                  <span>Subtotal neto:</span>
                  <span className="font-medium text-on-surface">{formatCOP(modalSale.subtotal)}</span>
                </div>
                <div className="border-t border-surface-variant pt-2 flex justify-between items-baseline">
                  <span className="text-sm font-bold text-on-surface">TOTAL COBRADO:</span>
                  <span className="text-xl font-black text-on-surface">{formatCOP(modalSale.total)}</span>
                </div>
              </div>

              {/* Aclaración Inmutable */}
              <div className="flex items-start gap-2.5 p-3 rounded-lg bg-surface-container text-tertiary text-xs">
                <span className="material-symbols-outlined text-[18px] text-tertiary shrink-0">lock</span>
                <span>
                  Registro histórico inmutable. Los precios y la composición corresponden al momento exacto de la venta. Este ticket no permite modificaciones ni reembolsos desde este panel.
                </span>
              </div>
            </div>

            {/* Pie del Modal */}
            <div className="p-4 border-t border-surface-variant bg-surface-container-lowest flex items-center justify-between shrink-0">
              <button
                type="button"
                onClick={handlePrint}
                className="inline-flex items-center gap-2 px-4 py-2 rounded-lg border border-surface-variant bg-surface-container-lowest hover:bg-surface-container text-on-surface text-xs font-semibold transition-colors cursor-pointer"
              >
                <span className="material-symbols-outlined text-[18px]">print</span>
                <span>Imprimir copia de ticket</span>
              </button>
              <button
                type="button"
                onClick={() => setModalSale(null)}
                className="px-5 py-2 rounded-lg bg-primary-container hover:bg-primary-fixed-dim text-on-surface text-xs font-bold transition-all active:scale-95 shadow-xs cursor-pointer"
              >
                Cerrar ventana
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
