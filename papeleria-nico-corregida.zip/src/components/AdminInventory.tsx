import React, { useState, useEffect } from 'react';
import { Product, InventoryMovement, Category, matchesCategoryFilter, getBogotaToday } from '../data/mockData';

interface AdminInventoryProps {
  products: Product[];
  movements: InventoryMovement[];
  categories?: Category[];
  initialStatusFilter?: string;
  initialSearch?: string;
  onAddStock: (productCode: string, quantity: number, reference: string) => void;
  onAdjustStock: (productCode: string, newStock: number, reason: string) => void;
}

export const AdminInventory: React.FC<AdminInventoryProps> = ({
  products,
  movements,
  categories,
  initialStatusFilter,
  initialSearch,
  onAddStock,
  onAdjustStock
}) => {
  const [activeTab, setActiveTab] = useState<'existencias' | 'movimientos'>('existencias');
  const [toastMessage, setToastMessage] = useState<string | null>(
    'Último registro confirmado: Entrada de 20 unidades en Colbón 115g guardada exitosamente hoy a las 10:14 AM.'
  );

  const { formattedLong } = getBogotaToday();

  // Filters for existencias
  const [searchQuery, setSearchQuery] = useState(initialSearch || '');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState(initialStatusFilter || 'all');
  const [currentPage, setCurrentPage] = useState(1);

  useEffect(() => {
    if (initialStatusFilter) {
      setStatusFilter(initialStatusFilter);
    }
  }, [initialStatusFilter]);

  useEffect(() => {
    if (initialSearch !== undefined) {
      setSearchQuery(initialSearch);
    }
  }, [initialSearch]);

  // Modal 1: Registrar Entrada
  const [modalEntradaOpen, setModalEntradaOpen] = useState(false);
  const [selectedProductForEntrada, setSelectedProductForEntrada] = useState<Product | null>(null);
  const [unidadesEntrada, setUnidadesEntrada] = useState<number>(20);
  const [facturaEntrada, setFacturaEntrada] = useState('Factura Distribuidora Tolima #45892');

  // Modal 2: Ajustar Stock
  const [modalAjusteOpen, setModalAjusteOpen] = useState(false);
  const [selectedProductForAjuste, setSelectedProductForAjuste] = useState<Product | null>(null);
  const [ajusteModo, setAjusteModo] = useState<'salida' | 'conteo'>('salida');
  const [unidadesRetirar, setUnidadesRetirar] = useState<number>(1);
  const [motivoSalida, setMotivoSalida] = useState('Daño / deterioro de empaque');
  const [conteoFisico, setConteoFisico] = useState<number>(10);
  const [motivoConteo, setMotivoConteo] = useState('Conteo periódico de estantería');
  const [checkConfirmacion, setCheckConfirmacion] = useState(false);

  // Filtered products list
  const filteredProducts = products.filter((p) => {
    const q = searchQuery.toLowerCase().trim();
    const matchSearch = q === '' || p.code.toLowerCase().includes(q) || p.name.toLowerCase().includes(q);
    const matchCategory = categoryFilter === 'all' || matchesCategoryFilter(p.category, categoryFilter);

    const isOut = p.stock === 0;
    const isLow = p.stock > 0 && p.stock <= p.minStock;
    const isAvailable = p.stock > p.minStock;

    let matchStatus = true;
    if (statusFilter === 'Disponible') matchStatus = isAvailable;
    else if (statusFilter === 'Stock bajo') matchStatus = isLow;
    else if (statusFilter === 'Agotado') matchStatus = isOut;

    return matchSearch && matchCategory && matchStatus;
  });

  const availableCount = products.filter(p => p.stock > p.minStock).length;
  const lowStockCount = products.filter(p => p.stock > 0 && p.stock <= p.minStock).length;
  const outOfStockCount = products.filter(p => p.stock === 0).length;

  const handleOpenEntrada = (p?: Product) => {
    const prod = p || products[0];
    setSelectedProductForEntrada(prod);
    setUnidadesEntrada(20);
    setFacturaEntrada('Factura Distribuidora Tolima #45892');
    setModalEntradaOpen(true);
  };

  const handleSaveEntrada = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedProductForEntrada || unidadesEntrada <= 0) return;
    onAddStock(selectedProductForEntrada.code, unidadesEntrada, facturaEntrada);
    setToastMessage(
      `Entrada de ${unidadesEntrada} unidades en ${selectedProductForEntrada.name} guardada exitosamente.`
    );
    setModalEntradaOpen(false);
  };

  const handleOpenAjuste = (p?: Product) => {
    const prod = p || products[0];
    setSelectedProductForAjuste(prod);
    setAjusteModo('salida');
    setUnidadesRetirar(prod.stock > 0 ? 1 : 0);
    setConteoFisico(prod.stock);
    setCheckConfirmacion(false);
    setModalAjusteOpen(true);
  };

  const handleSaveAjuste = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedProductForAjuste || !checkConfirmacion) return;

    let newStock = selectedProductForAjuste.stock;
    let reason = '';

    if (ajusteModo === 'salida') {
      if (unidadesRetirar > selectedProductForAjuste.stock) {
        alert('No puedes retirar más unidades de las disponibles.');
        return;
      }
      newStock = selectedProductForAjuste.stock - unidadesRetirar;
      reason = `Ajuste por merma/salida: ${motivoSalida} (-${unidadesRetirar} unids)`;
    } else {
      newStock = Math.max(0, conteoFisico);
      const diff = newStock - selectedProductForAjuste.stock;
      reason = `Conteo físico: ${motivoConteo} (${diff >= 0 ? '+' : ''}${diff} unids)`;
    }

    onAdjustStock(selectedProductForAjuste.code, newStock, reason);
    setToastMessage(`Ajuste de inventario aplicado para ${selectedProductForAjuste.name}. Nuevo stock: ${newStock} unids.`);
    setModalAjusteOpen(false);
  };

  const resetFilters = () => {
    setSearchQuery('');
    setCategoryFilter('all');
    setStatusFilter('all');
    setCurrentPage(1);
  };

  return (
    <div className="flex-1 flex flex-col min-w-0 h-full overflow-hidden bg-surface">
      {/* CABECERA SUPERIOR COMPACTA */}
      <header className="h-16 bg-surface-container-lowest border-b border-surface-variant sticky top-0 z-20 px-6 lg:px-8 flex items-center justify-between gap-4 shrink-0">
        <div className="flex items-center gap-2 text-xs font-semibold text-on-surface-variant">
          <span>Administración</span>
          <span className="text-outline-variant">/</span>
          <span className="text-on-surface font-bold">Inventario de existencias</span>
        </div>
        <div className="flex items-center gap-4">
          <div className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-surface-container-low border border-surface-variant text-xs text-on-surface">
            <span className="material-symbols-outlined text-secondary text-[16px]">location_on</span>
            <span className="font-medium">Torreón El Roble, Ibagué</span>
          </div>
          <div className="hidden lg:flex items-center gap-1.5 text-xs text-on-surface-variant">
            <span className="material-symbols-outlined text-[16px]">calendar_today</span>
            <span>{formattedLong}</span>
          </div>
        </div>
      </header>

      {/* ÁREA DE CONTENIDO */}
      <main className="flex-1 overflow-y-auto custom-scroll p-6 lg:p-8 max-w-7xl w-full mx-auto flex flex-col gap-6">
        {/* BANNER DE FEEDBACK DINÁMICO */}
        {toastMessage && (
          <div className="bg-emerald-50 border border-emerald-300 rounded-xl p-3.5 flex items-center justify-between text-emerald-900 shadow-xs transition-all">
            <div className="flex items-center gap-3">
              <span className="material-symbols-outlined text-emerald-600 text-xl font-bold" style={{ fontVariationSettings: "'FILL' 1" }}>
                check_circle
              </span>
              <p className="text-xs font-semibold">
                {toastMessage}
              </p>
            </div>
            <button
              onClick={() => setToastMessage(null)}
              className="text-emerald-700 hover:text-emerald-900 p-1 rounded-md"
              title="Cerrar notificación"
            >
              <span className="material-symbols-outlined text-sm">close</span>
            </button>
          </div>
        )}

        {/* TÍTULO Y SUBTÍTULO */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div>
            <h1 className="text-2xl lg:text-3xl font-bold text-on-surface tracking-tight">Inventario</h1>
            <p className="text-sm text-on-surface-variant mt-1">
              Control de existencias físicas, registro de entradas y trazabilidad de movimientos en almacén.
            </p>
          </div>
          {/* ACCIONES RÁPIDAS GLOBALES */}
          <div className="flex items-center gap-2.5">
            <button
              onClick={() => handleOpenEntrada()}
              className="bg-primary-container text-on-surface hover:bg-[#e5bd1b] px-4 py-2.5 rounded-lg text-sm font-bold transition-all shadow-xs active:scale-98 flex items-center gap-2 cursor-pointer"
            >
              <span className="material-symbols-outlined text-[18px]">add_box</span>
              <span>Registrar entrada</span>
            </button>
            <button
              onClick={() => handleOpenAjuste()}
              className="bg-surface-container-lowest border border-surface-variant text-on-surface hover:bg-surface-container px-4 py-2.5 rounded-lg text-sm font-semibold transition-all active:scale-98 flex items-center gap-2 shadow-xs cursor-pointer"
            >
              <span className="material-symbols-outlined text-[18px]">tune</span>
              <span>Ajustar stock</span>
            </button>
          </div>
        </div>

        {/* TABS PRINCIPALES */}
        <div className="border-b border-surface-variant flex items-center gap-8">
          <button
            onClick={() => setActiveTab('existencias')}
            className={`pb-3 border-b-2 font-bold text-sm flex items-center gap-2 transition-all cursor-pointer ${
              activeTab === 'existencias'
                ? 'border-primary text-primary'
                : 'border-transparent text-on-surface-variant hover:text-on-surface'
            }`}
          >
            <span>Existencias</span>
            <span className="bg-primary-container text-on-primary-container text-[11px] font-bold px-2 py-0.5 rounded-full border border-primary-fixed-dim">
              {products.length} productos
            </span>
          </button>
          <button
            onClick={() => setActiveTab('movimientos')}
            className={`pb-3 border-b-2 font-bold text-sm flex items-center gap-2 transition-all cursor-pointer ${
              activeTab === 'movimientos'
                ? 'border-primary text-primary'
                : 'border-transparent text-on-surface-variant hover:text-on-surface'
            }`}
          >
            <span>Movimientos</span>
            <span className="bg-surface-container text-on-surface-variant text-[11px] font-medium px-2 py-0.5 rounded-full">
              {movements.length} registros
            </span>
          </button>
        </div>

        {/* ================= PESTAÑA 1: EXISTENCIAS ================= */}
        {activeTab === 'existencias' && (
          <div className="flex flex-col gap-6">
            {/* RESUMEN DE MÉTRICAS RÁPIDAS */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="bg-surface-container-lowest p-4 rounded-xl border border-surface-variant shadow-xs flex items-center gap-3.5">
                <div className="w-10 h-10 rounded-lg bg-surface-container flex items-center justify-center text-on-surface">
                  <span className="material-symbols-outlined text-[22px]">inventory_2</span>
                </div>
                <div>
                  <span className="text-[11px] font-semibold text-on-surface-variant block uppercase tracking-wider">Total Referencias</span>
                  <span className="text-xl font-bold text-on-surface">{products.length}</span>
                </div>
              </div>
              <div className="bg-surface-container-lowest p-4 rounded-xl border border-surface-variant shadow-xs flex items-center gap-3.5">
                <div className="w-10 h-10 rounded-lg bg-emerald-50 text-emerald-700 flex items-center justify-center border border-emerald-200">
                  <span className="material-symbols-outlined text-[22px]">check_circle</span>
                </div>
                <div>
                  <span className="text-[11px] font-semibold text-on-surface-variant block uppercase tracking-wider">Disponibles</span>
                  <span className="text-xl font-bold text-emerald-800">{availableCount}</span>
                </div>
              </div>
              <div className="bg-surface-container-lowest p-4 rounded-xl border border-surface-variant shadow-xs flex items-center gap-3.5">
                <div className="w-10 h-10 rounded-lg bg-amber-50 text-amber-800 flex items-center justify-center border border-amber-300">
                  <span className="material-symbols-outlined text-[22px]">warning</span>
                </div>
                <div>
                  <span className="text-[11px] font-semibold text-on-surface-variant block uppercase tracking-wider">Stock Bajo</span>
                  <span className="text-xl font-bold text-amber-900">{lowStockCount}</span>
                </div>
              </div>
              <div className="bg-surface-container-lowest p-4 rounded-xl border border-surface-variant shadow-xs flex items-center gap-3.5">
                <div className="w-10 h-10 rounded-lg bg-rose-50 text-rose-700 flex items-center justify-center border border-rose-200">
                  <span className="material-symbols-outlined text-[22px]">error</span>
                </div>
                <div>
                  <span className="text-[11px] font-semibold text-on-surface-variant block uppercase tracking-wider">Agotados</span>
                  <span className="text-xl font-bold text-rose-700">{outOfStockCount}</span>
                </div>
              </div>
            </div>

            {/* BARRA DE HERRAMIENTAS Y FILTROS */}
            <div className="bg-surface-container-lowest p-4 rounded-xl border border-surface-variant shadow-xs flex flex-col md:flex-row gap-4 items-stretch md:items-center justify-between">
              <div className="flex-1 flex flex-col sm:flex-row gap-3">
                {/* BUSCADOR */}
                <div className="relative flex-1">
                  <span className="material-symbols-outlined absolute left-3.5 top-1/2 -translate-y-1/2 text-tertiary text-[20px]">search</span>
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Buscar por código o nombre de producto..."
                    className="w-full pl-10 pr-9 py-2.5 bg-surface rounded-lg border border-surface-variant focus:border-primary focus:ring-1 focus:ring-primary text-sm text-on-surface placeholder:text-outline-variant outline-none transition-all"
                  />
                  {searchQuery && (
                    <button
                      onClick={() => setSearchQuery('')}
                      className="absolute right-2.5 top-1/2 -translate-y-1/2 text-outline hover:text-on-surface p-1"
                    >
                      <span className="material-symbols-outlined text-sm">cancel</span>
                    </button>
                  )}
                </div>

                {/* SELECTOR CATEGORÍA */}
                <div className="w-full sm:w-56">
                  <select
                    value={categoryFilter}
                    onChange={(e) => {
                      setCategoryFilter(e.target.value);
                      setCurrentPage(1);
                    }}
                    className="w-full py-2.5 px-3 bg-surface rounded-lg border border-surface-variant focus:border-primary focus:ring-1 focus:ring-primary text-xs font-semibold text-on-surface outline-none cursor-pointer"
                  >
                    <option value="all">Todas las categorías</option>
                    {categories && categories.length > 0 ? (
                      categories.map((c) => (
                        <option key={c.name} value={c.name}>
                          {c.name}
                        </option>
                      ))
                    ) : (
                      <>
                        <option value="Cuadernos">Cuadernos</option>
                        <option value="Lápices y Bolígrafos">Lápices y Bolígrafos</option>
                        <option value="Colores y Arte">Colores y Arte</option>
                        <option value="Borradores">Borradores</option>
                        <option value="Adhesivos y pegantes">Adhesivos y pegantes</option>
                        <option value="Escolar">Escolar</option>
                      </>
                    )}
                  </select>
                </div>

                {/* SELECTOR ESTADO STOCK */}
                <div className="w-full sm:w-48">
                  <select
                    value={statusFilter}
                    onChange={(e) => setStatusFilter(e.target.value)}
                    className="w-full py-2.5 px-3 bg-surface rounded-lg border border-surface-variant focus:border-primary focus:ring-1 focus:ring-primary text-xs font-semibold text-on-surface outline-none cursor-pointer"
                  >
                    <option value="all">Todos los estados</option>
                    <option value="Disponible">Disponible</option>
                    <option value="Stock bajo">Stock bajo</option>
                    <option value="Agotado">Agotado</option>
                  </select>
                </div>
              </div>

              {/* BOTÓN RESTABLECER */}
              <div className="flex items-center gap-2 self-end md:self-auto">
                <button
                  onClick={resetFilters}
                  className="p-2.5 border border-surface-variant rounded-lg text-on-surface-variant hover:text-on-surface hover:bg-surface transition-colors flex items-center gap-1 text-xs font-semibold cursor-pointer"
                  title="Restablecer filtros"
                >
                  <span className="material-symbols-outlined text-[18px]">restart_alt</span>
                  <span className="hidden sm:inline">Restablecer</span>
                </button>
              </div>
            </div>

            {/* TABLA DE EXISTENCIAS */}
            <div className="bg-surface-container-lowest border border-surface-variant rounded-xl overflow-hidden shadow-xs">
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="bg-surface-container-low border-b border-surface-variant text-xs font-bold text-on-surface-variant select-none">
                      <th className="py-3.5 px-4 font-bold">Producto</th>
                      <th className="py-3.5 px-4 font-bold">Categoría</th>
                      <th className="py-3.5 px-4 font-bold text-center">Disponible</th>
                      <th className="py-3.5 px-4 font-bold text-center">Stock mín.</th>
                      <th className="py-3.5 px-4 font-bold text-center">Estado</th>
                      <th className="py-3.5 px-4 font-bold text-right">Acciones</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-surface-variant text-sm">
                    {filteredProducts.map((p) => {
                      const isOut = p.stock === 0;
                      const isLow = p.stock > 0 && p.stock <= p.minStock;

                      return (
                        <tr
                          key={p.code}
                          className={`hover:bg-surface transition-colors ${
                            isOut ? 'bg-rose-50/20' : isLow ? 'bg-amber-50/20' : ''
                          }`}
                        >
                          <td className="py-3.5 px-4">
                            <div className="flex items-center gap-3">
                              <div className="w-10 h-10 rounded-lg bg-surface-container flex items-center justify-center text-outline flex-shrink-0 border border-surface-variant">
                                <span className="material-symbols-outlined text-[20px]">
                                  {p.category.includes('Papel') ? 'description' : p.category.includes('Pegante') ? 'science' : 'menu_book'}
                                </span>
                              </div>
                              <div className="flex flex-col min-w-0">
                                <span className="font-bold text-on-surface truncate text-sm">{p.name}</span>
                                <span className="text-xs text-outline font-mono">{p.code}</span>
                              </div>
                            </div>
                          </td>
                          <td className="py-3.5 px-4">
                            <span className="inline-block px-2.5 py-0.5 rounded-full bg-surface-container text-on-surface-variant text-xs font-medium">
                              {p.category}
                            </span>
                          </td>
                          <td className="py-3.5 px-4 text-center">
                            <span className={`text-base font-bold ${isOut ? 'text-rose-700' : isLow ? 'text-amber-900' : 'text-on-surface'}`}>
                              {p.stock}
                            </span>
                            <span className="text-xs text-on-surface-variant ml-1">unids</span>
                          </td>
                          <td className="py-3.5 px-4 text-center">
                            <span className="text-xs text-on-surface-variant font-medium">Mín: {p.minStock} unids</span>
                          </td>
                          <td className="py-3.5 px-4 text-center">
                            {isOut ? (
                              <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-rose-700 bg-rose-50 border border-rose-200 text-xs font-bold">
                                <span className="w-1.5 h-1.5 rounded-full bg-rose-600"></span>
                                Agotado
                              </span>
                            ) : isLow ? (
                              <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-amber-800 bg-amber-50 border border-amber-300 text-xs font-bold">
                                <span className="w-1.5 h-1.5 rounded-full bg-amber-600 animate-pulse"></span>
                                Stock bajo
                              </span>
                            ) : (
                              <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-emerald-700 bg-emerald-50 border border-emerald-200 text-xs font-bold">
                                <span className="w-1.5 h-1.5 rounded-full bg-emerald-600"></span>
                                Disponible
                              </span>
                            )}
                          </td>
                          <td className="py-3.5 px-4 text-right">
                            <div className="inline-flex items-center gap-2">
                              <button
                                onClick={() => handleOpenEntrada(p)}
                                className="px-2.5 py-1.5 rounded-lg bg-primary-container/40 hover:bg-primary-container text-on-surface text-xs font-bold transition-colors border border-primary-fixed-dim cursor-pointer"
                              >
                                + Agregar stock
                              </button>
                              <button
                                onClick={() => handleOpenAjuste(p)}
                                className="p-1.5 rounded-lg border border-surface-variant text-on-surface-variant hover:text-on-surface hover:bg-surface-container transition-colors cursor-pointer"
                                title="Ajustar existencias"
                              >
                                <span className="material-symbols-outlined text-[18px]">tune</span>
                              </button>
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>

              {filteredProducts.length === 0 && (
                <div className="p-12 text-center flex flex-col items-center justify-center">
                  <div className="w-14 h-14 rounded-full bg-surface-container flex items-center justify-center text-outline mb-3">
                    <span className="material-symbols-outlined text-3xl">search_off</span>
                  </div>
                  <h3 className="text-base font-bold text-on-surface">No se encontraron productos</h3>
                  <p className="text-sm text-on-surface-variant max-w-sm mt-1">
                    No hay existencias registradas con el código o nombre ingresado.
                  </p>
                  <button
                    onClick={resetFilters}
                    className="mt-4 px-4 py-2 bg-primary-container text-on-surface rounded-lg text-xs font-bold hover:bg-[#e5bd1b] transition-colors"
                  >
                    Ver todos los productos
                  </button>
                </div>
              )}

              {/* PIE DE TABLA / PAGINACIÓN */}
              <div className="px-6 py-4 bg-surface-container-low border-t border-surface-variant flex items-center justify-between text-xs text-on-surface-variant">
                <span>Mostrando {filteredProducts.length} de {products.length} referencias registradas</span>
                <div className="flex items-center gap-2">
                  <button className="px-3 py-1.5 rounded-md border border-surface-variant bg-surface-container-lowest text-on-surface disabled:opacity-40" disabled>
                    Anterior
                  </button>
                  <span className="px-2 font-bold text-on-surface">Página 1 de 1</span>
                  <button className="px-3 py-1.5 rounded-md border border-surface-variant bg-surface-container-lowest text-on-surface disabled:opacity-40" disabled>
                    Siguiente
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ================= PESTAÑA 2: MOVIMIENTOS ================= */}
        {activeTab === 'movimientos' && (
          <div className="flex flex-col gap-6">
            <div className="bg-surface-container-lowest p-4 rounded-xl border border-surface-variant shadow-xs flex flex-wrap gap-4 items-center justify-between">
              <div className="flex flex-wrap items-center gap-3 flex-1">
                <div className="inline-flex items-center gap-2 px-3 py-2 bg-surface rounded-lg border border-surface-variant text-xs text-on-surface">
                  <span className="material-symbols-outlined text-outline text-[18px]">calendar_month</span>
                  <span className="font-semibold">Hoy, 24 Octubre 2024</span>
                </div>
              </div>
              <div className="text-xs font-semibold text-on-surface-variant bg-surface-container-low px-3 py-1.5 rounded-lg border border-surface-variant">
                Auditoría en tiempo real con trazabilidad de Kits
              </div>
            </div>

            <div className="bg-surface-container-lowest border border-surface-variant rounded-xl overflow-hidden shadow-xs">
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="bg-surface-container-low border-b border-surface-variant text-xs font-bold text-on-surface-variant select-none">
                      <th className="py-3.5 px-4 font-bold">Fecha / Hora</th>
                      <th className="py-3.5 px-4 font-bold">Producto</th>
                      <th className="py-3.5 px-4 font-bold">Tipo movimiento</th>
                      <th className="py-3.5 px-4 font-bold text-center">Cantidad</th>
                      <th className="py-3.5 px-4 font-bold">Motivo / Referencia</th>
                      <th className="py-3.5 px-4 font-bold">Responsable</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-surface-variant text-sm">
                    {movements.map((m) => (
                      <tr key={m.id} className="hover:bg-surface transition-colors">
                        <td className="py-3.5 px-4 text-xs text-on-surface-variant font-mono">{m.dateTime}</td>
                        <td className="py-3.5 px-4">
                          <div className="flex flex-col">
                            <span className="font-bold text-on-surface text-sm">{m.productName}</span>
                            <span className="text-xs text-outline font-mono">{m.productCode}</span>
                          </div>
                        </td>
                        <td className="py-3.5 px-4">
                          {m.type === 'entrada' ? (
                            <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-emerald-800 bg-emerald-50 border border-emerald-300 text-xs font-bold">
                              <span className="material-symbols-outlined text-[14px]">arrow_downward</span>
                              {m.typeLabel}
                            </span>
                          ) : m.type === 'salida_kit' ? (
                            <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-blue-800 bg-blue-50 border border-blue-200 text-xs font-bold">
                              <span className="material-symbols-outlined text-[14px]">inventory_2</span>
                              {m.typeLabel}
                            </span>
                          ) : m.type === 'salida_venta' ? (
                            <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-slate-800 bg-slate-100 border border-slate-300 text-xs font-semibold">
                              <span className="material-symbols-outlined text-[14px]">point_of_sale</span>
                              {m.typeLabel}
                            </span>
                          ) : (
                            <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-amber-900 bg-amber-50 border border-amber-300 text-xs font-bold">
                              <span className="material-symbols-outlined text-[14px]">content_paste_off</span>
                              {m.typeLabel}
                            </span>
                          )}
                        </td>
                        <td className="py-3.5 px-4 text-center">
                          <span className={`font-bold font-mono text-base ${m.quantity > 0 ? 'text-emerald-700' : 'text-rose-600'}`}>
                            {m.quantity > 0 ? `+${m.quantity}` : m.quantity}
                          </span>
                        </td>
                        <td className="py-3.5 px-4 text-xs text-on-surface">
                          {m.reference}
                        </td>
                        <td className="py-3.5 px-4 text-xs font-medium text-on-surface">{m.responsible}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}
      </main>

      {/* ================= MODAL 1: REGISTRAR ENTRADA DE MERCANCÍA ================= */}
      {modalEntradaOpen && selectedProductForEntrada && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-inverse-surface/40 backdrop-blur-xs">
          <div className="bg-surface-container-lowest rounded-2xl border border-surface-variant shadow-2xl max-w-lg w-full overflow-hidden">
            <div className="px-6 py-4 border-b border-surface-variant flex items-center justify-between bg-surface-container-low">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-primary-container text-on-surface flex items-center justify-center font-bold">
                  <span className="material-symbols-outlined text-base">add_box</span>
                </div>
                <h2 className="text-base font-bold text-on-surface">Registrar entrada de mercancía</h2>
              </div>
              <button
                onClick={() => setModalEntradaOpen(false)}
                className="text-outline hover:text-on-surface p-1 rounded-md"
              >
                <span className="material-symbols-outlined">close</span>
              </button>
            </div>

            <form onSubmit={handleSaveEntrada} className="p-6 flex flex-col gap-4">
              <div className="p-3 bg-surface rounded-xl border border-surface-variant flex items-center justify-between">
                <div>
                  <span className="font-bold text-on-surface text-sm block">{selectedProductForEntrada.name}</span>
                  <span className="text-xs text-outline font-mono">{selectedProductForEntrada.code}</span>
                </div>
                <div className="text-right">
                  <span className="text-[11px] uppercase tracking-wider text-on-surface-variant font-semibold block">Stock actual</span>
                  <span className="text-base font-bold text-on-surface">{selectedProductForEntrada.stock} <span className="text-xs font-normal">unids</span></span>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-on-surface mb-1">Unidades recibidas *</label>
                <input
                  type="number"
                  min={1}
                  required
                  value={unidadesEntrada}
                  onChange={(e) => setUnidadesEntrada(Number(e.target.value) || 0)}
                  className="w-full px-3.5 py-2.5 bg-surface rounded-lg border border-surface-variant focus:border-primary text-lg font-bold text-on-surface outline-none"
                />
                <p className="text-xs text-on-surface-variant mt-1">Ingresa el total exacto recibido del proveedor.</p>
              </div>

              <div>
                <label className="block text-xs font-bold text-on-surface mb-1">Observación o factura proveedor</label>
                <input
                  type="text"
                  value={facturaEntrada}
                  onChange={(e) => setFacturaEntrada(e.target.value)}
                  placeholder="Ej: Factura Distribuidora Nacional #45892"
                  className="w-full px-3.5 py-2.5 bg-surface rounded-lg border border-surface-variant focus:border-primary text-sm text-on-surface outline-none"
                />
              </div>

              <div className="p-3.5 bg-primary-container/20 rounded-xl border border-primary-fixed-dim/70 flex flex-col gap-1.5">
                <span className="text-xs font-bold text-on-surface flex items-center gap-1.5">
                  <span className="material-symbols-outlined text-sm text-primary">visibility</span>
                  Cálculo proyectado del saldo
                </span>
                <div className="text-xs text-on-surface-variant flex flex-wrap items-center gap-2 font-mono">
                  <span>Anterior: <strong>{selectedProductForEntrada.stock}</strong> unids</span>
                  <span>+</span>
                  <span>Recibidas: <strong>{unidadesEntrada}</strong> unids</span>
                  <span>=</span>
                  <span className="text-emerald-800 font-bold text-sm bg-emerald-100 px-2 py-0.5 rounded">
                    Nueva cant: {selectedProductForEntrada.stock + unidadesEntrada} unidades
                  </span>
                </div>
                <span className="text-[11px] text-emerald-800 font-semibold mt-0.5">
                  ✓ Pasa automáticamente a estado: "Disponible"
                </span>
              </div>

              <div className="pt-3 border-t border-surface-variant flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setModalEntradaOpen(false)}
                  className="px-4 py-2.5 rounded-lg border border-surface-variant text-xs text-on-surface font-semibold hover:bg-surface-container"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-lg bg-primary-container hover:bg-[#e5bd1b] text-on-surface text-xs font-bold transition-all shadow-xs"
                >
                  Guardar entrada
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ================= MODAL 2: AJUSTAR EXISTENCIAS ================= */}
      {modalAjusteOpen && selectedProductForAjuste && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-inverse-surface/40 backdrop-blur-xs">
          <div className="bg-surface-container-lowest rounded-2xl border border-surface-variant shadow-2xl max-w-lg w-full overflow-hidden">
            <div className="px-6 py-4 border-b border-surface-variant flex items-center justify-between bg-surface-container-low">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-surface-container text-on-surface flex items-center justify-center font-bold">
                  <span className="material-symbols-outlined text-base">tune</span>
                </div>
                <div>
                  <h2 className="text-base font-bold text-on-surface">Ajuste de inventario</h2>
                  <p className="text-xs text-outline">
                    {selectedProductForAjuste.name} - Código {selectedProductForAjuste.code}
                  </p>
                </div>
              </div>
              <button
                onClick={() => setModalAjusteOpen(false)}
                className="text-outline hover:text-on-surface p-1 rounded-md"
              >
                <span className="material-symbols-outlined">close</span>
              </button>
            </div>

            <form onSubmit={handleSaveAjuste} className="p-6 flex flex-col gap-4">
              <div className="grid grid-cols-2 gap-3">
                <label
                  onClick={() => setAjusteModo('salida')}
                  className={`cursor-pointer border-2 rounded-xl p-3 flex flex-col gap-1 transition-all ${
                    ajusteModo === 'salida'
                      ? 'border-primary bg-primary-container/15'
                      : 'border-surface-variant bg-surface'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-on-surface">Registrar salida</span>
                    <span className="material-symbols-outlined text-amber-700 text-sm">remove_circle_outline</span>
                  </div>
                  <span className="text-[11px] text-on-surface-variant leading-tight">Por merma, daño, vencimiento o uso interno.</span>
                </label>

                <label
                  onClick={() => setAjusteModo('conteo')}
                  className={`cursor-pointer border-2 rounded-xl p-3 flex flex-col gap-1 transition-all ${
                    ajusteModo === 'conteo'
                      ? 'border-primary bg-primary-container/15'
                      : 'border-surface-variant bg-surface'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-on-surface">Conteo físico</span>
                    <span className="material-symbols-outlined text-primary text-sm">fact_check</span>
                  </div>
                  <span className="text-[11px] text-on-surface-variant leading-tight">Cuadre tras revisión de estantería.</span>
                </label>
              </div>

              {ajusteModo === 'salida' ? (
                <div className="flex flex-col gap-3">
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="text-xs font-bold text-on-surface">Unidades a retirar *</label>
                      <span className="text-xs text-on-surface-variant">Disponibles actuales: <strong>{selectedProductForAjuste.stock}</strong></span>
                    </div>
                    <input
                      type="number"
                      min={1}
                      max={selectedProductForAjuste.stock}
                      value={unidadesRetirar}
                      onChange={(e) => setUnidadesRetirar(Number(e.target.value) || 0)}
                      className="w-full px-3.5 py-2.5 bg-surface rounded-lg border border-surface-variant font-bold text-on-surface outline-none"
                    />
                    {unidadesRetirar > selectedProductForAjuste.stock && (
                      <p className="text-xs text-error font-semibold mt-1">Error: No puedes retirar más unidades de las disponibles.</p>
                    )}
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-on-surface mb-1">Motivo de salida *</label>
                    <select
                      value={motivoSalida}
                      onChange={(e) => setMotivoSalida(e.target.value)}
                      className="w-full py-2.5 px-3 bg-surface rounded-lg border border-surface-variant text-sm text-on-surface outline-none"
                    >
                      <option>Daño / deterioro de empaque</option>
                      <option>Pérdida o merma</option>
                      <option>Uso interno del local</option>
                      <option>Devolución a proveedor</option>
                    </select>
                  </div>
                </div>
              ) : (
                <div className="flex flex-col gap-3">
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="text-xs font-bold text-on-surface">Cantidad contada en estantería *</label>
                      <span className="text-xs text-on-surface-variant">En sistema: <strong>{selectedProductForAjuste.stock}</strong> unids</span>
                    </div>
                    <input
                      type="number"
                      min={0}
                      value={conteoFisico}
                      onChange={(e) => setConteoFisico(Number(e.target.value) || 0)}
                      className="w-full px-3.5 py-2.5 bg-surface rounded-lg border border-surface-variant font-bold text-on-surface outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-on-surface mb-1">Motivo de la corrección</label>
                    <select
                      value={motivoConteo}
                      onChange={(e) => setMotivoConteo(e.target.value)}
                      className="w-full py-2.5 px-3 bg-surface rounded-lg border border-surface-variant text-sm text-on-surface outline-none"
                    >
                      <option>Conteo periódico de estantería</option>
                      <option>Error en registro previo</option>
                      <option>Ajuste de descuadre mensual</option>
                    </select>
                  </div>
                </div>
              )}

              {/* CÁLCULO VISIBLE */}
              <div className="p-3 bg-surface-container-low rounded-xl border border-surface-variant font-mono text-xs flex flex-wrap items-center justify-between gap-2">
                <span className="text-on-surface-variant">Stock en sistema: <strong className="text-on-surface">{selectedProductForAjuste.stock} unids</strong></span>
                <span className="text-on-surface font-bold bg-surface-container px-2 py-0.5 rounded">
                  Resultado final:{' '}
                  {ajusteModo === 'salida'
                    ? Math.max(0, selectedProductForAjuste.stock - unidadesRetirar)
                    : conteoFisico}{' '}
                  unids
                </span>
              </div>

              <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl flex items-start gap-2.5">
                <span className="material-symbols-outlined text-amber-800 text-sm mt-0.5">info</span>
                <p className="text-xs text-amber-900 leading-snug">
                  <strong>Advertencia:</strong> Esta acción actualizará de inmediato el saldo disponible en tienda y kits escolares asociados.
                </p>
              </div>

              <label className="flex items-center gap-2 cursor-pointer select-none">
                <input
                  type="checkbox"
                  required
                  checked={checkConfirmacion}
                  onChange={(e) => setCheckConfirmacion(e.target.checked)}
                  className="rounded border-surface-variant text-primary focus:ring-primary w-4 h-4"
                />
                <span className="text-xs font-semibold text-on-surface">
                  He verificado físicamente el producto y confirmo el ajuste.
                </span>
              </label>

              <div className="pt-2 border-t border-surface-variant flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setModalAjusteOpen(false)}
                  className="px-4 py-2.5 rounded-lg border border-surface-variant text-xs text-on-surface font-semibold hover:bg-surface-container"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  disabled={!checkConfirmacion}
                  className="px-5 py-2.5 rounded-lg bg-primary-container hover:bg-[#e5bd1b] text-on-surface text-xs font-bold transition-all shadow-xs disabled:opacity-50 cursor-pointer"
                >
                  Confirmar ajuste
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
