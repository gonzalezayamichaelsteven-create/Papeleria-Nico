import React, { useState } from 'react';

interface AdminAuthProps {
  onLoginSuccess: () => void;
  onBackToCatalog: () => void;
}

type AuthView = 'login' | 'recovery' | 'reset' | 'expired';

export const AdminAuth: React.FC<AdminAuthProps> = ({
  onLoginSuccess,
  onBackToCatalog
}) => {
  const [currentView, setCurrentView] = useState<AuthView>('login');

  // Login form state
  const [emailOrUser, setEmailOrUser] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loginLoading, setLoginLoading] = useState(false);
  const [loginError, setLoginError] = useState(false);
  const [loginSuccess, setLoginSuccess] = useState(false);

  // Recovery form state
  const [recoveryEmail, setRecoveryEmail] = useState('');
  const [recoverySent, setRecoverySent] = useState(false);
  const [recoveryLoading, setRecoveryLoading] = useState(false);

  // Reset password form state
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [passwordMatchError, setPasswordMatchError] = useState(false);
  const [resetSuccess, setResetSuccess] = useState(false);
  const [resetLoading, setResetLoading] = useState(false);

  // Demo Login: un clic directo para evaluadores y revisión inmediata
  const handleDemoLogin = () => {
    setLoginLoading(true);
    setLoginError(false);
    setTimeout(() => {
      setLoginLoading(false);
      setLoginSuccess(true);
      setTimeout(() => {
        onLoginSuccess();
      }, 500);
    }, 400);
  };

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError(false);
    setLoginSuccess(false);

    // Si simula credencial errónea
    if (password === 'passwordInvalida123' || password === 'error') {
      setLoginError(true);
      return;
    }

    setLoginLoading(true);
    setTimeout(() => {
      setLoginLoading(false);
      setLoginSuccess(true);
      setTimeout(() => {
        onLoginSuccess();
      }, 500);
    }, 500);
  };

  const handleRecoverySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setRecoveryLoading(true);
    setTimeout(() => {
      setRecoveryLoading(false);
      setRecoverySent(true);
    }, 600);
  };

  const handleResetSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (newPassword !== confirmPassword) {
      setPasswordMatchError(true);
      return;
    }
    setPasswordMatchError(false);
    setResetLoading(true);
    setTimeout(() => {
      setResetLoading(false);
      setResetSuccess(true);
    }, 600);
  };

  return (
    <div className="bg-background text-on-surface antialiased min-h-screen flex flex-col justify-between selection:bg-primary-container selection:text-on-primary-fixed">
      {/* Contenedor Principal (centrado limpio) */}
      <main className="flex-1 flex flex-col justify-center items-center px-4 py-8 md:py-12 w-full max-w-[1440px] mx-auto">
        {/* Tarjeta Central de Autenticación (440px) */}
        <div className="w-full max-w-[440px] bg-surface-container-lowest rounded-xl border border-surface-variant shadow-sm p-6 sm:p-8 relative">
          
          {/* ACCESO DEMO BANNER EN PROMINENCIA SUPERIOR */}
          {currentView === 'login' && (
            <div className="mb-5 p-3 rounded-lg bg-primary-container/25 border border-primary-container flex items-start gap-2.5">
              <span className="material-symbols-outlined text-primary text-[22px] shrink-0 mt-0.5" style={{ fontVariationSettings: "'FILL' 1" }}>
                verified_user
              </span>
              <div className="flex-1">
                <span className="text-xs font-bold text-on-surface block">Acceso de demostración para revisión</span>
                <p className="text-[11px] text-on-surface-variant mt-0.5">
                  Puedes ingresar con 1 solo clic como <strong>Carlos M. (Administrador)</strong> para revisar todas las pantallas.
                </p>
                <button
                  type="button"
                  onClick={handleDemoLogin}
                  disabled={loginLoading}
                  className="mt-2 w-full py-1.5 px-3 rounded-lg bg-primary-container hover:bg-[#e5bd1b] active:scale-98 text-on-surface font-bold text-xs flex items-center justify-center gap-1.5 transition-all shadow-xs"
                >
                  <span className="material-symbols-outlined text-base">login</span>
                  <span>Ingresar como Administrador (Demo)</span>
                </button>
              </div>
            </div>
          )}

          {/* ========================================== */}
          {/* VISTA 1: INICIAR SESIÓN                     */}
          {/* ========================================== */}
          {currentView === 'login' && (
            <section className="transition-all duration-200">
              <div className="flex flex-col items-center text-center mb-6">
                <div className="w-20 h-20 rounded-xl overflow-hidden border border-surface-variant shadow-xs mb-4 bg-surface-container-low p-1.5 flex items-center justify-center">
                  <img
                    src="https://lh3.googleusercontent.com/aida-public/AB6AXuCRSD000prE69m2RVqEsdCqOdNa09w7MXHnDNYoLCpU2D14dxOhIOHIhVo98lkS11cy3ESzLzK_IWPZewu51Po9PJ7iNWT8F6mhR2-2Xozujy49dLjzkW-jTglo-ugRzEpcrsFN4ugsx6rmBAME7xYJA7A0Uk5xny_aifqzioipNnI42AhFE9XQ3tGw-xbMRjniYVykppz1j6b5eL5KnwlRWusxCppT5eSArmdIaQKI0GSGB_SM1nYj815i7j2mVptlswI"
                    alt="Papelería Nico Logo Oficial"
                    className="w-full h-full object-contain"
                  />
                </div>
                <h1 className="text-xl font-bold text-on-surface mb-1">
                  Iniciar sesión
                </h1>
                <p className="text-sm text-on-surface-variant">Acceso para administrar inventario y ventas</p>
              </div>

              {/* Banner de Error Simulado */}
              {loginError && (
                <div className="mb-5 p-3 rounded-lg bg-error-container text-on-error-container border border-error/20 flex items-start gap-2.5">
                  <span className="material-symbols-outlined text-error text-[20px] shrink-0">error</span>
                  <div className="text-xs">
                    <span className="font-bold">Credenciales incorrectas:</span> El usuario o la contraseña ingresados no son correctos.
                  </div>
                </div>
              )}

              {/* Banner de Éxito / Redirección */}
              {loginSuccess && (
                <div className="mb-5 p-3 rounded-lg bg-emerald-50 text-emerald-800 border border-emerald-200 flex items-center gap-2.5">
                  <span className="material-symbols-outlined text-emerald-700 text-[20px] animate-spin">
                    progress_activity
                  </span>
                  <div className="text-xs font-semibold">
                    Acceso concedido. Redirigiendo a Inicio administrativo...
                  </div>
                </div>
              )}

              {/* Formulario de Login */}
              <form onSubmit={handleLoginSubmit} className="space-y-4">
                <div>
                  <label className="block text-sm font-semibold text-on-surface mb-1.5" htmlFor="login-email">
                    Usuario o correo
                  </label>
                  <div className="relative">
                    <span className="material-symbols-outlined absolute left-3 top-1/2 -translate-y-1/2 text-tertiary text-[20px] pointer-events-none">
                      person
                    </span>
                    <input
                      id="login-email"
                      type="text"
                      required
                      value={emailOrUser}
                      onChange={(e) => setEmailOrUser(e.target.value)}
                      placeholder="ejemplo@correo.com o usuario"
                      className="w-full h-11 pl-10 pr-3 rounded-lg border border-surface-variant bg-surface-container-lowest text-on-surface text-sm placeholder:text-outline-variant focus:outline-none focus:border-primary-container focus:ring-2 focus:ring-primary-container/30 transition-all"
                    />
                  </div>
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <label className="block text-sm font-semibold text-on-surface" htmlFor="login-password">
                      Contraseña
                    </label>
                    <button
                      type="button"
                      onClick={() => setCurrentView('recovery')}
                      className="text-xs text-primary hover:text-on-surface font-semibold transition-colors focus:outline-none"
                    >
                      ¿Olvidaste tu contraseña?
                    </button>
                  </div>
                  <div className="relative">
                    <span className="material-symbols-outlined absolute left-3 top-1/2 -translate-y-1/2 text-tertiary text-[20px] pointer-events-none">
                      lock
                    </span>
                    <input
                      id="login-password"
                      type={showPassword ? 'text' : 'password'}
                      required
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="Ingresa tu contraseña"
                      className="w-full h-11 pl-10 pr-10 rounded-lg border border-surface-variant bg-surface-container-lowest text-on-surface text-sm placeholder:text-outline-variant focus:outline-none focus:border-primary-container focus:ring-2 focus:ring-primary-container/30 transition-all"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-2.5 top-1/2 -translate-y-1/2 text-tertiary hover:text-on-surface p-1 rounded transition-colors focus:outline-none"
                      title="Mostrar u ocultar contraseña"
                    >
                      <span className="material-symbols-outlined text-[20px] block">
                        {showPassword ? 'visibility_off' : 'visibility'}
                      </span>
                    </button>
                  </div>
                </div>

                {/* Botón de acción principal */}
                <div className="pt-2">
                  <button
                    type="submit"
                    disabled={loginLoading}
                    className="w-full h-11 bg-primary-container hover:bg-[#e5bd1b] text-on-surface text-sm font-bold rounded-lg shadow-sm active:scale-[0.99] transition-all flex items-center justify-center gap-2 cursor-pointer"
                  >
                    {loginLoading ? (
                      <span className="material-symbols-outlined animate-spin text-[20px]">progress_activity</span>
                    ) : (
                      <span>Ingresar</span>
                    )}
                  </button>
                </div>
              </form>

              {/* Selector de vistas para testeo rápido */}
              <div className="mt-4 pt-3 border-t border-surface-variant/60 flex items-center justify-center gap-3 text-[11px] text-tertiary">
                <button
                  type="button"
                  onClick={() => setCurrentView('recovery')}
                  className="hover:underline"
                >
                  Probar recuperación
                </button>
                <span>•</span>
                <button
                  type="button"
                  onClick={() => setCurrentView('reset')}
                  className="hover:underline"
                >
                  Probar nueva clave
                </button>
                <span>•</span>
                <button
                  type="button"
                  onClick={() => setCurrentView('expired')}
                  className="hover:underline"
                >
                  Enlace vencido
                </button>
              </div>

              {/* Enlace inferior al catálogo público */}
              <div className="mt-5 pt-4 border-t border-surface-variant">
                <button
                  type="button"
                  onClick={onBackToCatalog}
                  className="w-full min-h-[44px] py-2.5 px-4 rounded-xl border border-surface-variant bg-surface-container-low hover:bg-surface-container active:scale-[0.99] text-on-surface text-sm font-semibold flex items-center justify-center gap-2 transition-all shadow-xs cursor-pointer"
                >
                  <span className="material-symbols-outlined text-[20px] text-on-surface">arrow_back</span>
                  <span>Volver al catálogo</span>
                </button>
              </div>
            </section>
          )}

          {/* ========================================== */}
          {/* VISTA 2: RECUPERAR ACCESO                   */}
          {/* ========================================== */}
          {currentView === 'recovery' && (
            <section className="transition-all duration-200">
              <div className="flex flex-col items-center text-center mb-6">
                <div className="w-12 h-12 rounded-xl bg-surface-container-low border border-surface-variant flex items-center justify-center text-primary mb-3">
                  <span className="material-symbols-outlined text-[26px]">lock_reset</span>
                </div>
                <h2 className="text-xl font-bold text-on-surface mb-1">
                  Recuperar acceso
                </h2>
                <p className="text-xs text-on-surface-variant">
                  Ingresa tu correo registrado y te enviaremos un enlace seguro para restablecer tu contraseña.
                </p>
              </div>

              {recoverySent ? (
                <div className="p-4 rounded-lg bg-surface-container-low border border-surface-variant text-center space-y-3">
                  <div className="w-10 h-10 mx-auto rounded-full bg-primary-container/20 flex items-center justify-center text-primary">
                    <span className="material-symbols-outlined text-[22px]">mail</span>
                  </div>
                  <p className="text-xs text-on-surface leading-relaxed">
                    Si el correo está asociado a una cuenta administrativa, recibirás instrucciones para restablecer tu clave.
                  </p>
                  <div className="pt-2 flex flex-col gap-2">
                    <button
                      type="button"
                      onClick={() => setCurrentView('reset')}
                      className="w-full py-2 px-3 rounded-lg bg-primary-container text-on-surface font-bold text-xs hover:bg-[#e5bd1b] transition-all"
                    >
                      Continuar al cambio de clave (Demo)
                    </button>
                    <button
                      type="button"
                      onClick={() => setCurrentView('login')}
                      className="w-full py-2 px-3 text-xs text-primary font-bold hover:underline"
                    >
                      Volver a iniciar sesión
                    </button>
                  </div>
                </div>
              ) : (
                <form onSubmit={handleRecoverySubmit} className="space-y-4">
                  <div>
                    <label className="block text-sm font-semibold text-on-surface mb-1.5" htmlFor="recovery-email">
                      Correo electrónico
                    </label>
                    <div className="relative">
                      <span className="material-symbols-outlined absolute left-3 top-1/2 -translate-y-1/2 text-tertiary text-[20px] pointer-events-none">
                        mail
                      </span>
                      <input
                        id="recovery-email"
                        type="email"
                        required
                        value={recoveryEmail}
                        onChange={(e) => setRecoveryEmail(e.target.value)}
                        placeholder="ej. admin@papelerianico.com"
                        className="w-full h-11 pl-10 pr-3 rounded-lg border border-surface-variant bg-surface-container-lowest text-on-surface text-sm placeholder:text-outline-variant focus:outline-none focus:border-primary-container focus:ring-2 focus:ring-primary-container/30 transition-all"
                      />
                    </div>
                  </div>

                  <div className="pt-2 space-y-2">
                    <button
                      type="submit"
                      disabled={recoveryLoading}
                      className="w-full h-11 bg-primary-container hover:bg-[#e5bd1b] text-on-surface text-sm font-bold rounded-lg shadow-sm active:scale-[0.99] transition-all flex items-center justify-center gap-2 cursor-pointer"
                    >
                      {recoveryLoading ? (
                        <span className="material-symbols-outlined animate-spin text-[20px]">progress_activity</span>
                      ) : (
                        <span>Enviar enlace</span>
                      )}
                    </button>
                    <button
                      type="button"
                      onClick={() => setCurrentView('login')}
                      className="w-full h-10 border border-surface-variant hover:bg-surface-container-low text-on-surface text-sm font-semibold rounded-lg transition-colors flex items-center justify-center"
                    >
                      Volver a iniciar sesión
                    </button>
                  </div>
                </form>
              )}
            </section>
          )}

          {/* ========================================== */}
          {/* VISTA 3: NUEVA CONTRASEÑA                   */}
          {/* ========================================== */}
          {currentView === 'reset' && (
            <section className="transition-all duration-200">
              <div className="flex flex-col items-center text-center mb-6">
                <div className="w-12 h-12 rounded-xl bg-surface-container-low border border-surface-variant flex items-center justify-center text-primary mb-3">
                  <span className="material-symbols-outlined text-[26px]">key</span>
                </div>
                <h2 className="text-xl font-bold text-on-surface mb-1">
                  Crear nueva contraseña
                </h2>
                <p className="text-xs text-on-surface-variant">
                  Define una contraseña segura de mínimo 8 caracteres para tu cuenta administrativa.
                </p>
              </div>

              {resetSuccess ? (
                <div className="p-4 rounded-lg bg-surface-container-low border border-surface-variant text-center space-y-3">
                  <div className="w-10 h-10 mx-auto rounded-full bg-primary-container/30 flex items-center justify-center text-primary">
                    <span className="material-symbols-outlined text-[24px]">check_circle</span>
                  </div>
                  <h3 className="text-base font-bold text-on-surface">¡Contraseña actualizada!</h3>
                  <p className="text-xs text-on-surface leading-relaxed">
                    Contraseña actualizada exitosamente. Ya puedes iniciar sesión con tu nueva clave.
                  </p>
                  <div className="pt-2">
                    <button
                      type="button"
                      onClick={() => setCurrentView('login')}
                      className="w-full h-11 bg-primary-container hover:bg-[#e5bd1b] text-on-surface text-sm font-bold rounded-lg shadow-sm transition-all flex items-center justify-center"
                    >
                      Iniciar sesión ahora
                    </button>
                  </div>
                </div>
              ) : (
                <form onSubmit={handleResetSubmit} className="space-y-4">
                  <div>
                    <label className="block text-sm font-semibold text-on-surface mb-1.5" htmlFor="new-password">
                      Nueva contraseña
                    </label>
                    <div className="relative">
                      <span className="material-symbols-outlined absolute left-3 top-1/2 -translate-y-1/2 text-tertiary text-[20px] pointer-events-none">
                        lock
                      </span>
                      <input
                        id="new-password"
                        type={showNewPassword ? 'text' : 'password'}
                        required
                        minLength={8}
                        value={newPassword}
                        onChange={(e) => setNewPassword(e.target.value)}
                        placeholder="Mínimo 8 caracteres"
                        className="w-full h-11 pl-10 pr-10 rounded-lg border border-surface-variant bg-surface-container-lowest text-on-surface text-sm placeholder:text-outline-variant focus:outline-none focus:border-primary-container focus:ring-2 focus:ring-primary-container/30 transition-all"
                      />
                      <button
                        type="button"
                        onClick={() => setShowNewPassword(!showNewPassword)}
                        className="absolute right-2.5 top-1/2 -translate-y-1/2 text-tertiary hover:text-on-surface p-1 rounded transition-colors"
                      >
                        <span className="material-symbols-outlined text-[20px] block">
                          {showNewPassword ? 'visibility_off' : 'visibility'}
                        </span>
                      </button>
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-on-surface mb-1.5" htmlFor="confirm-password">
                      Confirmar nueva contraseña
                    </label>
                    <div className="relative">
                      <span className="material-symbols-outlined absolute left-3 top-1/2 -translate-y-1/2 text-tertiary text-[20px] pointer-events-none">
                        lock_clock
                      </span>
                      <input
                        id="confirm-password"
                        type={showConfirmPassword ? 'text' : 'password'}
                        required
                        minLength={8}
                        value={confirmPassword}
                        onChange={(e) => setConfirmPassword(e.target.value)}
                        placeholder="Repite la contraseña"
                        className="w-full h-11 pl-10 pr-10 rounded-lg border border-surface-variant bg-surface-container-lowest text-on-surface text-sm placeholder:text-outline-variant focus:outline-none focus:border-primary-container focus:ring-2 focus:ring-primary-container/30 transition-all"
                      />
                      <button
                        type="button"
                        onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                        className="absolute right-2.5 top-1/2 -translate-y-1/2 text-tertiary hover:text-on-surface p-1 rounded transition-colors"
                      >
                        <span className="material-symbols-outlined text-[20px] block">
                          {showConfirmPassword ? 'visibility_off' : 'visibility'}
                        </span>
                      </button>
                    </div>
                    {passwordMatchError && (
                      <p className="text-xs text-error font-medium mt-1 flex items-center gap-1">
                        <span className="material-symbols-outlined text-[15px]">warning</span>
                        Las contraseñas no coinciden.
                      </p>
                    )}
                  </div>

                  <div className="p-3 bg-surface-container-low rounded-lg border border-surface-variant space-y-1 text-xs text-on-surface-variant">
                    <p className="font-semibold text-on-surface">Requisitos de seguridad:</p>
                    <div className="flex items-center gap-1.5 text-tertiary">
                      <span className="material-symbols-outlined text-[15px] text-[#137333]">check</span>
                      <span>Al menos 8 caracteres de longitud</span>
                    </div>
                  </div>

                  <div className="pt-2">
                    <button
                      type="submit"
                      disabled={resetLoading}
                      className="w-full h-11 bg-primary-container hover:bg-[#e5bd1b] text-on-surface text-sm font-bold rounded-lg shadow-sm active:scale-[0.99] transition-all flex items-center justify-center gap-2 cursor-pointer"
                    >
                      {resetLoading ? (
                        <span className="material-symbols-outlined animate-spin text-[20px]">progress_activity</span>
                      ) : (
                        <span>Guardar contraseña</span>
                      )}
                    </button>
                  </div>
                </form>
              )}

              <div className="mt-4 text-center">
                <button
                  type="button"
                  onClick={() => setCurrentView('login')}
                  className="text-xs text-on-surface-variant hover:text-on-surface font-medium transition-colors"
                >
                  ← Volver a inicio de sesión
                </button>
              </div>
            </section>
          )}

          {/* ========================================== */}
          {/* VISTA 4: ENLACE VENCIDO O INVÁLIDO          */}
          {/* ========================================== */}
          {currentView === 'expired' && (
            <section className="transition-all duration-200">
              <div className="flex flex-col items-center text-center mb-6">
                <div className="w-14 h-14 rounded-full bg-error-container text-error flex items-center justify-center mb-3">
                  <span className="material-symbols-outlined text-[30px]">link_off</span>
                </div>
                <h2 className="text-xl font-bold text-on-surface mb-2">
                  Enlace vencido o inválido
                </h2>
                <p className="text-xs text-on-surface-variant leading-relaxed">
                  Este enlace de restablecimiento ha expirado por seguridad o ya ha sido utilizado. Los enlaces tienen una validez de 30 minutos.
                </p>
              </div>
              <div className="space-y-3 pt-2">
                <button
                  type="button"
                  onClick={() => setCurrentView('recovery')}
                  className="w-full h-11 bg-primary-container hover:bg-[#e5bd1b] text-on-surface text-sm font-bold rounded-lg shadow-sm transition-all flex items-center justify-center gap-2"
                >
                  <span className="material-symbols-outlined text-[18px]">refresh</span>
                  <span>¿Solicitar un nuevo enlace?</span>
                </button>
                <button
                  type="button"
                  onClick={() => setCurrentView('login')}
                  className="w-full h-10 border border-surface-variant hover:bg-surface-container-low text-on-surface text-sm font-semibold rounded-lg transition-colors flex items-center justify-center"
                >
                  Volver a iniciar sesión
                </button>
              </div>
            </section>
          )}
        </div>
      </main>

      {/* Pie de página institucional */}
      <footer className="w-full bg-surface-container-low border-t border-surface-variant py-4">
        <div className="w-full max-w-7xl mx-auto px-4 text-center">
          <p className="text-xs text-tertiary">
            © 2024 Papelería Nico • Sede Torreón El Roble, Ibagué
          </p>
        </div>
      </footer>
    </div>
  );
};
