import React, { useState } from 'react';
import { AdminUser } from '../data/mockData';

interface AdminAccountProps {
  admins: AdminUser[];
  onAddAdmin: (user: AdminUser) => void;
}

export const AdminAccount: React.FC<AdminAccountProps> = ({
  admins,
  onAddAdmin
}) => {
  const [activeTab, setActiveTab] = useState<'admins' | 'account'>('admins');
  const [searchQuery, setSearchQuery] = useState('');

  // Modal registrar administrador
  const [modalOpen, setModalOpen] = useState(false);
  const [newName, setNewName] = useState('');
  const [newUsername, setNewUsername] = useState('');
  const [newEmail, setNewEmail] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPass1, setShowPass1] = useState(false);
  const [showPass2, setShowPass2] = useState(false);

  // Mi cuenta form states
  const [fullName, setFullName] = useState('Carlos Mario Mendoza');
  const [emailRecovery, setEmailRecovery] = useState('carlos.mendoza@papelerianico.com');
  const [currentPassForProfile, setCurrentPassForProfile] = useState('');
  const [profileSuccessMsg, setProfileSuccessMsg] = useState(false);

  // Change password form states
  const [currentPass, setCurrentPass] = useState('');
  const [newPass, setNewPass] = useState('');
  const [confirmNewPass, setConfirmNewPass] = useState('');
  const [showCurrentPass, setShowCurrentPass] = useState(false);
  const [showNewPass, setShowNewPass] = useState(false);
  const [showConfirmNewPass, setShowConfirmNewPass] = useState(false);
  const [passwordSuccessMsg, setPasswordSuccessMsg] = useState(false);

  const filteredAdmins = admins.filter((a) => {
    const q = searchQuery.toLowerCase().trim();
    return (
      q === '' ||
      a.name.toLowerCase().includes(q) ||
      a.username.toLowerCase().includes(q) ||
      a.email.toLowerCase().includes(q)
    );
  });

  const handleRegisterAdmin = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName.trim() || !newUsername.trim() || !newEmail.trim()) return;

    if (newPassword.length < 8) {
      alert('La contraseña debe tener mínimo 8 caracteres.');
      return;
    }

    if (newPassword !== confirmPassword) {
      alert('Las contraseñas no coinciden.');
      return;
    }

    const initials = newName
      .trim()
      .split(' ')
      .map((w) => w[0])
      .slice(0, 2)
      .join('')
      .toUpperCase();

    const newUser: AdminUser = {
      id: `ADM-${Date.now().toString().slice(-4)}`,
      name: newName.trim(),
      username: newUsername.trim().toLowerCase().replace(/[^a-z0-9_]/g, ''),
      email: newEmail.trim().toLowerCase(),
      role: 'Administrador',
      status: 'activo',
      lastAccess: 'Nunca',
      avatar: initials || 'AD'
    };

    onAddAdmin(newUser);
    setNewName('');
    setNewUsername('');
    setNewEmail('');
    setNewPassword('');
    setConfirmPassword('');
    setModalOpen(false);
    alert(`Administrador @${newUser.username} creado exitosamente.`);
  };

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentPassForProfile) {
      alert('Por seguridad, debes ingresar tu contraseña actual para confirmar los cambios de perfil.');
      return;
    }
    setProfileSuccessMsg(true);
    setTimeout(() => setProfileSuccessMsg(false), 3000);
  };

  const handleUpdatePassword = (e: React.FormEvent) => {
    e.preventDefault();
    if (newPass.length < 8) {
      alert('La nueva contraseña debe tener mínimo 8 caracteres.');
      return;
    }
    if (newPass !== confirmNewPass) {
      alert('La confirmación de la nueva contraseña no coincide.');
      return;
    }
    setPasswordSuccessMsg(true);
    setCurrentPass('');
    setNewPass('');
    setConfirmNewPass('');
    setTimeout(() => setPasswordSuccessMsg(false), 3000);
  };

  return (
    <div className="flex-1 flex flex-col min-w-0 h-full overflow-hidden bg-background">
      {/* CABECERA SUPERIOR */}
      <header className="h-16 bg-surface-container-lowest border-b border-surface-variant px-6 lg:px-8 flex items-center justify-between shrink-0 z-10">
        <div className="flex items-center gap-2 text-xs font-semibold text-on-surface-variant">
          <span className="text-tertiary">Administración</span>
          <span className="material-symbols-outlined text-xs">chevron_right</span>
          <span className="font-bold text-on-surface">Administradores y cuenta</span>
        </div>
        <div className="flex items-center gap-6">
          <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-surface-container text-on-surface-variant text-xs font-medium">
            <span className="material-symbols-outlined text-sm text-secondary">location_on</span>
            <span>Torreón El Roble, Ibagué</span>
          </div>
          <div className="hidden sm:flex items-center gap-1.5 text-on-surface-variant text-xs">
            <span className="material-symbols-outlined text-sm">calendar_today</span>
            <span>24 de octubre de 2024</span>
          </div>
        </div>
      </header>

      {/* CUERPO CON SCROLL */}
      <main className="flex-1 overflow-y-auto custom-scroll px-6 lg:px-8 py-6 space-y-6">
        {/* Título y Descripción */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl lg:text-3xl font-bold text-on-surface tracking-tight">Administradores y cuenta</h1>
            <p className="text-sm text-tertiary mt-1">
              Gestión del equipo administrativo del punto de venta y configuración de credenciales personales de acceso.
            </p>
          </div>
          <button
            onClick={() => setModalOpen(true)}
            className="flex items-center gap-2 bg-primary-container text-on-surface hover:bg-[#e5bd1b] active:scale-98 transition-all px-4 py-2.5 rounded-lg text-sm font-bold shadow-xs cursor-pointer self-start md:self-auto"
          >
            <span className="material-symbols-outlined text-[20px]">person_add</span>
            <span>Registrar administrador</span>
          </button>
        </div>

        {/* TABS DE NAVEGACIÓN */}
        <div className="border-b border-surface-variant flex items-center gap-8">
          <button
            onClick={() => setActiveTab('admins')}
            className={`pb-3 border-b-2 text-sm font-bold flex items-center gap-2 transition-colors cursor-pointer ${
              activeTab === 'admins'
                ? 'border-primary-container text-on-surface'
                : 'border-transparent text-tertiary hover:text-on-surface font-medium'
            }`}
          >
            <span className="material-symbols-outlined text-[18px]">group</span>
            <span>Administradores ({admins.length})</span>
          </button>
          <button
            onClick={() => setActiveTab('account')}
            className={`pb-3 border-b-2 text-sm font-bold flex items-center gap-2 transition-colors cursor-pointer ${
              activeTab === 'account'
                ? 'border-primary-container text-on-surface'
                : 'border-transparent text-tertiary hover:text-on-surface font-medium'
            }`}
          >
            <span className="material-symbols-outlined text-[18px]">badge</span>
            <span>Mi cuenta</span>
          </button>
        </div>

        {/* CONTENIDO TAB 1: ADMINISTRADORES */}
        {activeTab === 'admins' && (
          <div className="space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-surface-container-lowest p-4 rounded-xl border border-surface-variant">
              <div className="relative flex-1 max-w-md">
                <span className="material-symbols-outlined absolute left-3.5 top-1/2 -translate-y-1/2 text-tertiary text-[20px]">search</span>
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Buscar por nombre, usuario o correo..."
                  className="w-full h-11 pl-11 pr-4 bg-surface-container-low border border-surface-variant rounded-lg text-on-surface text-sm placeholder:text-tertiary focus:outline-none focus:border-primary-container focus:ring-1 focus:ring-primary-container transition-all"
                />
              </div>
              <div className="flex items-center gap-2 text-xs text-tertiary">
                <span className="material-symbols-outlined text-[18px] text-[#137333]">verified_user</span>
                <span>Acceso administrativo unificado de mostrador y bodega</span>
              </div>
            </div>

            {/* Tabla de Administradores */}
            <div className="bg-surface-container-lowest rounded-xl border border-surface-variant shadow-xs overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="bg-surface-container-low border-b border-surface-variant">
                      <th className="py-3.5 px-5 text-xs font-bold text-on-surface uppercase tracking-wider">Nombre completo</th>
                      <th className="py-3.5 px-4 text-xs font-bold text-on-surface uppercase tracking-wider">Usuario</th>
                      <th className="py-3.5 px-4 text-xs font-bold text-on-surface uppercase tracking-wider">Correo electrónico registrado</th>
                      <th className="py-3.5 px-4 text-xs font-bold text-on-surface uppercase tracking-wider">Rol</th>
                      <th className="py-3.5 px-4 text-xs font-bold text-on-surface uppercase tracking-wider">Estado</th>
                      <th className="py-3.5 px-5 text-xs font-bold text-on-surface uppercase tracking-wider text-right">Último acceso</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-surface-variant text-sm">
                    {filteredAdmins.map((admin) => (
                      <tr key={admin.id} className="hover:bg-surface-container-low/40 transition-colors">
                        <td className="py-4 px-5">
                          <div className="flex items-center gap-3">
                            <div className="w-9 h-9 rounded-full bg-primary-container text-on-surface font-bold text-xs flex items-center justify-center flex-shrink-0">
                              {admin.avatar}
                            </div>
                            <div className="flex flex-col">
                              <span className="font-bold text-on-surface text-sm">{admin.name}</span>
                              <span className="text-xs text-tertiary">{admin.role}</span>
                            </div>
                          </div>
                        </td>
                        <td className="py-4 px-4 font-semibold text-on-surface">
                          <span className="px-2.5 py-1 rounded bg-surface-container font-mono text-xs">
                            @{admin.username}
                          </span>
                        </td>
                        <td className="py-4 px-4 text-xs text-on-surface">{admin.email}</td>
                        <td className="py-4 px-4">
                          <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-surface-container-high text-on-surface text-xs font-semibold">
                            <span className="material-symbols-outlined text-[14px]">shield_person</span>
                            Administrador
                          </span>
                        </td>
                        <td className="py-4 px-4">
                          {admin.status === 'activo_online' ? (
                            <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-[#E6F4EA] text-[#137333] text-[11px] font-bold">
                              <span className="w-2 h-2 rounded-full bg-[#137333]"></span>
                              Activo (En línea)
                            </span>
                          ) : (
                            <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-[#E6F4EA] text-[#137333] text-[11px] font-bold">
                              <span className="w-2 h-2 rounded-full bg-[#137333]"></span>
                              Activo
                            </span>
                          )}
                        </td>
                        <td className="py-4 px-5 text-right">
                          {admin.lastAccess === 'Sesión actual' ? (
                            <span className="text-xs font-bold text-[#137333] bg-[#E6F4EA] px-2.5 py-1 rounded-md">
                              Sesión actual
                            </span>
                          ) : (
                            <span className="text-xs text-tertiary font-medium">{admin.lastAccess}</span>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* Aclaración al pie */}
              <div className="p-4 bg-surface-container-low/60 border-t border-surface-variant flex items-center gap-3 text-tertiary text-xs">
                <span className="material-symbols-outlined text-[20px] text-tertiary flex-shrink-0">verified</span>
                <span>
                  Por políticas de seguridad y trazabilidad operativa de Papelería Nico, no se permite eliminar cuentas administradoras ni visualizar contraseñas.
                </span>
              </div>
            </div>

            {/* SECCIÓN RESUMEN MI CUENTA EN TAB ADMINISTRADORES */}
            <div className="bg-surface-container-lowest rounded-xl border border-surface-variant p-6 flex flex-col md:flex-row items-center justify-between gap-6">
              <div className="flex items-center gap-4">
                <div className="w-14 h-14 rounded-full bg-primary-container text-on-surface text-xl font-bold flex items-center justify-center flex-shrink-0 border border-outline-variant/40">
                  CM
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-base font-bold text-on-surface">Carlos Mario Mendoza</h3>
                    <span className="px-2 py-0.5 bg-surface-container rounded font-mono text-xs font-semibold text-tertiary">
                      @carlosm
                    </span>
                  </div>
                  <p className="text-xs text-tertiary mt-0.5">
                    Sesión actual activa desde Ibagué, Tolima · carlos.mendoza@papelerianico.com
                  </p>
                </div>
              </div>
              <button
                onClick={() => setActiveTab('account')}
                className="flex items-center gap-2 px-4 py-2.5 rounded-lg border border-surface-variant bg-surface-container-lowest hover:bg-surface-container text-xs font-semibold text-on-surface transition-colors whitespace-nowrap cursor-pointer"
              >
                <span className="material-symbols-outlined text-[18px]">manage_accounts</span>
                <span>Configurar mis credenciales</span>
              </button>
            </div>
          </div>
        )}

        {/* CONTENIDO TAB 2: MI CUENTA */}
        {activeTab === 'account' && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Bloque: Datos del Perfil */}
              <div className="bg-surface-container-lowest p-6 rounded-xl border border-surface-variant shadow-xs space-y-5">
                <div className="flex items-center gap-3 pb-4 border-b border-surface-variant">
                  <span className="material-symbols-outlined text-primary text-[24px]">account_box</span>
                  <div>
                    <h2 className="text-base font-bold text-on-surface">Datos de perfil</h2>
                    <p className="text-xs text-tertiary">Información personal y de contacto en el sistema.</p>
                  </div>
                </div>

                {profileSuccessMsg && (
                  <div className="p-3 bg-emerald-50 text-emerald-800 border border-emerald-200 rounded-lg text-xs font-semibold flex items-center gap-2">
                    <span className="material-symbols-outlined text-base">check_circle</span>
                    <span>Datos de perfil actualizados exitosamente.</span>
                  </div>
                )}

                <form onSubmit={handleSaveProfile} className="space-y-4">
                  {/* Nombre de Usuario (Solo lectura) */}
                  <div>
                    <label className="block text-xs font-bold text-on-surface mb-1.5">Nombre de usuario</label>
                    <div className="relative flex items-center">
                      <span className="absolute left-3 font-mono text-tertiary">@</span>
                      <input
                        type="text"
                        readOnly
                        value="carlosm"
                        className="w-full h-11 pl-8 pr-28 bg-surface-container-low border border-surface-variant rounded-lg text-on-surface font-mono font-medium focus:outline-none cursor-not-allowed text-sm"
                      />
                      <span className="absolute right-3 px-2 py-0.5 rounded text-[11px] font-bold bg-surface-container-highest text-tertiary">
                        No modificable
                      </span>
                    </div>
                    <p className="text-xs text-tertiary mt-1">El identificador de usuario es permanente para trazabilidad de ventas.</p>
                  </div>

                  {/* Nombre Completo */}
                  <div>
                    <label className="block text-xs font-bold text-on-surface mb-1.5">Nombre completo</label>
                    <input
                      type="text"
                      required
                      value={fullName}
                      onChange={(e) => setFullName(e.target.value)}
                      className="w-full h-11 px-3.5 bg-surface-container-lowest border border-surface-variant rounded-lg text-on-surface text-sm focus:outline-none focus:border-primary-container focus:ring-1 focus:ring-primary-container"
                    />
                  </div>

                  {/* Correo de Recuperación */}
                  <div>
                    <label className="block text-xs font-bold text-on-surface mb-1.5">Correo electrónico de recuperación</label>
                    <input
                      type="email"
                      required
                      value={emailRecovery}
                      onChange={(e) => setEmailRecovery(e.target.value)}
                      className="w-full h-11 px-3.5 bg-surface-container-lowest border border-surface-variant rounded-lg text-on-surface text-sm focus:outline-none focus:border-primary-container focus:ring-1 focus:ring-primary-container"
                    />
                  </div>

                  {/* Confirmar con contraseña */}
                  <div className="p-3.5 bg-surface-container-low rounded-lg border border-surface-variant">
                    <label className="block text-xs font-bold text-on-surface mb-1">Confirmar con tu contraseña actual</label>
                    <input
                      type="password"
                      required
                      value={currentPassForProfile}
                      onChange={(e) => setCurrentPassForProfile(e.target.value)}
                      placeholder="Ingresa tu contraseña para confirmar cambios"
                      className="w-full h-10 px-3 bg-surface-container-lowest border border-surface-variant rounded-lg text-xs text-on-surface focus:outline-none focus:border-primary-container"
                    />
                    <p className="text-[11px] text-tertiary mt-1.5">Contraseña actual requerida para confirmar cambio de correo.</p>
                  </div>

                  <div className="pt-2">
                    <button
                      type="submit"
                      className="w-full sm:w-auto px-6 py-2.5 bg-primary-container text-on-surface text-xs font-bold rounded-lg hover:bg-[#e5bd1b] active:scale-98 transition-all shadow-xs cursor-pointer"
                    >
                      Guardar datos de perfil
                    </button>
                  </div>
                </form>
              </div>

              {/* Bloque: Cambiar Contraseña */}
              <div className="bg-surface-container-lowest p-6 rounded-xl border border-surface-variant shadow-xs space-y-5">
                <div className="flex items-center gap-3 pb-4 border-b border-surface-variant">
                  <span className="material-symbols-outlined text-primary text-[24px]">key</span>
                  <div>
                    <h2 className="text-base font-bold text-on-surface">Cambiar contraseña</h2>
                    <p className="text-xs text-tertiary">Actualiza periódicamente tu clave para salvaguardar las operaciones.</p>
                  </div>
                </div>

                {passwordSuccessMsg && (
                  <div className="p-3 bg-emerald-50 text-emerald-800 border border-emerald-200 rounded-lg text-xs font-semibold flex items-center gap-2">
                    <span className="material-symbols-outlined text-base">check_circle</span>
                    <span>Tu contraseña ha sido actualizada con éxito.</span>
                  </div>
                )}

                <form onSubmit={handleUpdatePassword} className="space-y-4">
                  {/* Contraseña Actual */}
                  <div>
                    <label className="block text-xs font-bold text-on-surface mb-1.5">Contraseña actual</label>
                    <div className="relative">
                      <input
                        type={showCurrentPass ? 'text' : 'password'}
                        required
                        value={currentPass}
                        onChange={(e) => setCurrentPass(e.target.value)}
                        placeholder="••••••••"
                        className="w-full h-11 pl-3.5 pr-10 bg-surface-container-lowest border border-surface-variant rounded-lg text-on-surface text-sm focus:outline-none focus:border-primary-container focus:ring-1 focus:ring-primary-container"
                      />
                      <button
                        type="button"
                        onClick={() => setShowCurrentPass(!showCurrentPass)}
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-tertiary hover:text-on-surface"
                      >
                        <span className="material-symbols-outlined text-[20px]">
                          {showCurrentPass ? 'visibility_off' : 'visibility'}
                        </span>
                      </button>
                    </div>
                  </div>

                  {/* Nueva Contraseña */}
                  <div>
                    <label className="block text-xs font-bold text-on-surface mb-1.5">Nueva contraseña</label>
                    <div className="relative">
                      <input
                        type={showNewPass ? 'text' : 'password'}
                        required
                        minLength={8}
                        value={newPass}
                        onChange={(e) => setNewPass(e.target.value)}
                        placeholder="••••••••"
                        className="w-full h-11 pl-3.5 pr-10 bg-surface-container-lowest border border-surface-variant rounded-lg text-on-surface text-sm focus:outline-none focus:border-primary-container focus:ring-1 focus:ring-primary-container"
                      />
                      <button
                        type="button"
                        onClick={() => setShowNewPass(!showNewPass)}
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-tertiary hover:text-on-surface"
                      >
                        <span className="material-symbols-outlined text-[20px]">
                          {showNewPass ? 'visibility_off' : 'visibility'}
                        </span>
                      </button>
                    </div>
                  </div>

                  {/* Confirmar Nueva Contraseña */}
                  <div>
                    <label className="block text-xs font-bold text-on-surface mb-1.5">Confirmar nueva contraseña</label>
                    <div className="relative">
                      <input
                        type={showConfirmNewPass ? 'text' : 'password'}
                        required
                        minLength={8}
                        value={confirmNewPass}
                        onChange={(e) => setConfirmNewPass(e.target.value)}
                        placeholder="••••••••"
                        className="w-full h-11 pl-3.5 pr-10 bg-surface-container-lowest border border-surface-variant rounded-lg text-on-surface text-sm focus:outline-none focus:border-primary-container focus:ring-1 focus:ring-primary-container"
                      />
                      <button
                        type="button"
                        onClick={() => setShowConfirmNewPass(!showConfirmNewPass)}
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-tertiary hover:text-on-surface"
                      >
                        <span className="material-symbols-outlined text-[20px]">
                          {showConfirmNewPass ? 'visibility_off' : 'visibility'}
                        </span>
                      </button>
                    </div>
                  </div>

                  {/* Requisitos */}
                  <div className="p-3 bg-surface-container-low rounded-lg space-y-1 text-xs text-tertiary">
                    <div className="flex items-center gap-2">
                      <span className="material-symbols-outlined text-[15px] text-[#137333]">check_circle</span>
                      <span>Mínimo 8 caracteres</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="material-symbols-outlined text-[15px] text-[#137333]">check_circle</span>
                      <span>Al menos una letra mayúscula y un número</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="material-symbols-outlined text-[15px] text-[#137333]">check_circle</span>
                      <span>No coincidente con el nombre de usuario</span>
                    </div>
                  </div>

                  <div className="pt-2">
                    <button
                      type="submit"
                      className="w-full sm:w-auto px-6 py-2.5 bg-on-surface text-white text-xs font-bold rounded-lg hover:bg-black active:scale-98 transition-all shadow-xs cursor-pointer"
                    >
                      Actualizar contraseña
                    </button>
                  </div>
                </form>
              </div>
            </div>
          </div>
        )}
      </main>

      {/* MODAL: REGISTRAR NUEVO ADMINISTRADOR */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-inverse-surface/40 backdrop-blur-xs">
          <div className="bg-surface-container-lowest w-full max-w-xl rounded-2xl shadow-2xl border border-surface-variant overflow-hidden">
            <div className="p-6 border-b border-surface-variant flex items-center justify-between bg-surface-container-lowest">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-primary-container/30 flex items-center justify-center text-primary">
                  <span className="material-symbols-outlined text-[24px]">admin_panel_settings</span>
                </div>
                <div>
                  <h2 className="text-base font-bold text-on-surface">Registrar nuevo administrador</h2>
                  <p className="text-xs text-tertiary">Crea credenciales oficiales para un colaborador del local.</p>
                </div>
              </div>
              <button
                onClick={() => setModalOpen(false)}
                className="w-9 h-9 rounded-lg flex items-center justify-center text-tertiary hover:text-on-surface hover:bg-surface-container transition-colors"
              >
                <span className="material-symbols-outlined text-[22px]">close</span>
              </button>
            </div>

            <form onSubmit={handleRegisterAdmin} className="p-6 space-y-4 max-h-[75vh] overflow-y-auto custom-scroll">
              <div className="p-3.5 bg-surface-container-low rounded-xl border border-surface-variant flex items-start gap-3">
                <span className="material-symbols-outlined text-primary text-[20px] mt-0.5">info</span>
                <p className="text-xs text-on-surface">
                  El nuevo usuario tendrá rol de <strong>Administrador</strong> para operar mostrador e inventario. No existen niveles restringidos.
                </p>
              </div>

              <div>
                <label className="block text-xs font-bold text-on-surface mb-1">Nombre completo *</label>
                <input
                  type="text"
                  required
                  value={newName}
                  onChange={(e) => setNewName(e.target.value)}
                  placeholder="ej: Julián David Morales"
                  className="w-full h-11 px-3.5 bg-surface-container-lowest border border-surface-variant rounded-lg text-on-surface text-sm placeholder:text-tertiary/70 focus:outline-none focus:border-primary-container focus:ring-1 focus:ring-primary-container"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-on-surface mb-1">Nombre de usuario *</label>
                <div className="relative flex items-center">
                  <span className="absolute left-3.5 font-mono text-tertiary font-bold">@</span>
                  <input
                    type="text"
                    required
                    value={newUsername}
                    onChange={(e) => setNewUsername(e.target.value)}
                    placeholder="julian_m"
                    className="w-full h-11 pl-9 pr-3.5 bg-surface-container-lowest border border-surface-variant rounded-lg text-on-surface font-mono text-sm placeholder:text-tertiary/70 focus:outline-none focus:border-primary-container focus:ring-1 focus:ring-primary-container"
                  />
                </div>
                <p className="text-[11px] text-tertiary mt-1">Solo letras minúsculas, números y guion bajo.</p>
              </div>

              <div>
                <label className="block text-xs font-bold text-on-surface mb-1">Correo electrónico *</label>
                <input
                  type="email"
                  required
                  value={newEmail}
                  onChange={(e) => setNewEmail(e.target.value)}
                  placeholder="ej: julian.morales@papelerianico.com"
                  className="w-full h-11 px-3.5 bg-surface-container-lowest border border-surface-variant rounded-lg text-on-surface text-sm placeholder:text-tertiary/70 focus:outline-none focus:border-primary-container focus:ring-1 focus:ring-primary-container"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-on-surface mb-1">Contraseña *</label>
                  <div className="relative">
                    <input
                      type={showPass1 ? 'text' : 'password'}
                      required
                      minLength={8}
                      value={newPassword}
                      onChange={(e) => setNewPassword(e.target.value)}
                      placeholder="Ingresa contraseña"
                      className="w-full h-11 pl-3.5 pr-10 bg-surface-container-lowest border border-surface-variant rounded-lg text-on-surface text-sm placeholder:text-tertiary/70 focus:outline-none focus:border-primary-container focus:ring-1 focus:ring-primary-container"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPass1(!showPass1)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-tertiary hover:text-on-surface"
                    >
                      <span className="material-symbols-outlined text-[20px]">
                        {showPass1 ? 'visibility_off' : 'visibility'}
                      </span>
                    </button>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-on-surface mb-1">Confirmar contraseña *</label>
                  <div className="relative">
                    <input
                      type={showPass2 ? 'text' : 'password'}
                      required
                      minLength={8}
                      value={confirmPassword}
                      onChange={(e) => setConfirmPassword(e.target.value)}
                      placeholder="Repite contraseña"
                      className="w-full h-11 pl-3.5 pr-10 bg-surface-container-lowest border border-surface-variant rounded-lg text-on-surface text-sm placeholder:text-tertiary/70 focus:outline-none focus:border-primary-container focus:ring-1 focus:ring-primary-container"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPass2(!showPass2)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-tertiary hover:text-on-surface"
                    >
                      <span className="material-symbols-outlined text-[20px]">
                        {showPass2 ? 'visibility_off' : 'visibility'}
                      </span>
                    </button>
                  </div>
                </div>
              </div>

              <div className="p-3 bg-surface-container-low rounded-lg space-y-1 border border-surface-variant text-xs text-tertiary">
                <div className="flex items-center gap-2">
                  <span className="material-symbols-outlined text-[15px] text-[#137333]">check_circle</span>
                  <span>Mínimo 8 caracteres</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="material-symbols-outlined text-[15px] text-[#137333]">check_circle</span>
                  <span>Al menos una letra mayúscula y un número</span>
                </div>
              </div>

              <div className="p-4 border-t border-surface-variant flex items-center justify-end gap-3 pt-4">
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  className="px-5 py-2.5 rounded-lg border border-surface-variant bg-surface-container-lowest hover:bg-surface-container text-xs font-semibold text-on-surface"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 rounded-lg bg-primary-container hover:bg-[#e5bd1b] active:scale-98 text-on-surface text-xs font-bold shadow-xs transition-all flex items-center gap-2 cursor-pointer"
                >
                  <span className="material-symbols-outlined text-[20px]">check</span>
                  <span>Crear administrador</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
