export interface Product {
  code: string;
  name: string;
  category: string;
  price: number;
  stock: number;
  minStock: number;
  description: string;
  image: string;
  isKit?: boolean;
  kitItemsRaw?: string;
}

export interface KitComponent {
  productCode: string;
  name: string;
  quantity: number;
  unitPrice: number;
}

export interface Kit {
  id: string;
  name: string;
  description: string;
  targetAge: string;
  image: string;
  status: 'publicado' | 'oculto';
  components: KitComponent[];
}

export interface InventoryMovement {
  id: string;
  dateTime: string;
  productCode: string;
  productName: string;
  type: 'entrada' | 'salida_kit' | 'salida_venta' | 'ajuste_merma' | 'conteo';
  typeLabel: string;
  quantity: number; // positive or negative
  reference: string;
  responsible: string;
}

export interface SaleItem {
  code: string;
  name: string;
  quantity: number;
  unitPrice: number;
  subtotal: number;
  isKit?: boolean;
  components?: { name: string; quantity: number }[];
}

export interface Sale {
  id: string;
  date: string;
  time: string;
  channel: string;
  items: SaleItem[];
  subtotal: number;
  total: number;
  responsible: string;
  location: string;
}

export interface AdminUser {
  id: string;
  name: string;
  username: string;
  email: string;
  role: string;
  status: 'activo_online' | 'activo';
  lastAccess: string;
  avatar: string;
}

export interface Category {
  name: string;
  description: string;
  productCount: number;
  icon: string;
}

export const INITIAL_CATEGORIES: Category[] = [
  {
    name: 'Cuadernos',
    description: 'Cuadernos cosidos y argollados, cuadriculados, rayados y libretas de notas escolares.',
    productCount: 1,
    icon: 'menu_book'
  },
  {
    name: 'Lápices y Bolígrafos',
    description: 'Bolígrafos, lápices de grafito, portaminas, resaltadores y marcadores permanentes.',
    productCount: 3,
    icon: 'edit'
  },
  {
    name: 'Colores y Arte',
    description: 'Cajas de colores, cartulinas de colores, papel silueta, vinilos y materiales artísticos.',
    productCount: 2,
    icon: 'palette'
  },
  {
    name: 'Borradores',
    description: 'Borradores de nata, miga de pan, borradores para tinta y correctores líquidos.',
    productCount: 1,
    icon: 'cleaning_services'
  },
  {
    name: 'Adhesivos y pegantes',
    description: 'Pegantes líquidos, barras de pegante lavable, silicona líquida y cintas adhesivas.',
    productCount: 3,
    icon: 'format_paint'
  },
  {
    name: 'Escolar',
    description: 'Tijeras escolares punta roma, reglas metálicas graduadas, compases y accesorios.',
    productCount: 2,
    icon: 'school'
  }
];

export const INITIAL_PRODUCTS: Product[] = [
  {
    code: 'CUA-100-CD',
    name: 'Cuaderno Cuadriculado 100 Hojas Norma Kiut',
    category: 'Cuadernos',
    price: 8500,
    stock: 48,
    minStock: 15,
    description: 'Cuaderno cosido de 100 hojas de cuadrícula estándar con pasta dura plastificada de alta resistencia y hojas blancas de 60g.',
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBbYQIlJIGi0a4bvq9sLUHLK0AUU0gMs4LQWqvTbNzDraRemd0_VE6t8BX4W4SiPqgSyJCgYKPbpxlJfE1IsJ4NIAsu3B_UbmKU3D9JTMTf67nI1beewaCtlUZ4Hg9G1VeEcgg13yEvvMMHR1gEfbvyNz7gl0rBFWJVweASz1tNkM996O6YzciX7u9juX7ztYgresUCD3XPYfyCCxf9gJwTTTN1IGPSRJKS4qj0Q097sKuEbWl9Dd3kZg'
  },
  {
    code: 'PLI-CART-BL',
    name: 'Pliego Cartulina Kimberly Blanco',
    category: 'Colores y Arte',
    price: 2200,
    stock: 112,
    minStock: 30,
    description: 'Pliego de cartulina premium de 180 gramos color blanco nieve, ideal para carteleras, maquetas y trabajos artísticos escolares.',
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuD4k2eDWFIkGDEYAx4nXmdnaiubvjmY6P3ldAJY8izRQ4OrCMnKW4NWJMUsRBem_EINrIpgmOcOMyA4LFyOgxxwCdzJOgPdzxgBqbG1tBYRyy3rsNPc4J3klDySGBMPVSoj_jo0vbnWw2GLljHkutkPC_CWeq7oTe9aW_XrbJgQwP9wHncquNMRoiW_4ObvBUbjYAf7oBVElxG8ivYr8TiZJyr9KfGOW-iYDGlm74cK8yHBqrTkj0dGfA'
  },
  {
    code: 'COL-PEQ-PGA',
    name: 'Pegante Líquido Colbón 115g',
    category: 'Adhesivos y pegantes',
    price: 3200,
    stock: 5,
    minStock: 10,
    description: 'Frasco de pegante blanco multiuso escolar, fórmula segura para niños, fácil dosificación para papel y cartón.',
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuDs_kKsYmdpzX1aCQL8IWpR_an0LOtWXLk4BUjnPpB5gX3O91E6kVAuyrOsyd-E0_tZXqVgcFVbVt257U3_T7V0ETwe_NBa0GxBXUsHwboX04LvyRXGO38bfJ6qGack1qZe9ozaUd7TzLCZkCYjMgrc14P59tUmKp9zZ8ZieJLYFs-X-Sik2nqbIVT0TdjAB9dpGgqtgKd-C-H3o11EOjM-L4cY2Qg1XfdK6gEva_E78drbYjnsk2ax1w'
  },
  {
    code: 'MAR-PERM-NG',
    name: 'Marcador Permanente Sharpie Punta Fina',
    category: 'Lápices y Bolígrafos',
    price: 4500,
    stock: 0,
    minStock: 12,
    description: 'Marcador de secado rápido que escribe sobre la mayoría de superficies como plástico, madera, metal y cartón grueso.',
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuC2vxQZkmdIfjQdu7p8NDCVWdgSC04m-fgUrynNNdFXIvfU1rKSrdoKIrJ8G-xW6MmtPvoCBlw3x01atwOZr3Lvp0o9u0WtRKrkNHd_OHesIxv-kslfypJlZd2aSzkH784JZoTRx4z_xMHP5Hg_XHtoLuctCG4lfxgaeufy3OGsLxBygGGNa9q4_E6VShCYZFGSrkbzkmcyn3ialC4UIvuC8ceL979H1zHQ_ULVq9e-sOVcH-fctodPvw'
  },
  {
    code: 'COL-MAD-12C',
    name: 'Caja Colores Doble Punta x 12 (24 Colores)',
    category: 'Colores y Arte',
    price: 18900,
    stock: 24,
    minStock: 8,
    description: 'Set de lápices de color madera con fórmula cremosa, doble tonalidad por lápiz, óptimos para dibujo artístico escolar y universitario.',
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuC8yGv9antuvVW_bO5dG3dLFTeOSyvqd-nFsS3AwcbBzPvlGXfowrjYW5I5FzFEqr3unMfsq-qB2Fg1Zh9dP66aCa6MBWw_n0DyF-MAB5k2WEzBITglE061FBuYnL51DPVH-oyQPMOiYvSnoZDhG7LTyIWFEck8-vC6X-lbHRathfNXVaZvev-FXCNJ7WgHT5TS9n2igJciCtKiQQ_45S-6QfLPuRFyWb88ViA5rJReMPx-_cTRQVINGQ'
  },
  {
    code: 'TIJ-ESC-PTA',
    name: 'Tijera Escolar Punta Roma Maped 13cm',
    category: 'Escolar',
    price: 3000,
    stock: 0,
    minStock: 10,
    description: 'Tijeras de agarre suave especialmente concebidas para niños pequeños de preescolar y primaria, seguras con hojas redondeadas.',
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuCAvh3k56AIGZhyHiEVp6beOC2DdIgI4TuWo7Mod51Oh5KAssl2suXKDqZwQNPCutAlC05QBaYyLRKmJeT_WD6nW00ukvshjIkmc_DvE4sR4VhxuXtn6Ewj3S00nVXY415d9XyqU6_hRlvXHVNDf9lbH8S64imKaaLGHVpqm9kAIEMnbuXFWKI3aL_iBkeRB-WYsD6Kfp_zcMi-4VeF5lEsdwaMuCHpdks8AgAuDxky5o6kgcWPGJmqiw'
  },
  {
    code: 'RES-PAS-4X',
    name: 'Resaltadores Pastel Pelikan x4',
    category: 'Lápices y Bolígrafos',
    price: 12000,
    stock: 18,
    minStock: 6,
    description: 'Set de 4 resaltadores en tonos pastel suaves: menta, lavanda, rosa y durazno. Tinta base agua que no traspasa hojas.',
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuB749SOsFtPrZrzh9ZWeE8RbWRNIhkmrIte1U_8fS5fmGitkmbiy4tyuvbyMn2ady_62fH-4K3sVbWFqugsi8PyFIDMzPr09zdvzaO6sB6AyKyCwnbMqGmMg5H0n9WtU5ucgQdGnHhg88StlbAjbZYq596F8nGhl9TQ-BYBWhhSbkg1wB4S2u-EC8tLsX-kERMqD8URhQfJOnFaE4WFUUHsb9Ko7oj54X05MqNz6xf56Nxt69oNUbJDmw'
  },
  {
    code: 'REG-MET-30',
    name: 'Regla Metálica 30cm Faber-Castell',
    category: 'Escolar',
    price: 2400,
    stock: 3,
    minStock: 8,
    description: 'Regla graduada en acero inoxidable con escala milimétrica grabada al ácido. Alta durabilidad y filo recto antideslizante.',
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuB6PNO_vOECKZTNKsE8t3nsOIVbSCFgHRzc_dhdS4zw8hLJsJr86ULUer3SUw7feRI_fMS3K94yMsZcpIVEEzdMnj4Byc4AgpyosZvI03TL5z9hjKTIEcC8XqGkhzGNSrevT_Gz-mhl8NE_ExMnh3tUQPohjjOiUnsdpEgtHTD3XDQjQ-mUOHObKqssBP4H207FA31q5_RHlYnxhOGVDlrVAzCum_VW4SyVmoQitFesLxM18UYNSIcFJQ'
  },
  {
    code: 'BOL-KIL-AZ',
    name: 'Bolígrafo Kilométrico Azul 1.0mm',
    category: 'Lápices y Bolígrafos',
    price: 1800,
    stock: 86,
    minStock: 20,
    description: 'Bolígrafo Paper Mate Kilométrico retráctil punta media 1.0mm, tinta fluida azul para escritura suave continua.',
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuB6PNO_vOECKZTNKsE8t3nsOIVbSCFgHRzc_dhdS4zw8hLJsJr86ULUer3SUw7feRI_fMS3K94yMsZcpIVEEzdMnj4Byc4AgpyosZvI03TL5z9hjKTIEcC8XqGkhzGNSrevT_Gz-mhl8NE_ExMnh3tUQPohjjOiUnsdpEgtHTD3XDQjQ-mUOHObKqssBP4H207FA31q5_RHlYnxhOGVDlrVAzCum_VW4SyVmoQitFesLxM18UYNSIcFJQ'
  },
  {
    code: 'BOR-NAT-BL',
    name: 'Borrador de Nata Suave Blanco',
    category: 'Borradores',
    price: 1200,
    stock: 50,
    minStock: 15,
    description: 'Borrador blanco de miga de pan / nata no abrasivo. Elimina trazos de grafito con suavidad sin manchar ni dañar el papel escolar.',
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuAJ9eOZ0S_ApojsrjQzcI0RaggPt_i5Oe6tBZskOk2OhLyf4yWXzE2e_aUHJyF9Y2V3wnnVzwYFe8smO6Bf5DlSAqup8Jnztx5btxBd0gVeiUJMd9IQ6akshnev0I5ay5DdR-bZQwLngZWaNmFi9c2Hmim7Q582V2JkwSXEYp9P7q7_VTvXgrwUQaWA5jFvo44idD7_eitrD1wyhqFw27mc6rqFgJPkEVvEoiRmbKbj0xPxSL2dinFdqQ'
  },
  {
    code: 'CIN-TRA-48',
    name: 'Cinta Transparente Gruesa 48mm',
    category: 'Adhesivos y pegantes',
    price: 4200,
    stock: 2,
    minStock: 10,
    description: 'Cinta adhesiva transparente de alta adherencia y 48mm de ancho. Perfecta para embalaje, sellado de cajas y forrado de libros.',
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBuT4G2_VzaQSlc2itGAPtm7r1kxPK7B0TUFLM_rZfa4Js2yrunCskKauqWPSTVYw_LQPHrDa89XUpZU66MxyM4wTra8BXCMCrAeu7LJGOHUg4AwklrcWjoL9tHSlwW9eh12c6FOj8XHlJThrj86GheV5m9iGLhpfbYrK672YikLlppLnDWr2bbD0_SeJabG5OJSQJL4xJALY3DPl2hW_c-SSlrTJH1Uia69MJREbd2deaLHqZQ8tgRsQ'
  },
  {
    code: 'PEG-BAR-40',
    name: 'Pegante en Barra Lavable 40g',
    category: 'Adhesivos y pegantes',
    price: 4200,
    stock: 0,
    minStock: 12,
    description: 'Barra de pegamento adhesivo sólido sin disolventes de 40g. Aplicación limpia, lavable y totalmente segura para uso escolar.',
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuAZuydE4TEgdo0GTdG1BduEm9tLSMCau77K2f7jLnvUlAxyr6VoFVz9ByLxMxfH3eXKIpbqKebL6jcxGYfZluV1icTXsssvYh-YS-KeIYLetk5dHF9WJiR6rZIP8l_PGUdqa5U7ttKfhCCKJ4BRf3-GucYwGh2GjBYVQAheZ9tZYkxKABt29oytPeODB0fa2sjlYR5x_p6JrRyUsjDlp2tTARtyH7VsrLmKyUY_eLAvRk0aMZhEJFvDmw'
  }
];

export const INITIAL_KITS: Kit[] = [
  {
    id: 'KIT-ESC-PRI',
    name: 'Kit Regreso a Primaria',
    description: 'Paquete escolar completo con los útiles esenciales solicitados para grados de básica primaria, seleccionados por su durabilidad y calidad.',
    targetAge: '6 a 10 años / Grados 1° a 5°',
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuAC99Wh6tPRAau69CyQlvV9QDUe7IxMxGVwTBreJFnf1bcEKO-r38WimN2qqBjgRQAd5wXFTc7Qq_9BXBmQ4hre5mt9ufzugrdmr1L9WPtieRiQ0P4Upsqe1RjFhL9r2_x0fTmtozsrVABCPT6-HuQIf4Mn58EiPKJKxeyCFItyu9Xwvqq8vX2DgsxRKiDvHR9WzX4aWeD2W7XFD3sRle5NHkQfd1zlPphjV7k4ivOJh-HNul1y1Cqcew',
    status: 'publicado',
    components: [
      { productCode: 'CUA-100-CD', name: 'Cuaderno Cuadriculado 100h Norma', quantity: 2, unitPrice: 8500 },
      { productCode: 'COL-MAD-12C', name: 'Caja Colores Doble Punta x12', quantity: 1, unitPrice: 18900 },
      { productCode: 'COL-PEQ-PGA', name: 'Pegante Líquido Colbón 115g', quantity: 1, unitPrice: 3200 },
      { productCode: 'REG-MET-30', name: 'Regla Metálica 30cm', quantity: 1, unitPrice: 2400 },
      { productCode: 'TIJ-ESC-PTA', name: 'Tijera Escolar Punta Roma', quantity: 1, unitPrice: 3000 }
    ]
  },
  {
    id: 'KIT-ESC-SEC',
    name: 'Kit Regreso a Secundaria',
    description: 'Set integral para estudiantes de bachillerato y grados avanzados. Todo lo requerido para ciencias exactas y humanidades.',
    targetAge: '11 a 16 años / Bachillerato',
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuB749SOsFtPrZrzh9ZWeE8RbWRNIhkmrIte1U_8fS5fmGitkmbiy4tyuvbyMn2ady_62fH-4K3sVbWFqugsi8PyFIDMzPr09zdvzaO6sB6AyKyCwnbMqGmMg5H0n9WtU5ucgQdGnHhg88StlbAjbZYq596F8nGhl9TQ-BYBWhhSbkg1wB4S2u-EC8tLsX-kERMqD8URhQfJOnFaE4WFUUHsb9Ko7oj54X05MqNz6xf56Nxt69oNUbJDmw',
    status: 'publicado',
    components: [
      { productCode: 'CUA-100-CD', name: 'Cuaderno Cuadriculado 100h Norma', quantity: 3, unitPrice: 8500 },
      { productCode: 'BOL-KIL-AZ', name: 'Bolígrafo Kilométrico Azul 1.0mm', quantity: 2, unitPrice: 1800 },
      { productCode: 'RES-PAS-4X', name: 'Resaltadores Pastel Pelikan x4', quantity: 1, unitPrice: 12000 },
      { productCode: 'REG-MET-30', name: 'Regla Metálica 30cm', quantity: 1, unitPrice: 2400 }
    ]
  },
  {
    id: 'KIT-ART-CRE',
    name: 'Kit de Arte y Creatividad',
    description: 'Pack artístico completo para clases de dibujo, técnicas plásticas y proyectos creativos, con pigmentos vivos y papeles especializados.',
    targetAge: 'Manualidades & expresión artística',
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuD0hCvuR9uRiHptT_6n3ieHRAEg0lpYQxluZ7oCrZcGigC2l4kSwhfvOSYCoYrjpKLH0m9F22KHkxYQlCqyjNKWEKiX9YRrKXCJVW5pOYjenaeb1DR-c5h7XW2vT0-GOPLHL6_pN5hD434k8bIy3HdpzNq3Livbt3UX8C3MsgKwKIxyGThiuX3_GbkxdmczoIWq5bxcBWlPiYa4AnrAfsSSqffXPA-yU13NFtL864XMqpHr4FP6H0VE3g',
    status: 'publicado',
    components: [
      { productCode: 'COL-MAD-12C', name: 'Caja Colores Doble Punta x12', quantity: 1, unitPrice: 18900 },
      { productCode: 'PLI-CART-BL', name: 'Pliego Cartulina Kimberly Blanco', quantity: 2, unitPrice: 2200 },
      { productCode: 'COL-PEQ-PGA', name: 'Pegante Líquido Colbón 115g', quantity: 1, unitPrice: 3200 },
      { productCode: 'TIJ-ESC-PTA', name: 'Tijera Escolar Punta Roma', quantity: 1, unitPrice: 3000 }
    ]
  },
  {
    id: 'KIT-PRI-TRA',
    name: 'Kit Primeros Trazos',
    description: 'Kit didáctico ideal para preescolar y primeros trazos. Estimula la motricidad fina y la creatividad con materiales de agarre ergonómico.',
    targetAge: 'Etapa inicial: 3 a 5 años',
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuAC99Wh6tPRAau69CyQlvV9QDUe7IxMxGVwTBreJFnf1bcEKO-r38WimN2qqBjgRQAd5wXFTc7Qq_9BXBmQ4hre5mt9ufzugrdmr1L9WPtieRiQ0P4Upsqe1RjFhL9r2_x0fTmtozsrVABCPT6-HuQIf4Mn58EiPKJKxeyCFItyu9Xwvqq8vX2DgsxRKiDvHR9WzX4aWeD2W7XFD3sRle5NHkQfd1zlPphjV7k4ivOJh-HNul1y1Cqcew',
    status: 'oculto',
    components: [
      { productCode: 'CUA-100-CD', name: 'Cuaderno Cuadriculado 100h Norma', quantity: 2, unitPrice: 8500 },
      { productCode: 'BOR-NAT-BL', name: 'Borrador de Nata Suave Blanco', quantity: 1, unitPrice: 1200 },
      { productCode: 'COL-PEQ-PGA', name: 'Pegante Líquido Colbón 115g', quantity: 1, unitPrice: 3200 }
    ]
  }
];

export const INITIAL_MOVEMENTS: InventoryMovement[] = [
  {
    id: 'MOV-1029',
    dateTime: '24 Oct, 10:14 AM',
    productCode: 'COL-PEQ-PGA',
    productName: 'Pegante Líquido Colbón 115g',
    type: 'entrada',
    typeLabel: 'Entrada por compra',
    quantity: 20,
    reference: 'Factura Prov. Distribuidora Tolima #45892',
    responsible: 'Carlos M.'
  },
  {
    id: 'MOV-1028',
    dateTime: '24 Oct, 09:45 AM',
    productCode: 'CUA-100-CD',
    productName: 'Cuaderno Cuadriculado 100h',
    type: 'salida_kit',
    typeLabel: 'Salida Kit Escolar',
    quantity: -1,
    reference: 'Kit Escolar Primaria #K-01 • Descuento vinculado a Venta #V-1048',
    responsible: 'Carlos M.'
  },
  {
    id: 'MOV-1027',
    dateTime: '24 Oct, 09:45 AM',
    productCode: 'TIJ-ESC-PTA',
    productName: 'Tijera Escolar Punta Roma',
    type: 'salida_kit',
    typeLabel: 'Salida Kit Escolar',
    quantity: -1,
    reference: 'Kit Escolar Primaria #K-01 • Descuento atómico de componentes',
    responsible: 'Carlos M.'
  },
  {
    id: 'MOV-1026',
    dateTime: '24 Oct, 09:12 AM',
    productCode: 'BOL-KIL-AZ',
    productName: 'Bolígrafo Kilométrico Azul',
    type: 'salida_venta',
    typeLabel: 'Salida por venta',
    quantity: -3,
    reference: 'Venta mostrador ticket #V-1047',
    responsible: 'Carlos M.'
  },
  {
    id: 'MOV-1025',
    dateTime: '24 Oct, 08:30 AM',
    productCode: 'PLI-CART-BL',
    productName: 'Pliego Cartulina Blanca',
    type: 'ajuste_merma',
    typeLabel: 'Ajuste por merma',
    quantity: -2,
    reference: 'Deterioro por humedad en transporte local',
    responsible: 'Carlos M.'
  }
];

export function getBogotaToday() {
  const now = new Date();
  const dateParts = new Intl.DateTimeFormat('es-CO', {
    timeZone: 'America/Bogota',
    day: '2-digit',
    month: '2-digit',
    year: 'numeric'
  }).formatToParts(now);

  const day = dateParts.find((p) => p.type === 'day')?.value || '01';
  const month = dateParts.find((p) => p.type === 'month')?.value || '10';
  const year = dateParts.find((p) => p.type === 'year')?.value || '2026';
  const dateString = `${day}/${month}/${year}`;

  const formattedLong = new Intl.DateTimeFormat('es-CO', {
    timeZone: 'America/Bogota',
    day: 'numeric',
    month: 'long',
    year: 'numeric'
  }).format(now);

  const timeString = new Intl.DateTimeFormat('es-CO', {
    timeZone: 'America/Bogota',
    hour: '2-digit',
    minute: '2-digit',
    hour12: true
  }).format(now);

  return {
    dateString,
    formattedLong,
    timeString,
    day,
    month,
    year
  };
}

export function getBogotaYesterdayDateString(): string {
  const now = new Date();
  now.setDate(now.getDate() - 1);
  const dateParts = new Intl.DateTimeFormat('es-CO', {
    timeZone: 'America/Bogota',
    day: '2-digit',
    month: '2-digit',
    year: 'numeric'
  }).formatToParts(now);

  const day = dateParts.find((p) => p.type === 'day')?.value || '01';
  const month = dateParts.find((p) => p.type === 'month')?.value || '10';
  const year = dateParts.find((p) => p.type === 'year')?.value || '2026';
  return `${day}/${month}/${year}`;
}

export function normalizeCategory(cat: string): string {
  if (!cat) return '';
  const c = cat
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .trim();
  if (c.includes('pegante') || c.includes('adhesivo')) return 'adhesivos-pegantes';
  if (c.includes('cuaderno')) return 'cuadernos';
  if (c.includes('lapiz') || c.includes('boligrafo') || c.includes('escritura') || c.includes('pluma') || c.includes('resaltador')) return 'lapices-boligrafos';
  if (c.includes('color') || c.includes('arte') || c.includes('papel') || c.includes('cartulina') || c.includes('manualidad')) return 'colores-arte';
  if (c.includes('borrador')) return 'borradores';
  if (c.includes('escolar') || c.includes('tijera') || c.includes('regla') || c.includes('compas')) return 'escolar';
  return c;
}

export function matchesCategoryFilter(productCategory: string, filterCategory: string): boolean {
  if (!filterCategory || filterCategory === 'all' || filterCategory === 'Todas' || filterCategory === 'todas') return true;
  if (!productCategory) return false;
  if (productCategory.trim().toLowerCase() === filterCategory.trim().toLowerCase()) return true;
  const pNorm = normalizeCategory(productCategory);
  const fNorm = normalizeCategory(filterCategory);
  return pNorm === fNorm;
}

export function getKitCurrentPrice(kit: Kit, products: Product[]): number {
  if (!kit.components || kit.components.length === 0) return 0;
  return kit.components.reduce((sum, comp) => {
    const prod = products.find((p) => p.code === comp.productCode);
    const unitPrice = prod ? prod.price : (comp.unitPrice || 0);
    return sum + unitPrice * comp.quantity;
  }, 0);
}

export function getKitAvailableUnits(kit: Kit, products: Product[]): number {
  if (!kit.components || kit.components.length === 0) return 0;
  let minUnits = Infinity;
  for (const comp of kit.components) {
    if (comp.quantity <= 0) continue;
    const prod = products.find((p) => p.code === comp.productCode);
    const stock = prod ? prod.stock : 0;
    const units = Math.floor(stock / comp.quantity);
    if (units < minUnits) {
      minUnits = units;
    }
  }
  return minUnits === Infinity ? 0 : Math.max(0, minUnits);
}

export function calculateRequiredProductQuantities(
  cartItems: SaleItem[],
  kits: Kit[]
): Map<string, { productCode: string; name: string; requiredQty: number }> {
  const map = new Map<string, { productCode: string; name: string; requiredQty: number }>();

  for (const item of cartItems) {
    const qty = Math.floor(item.quantity);
    if (qty <= 0) continue;

    if (item.isKit) {
      const kit = kits.find((k) => k.id === item.code || k.name === item.name);
      if (kit) {
        for (const comp of kit.components) {
          const existing = map.get(comp.productCode) || {
            productCode: comp.productCode,
            name: comp.name,
            requiredQty: 0
          };
          existing.requiredQty += comp.quantity * qty;
          map.set(comp.productCode, existing);
        }
      }
    } else {
      const existing = map.get(item.code) || {
        productCode: item.code,
        name: item.name,
        requiredQty: 0
      };
      existing.requiredQty += qty;
      map.set(item.code, existing);
    }
  }

  return map;
}

export interface StockValidationError {
  productCode: string;
  name: string;
  required: number;
  available: number;
}

export function validateCartStock(
  cartItems: SaleItem[],
  products: Product[],
  kits: Kit[]
): {
  isValid: boolean;
  errors: StockValidationError[];
} {
  if (!cartItems || cartItems.length === 0) {
    return { isValid: false, errors: [] };
  }

  // Comprobar que todas las cantidades sean enteros positivos
  for (const it of cartItems) {
    if (!Number.isInteger(it.quantity) || it.quantity <= 0) {
      return {
        isValid: false,
        errors: [{
          productCode: it.code,
          name: it.name,
          required: it.quantity,
          available: 0
        }]
      };
    }
  }

  const requiredMap = calculateRequiredProductQuantities(cartItems, kits);
  const errors: StockValidationError[] = [];

  for (const [code, req] of requiredMap.entries()) {
    const prod = products.find((p) => p.code === code);
    const available = prod ? prod.stock : 0;
    if (req.requiredQty > available) {
      errors.push({
        productCode: code,
        name: prod ? prod.name : req.name,
        required: req.requiredQty,
        available: available
      });
    }
  }

  return {
    isValid: errors.length === 0,
    errors
  };
}

const bogotaTodayStr = getBogotaToday().dateString;
const bogotaYesterdayStr = getBogotaYesterdayDateString();

export const INITIAL_SALES: Sale[] = [
  {
    id: '#V-1048',
    date: bogotaTodayStr,
    time: '03:42 p.m.',
    channel: 'Mostrador',
    items: [
      {
        code: 'CUA-100-CD',
        name: 'Cuaderno Cuadriculado 100h Norma',
        quantity: 2,
        unitPrice: 8500,
        subtotal: 17000
      },
      {
        code: 'KIT-ESC-PRI',
        name: 'Kit Escolar Primaria 2024',
        quantity: 1,
        unitPrice: 45000,
        subtotal: 45000,
        isKit: true,
        components: [
          { name: 'Cuaderno Norma 100h', quantity: 2 },
          { name: 'Caja Colores Doble Punta x12', quantity: 1 },
          { name: 'Colbón Líquido 115g', quantity: 1 },
          { name: 'Regla Metálica 30cm', quantity: 1 },
          { name: 'Tijera Escolar Punta Roma', quantity: 1 }
        ]
      },
      {
        code: 'COL-PEQ-PGA',
        name: 'Colbón Líquido Escolar 115g',
        quantity: 1,
        unitPrice: 3200,
        subtotal: 3200
      }
    ],
    subtotal: 65200,
    total: 65200,
    responsible: 'Carlos M. (Administrador)',
    location: 'Torreón El Roble, Ibagué'
  },
  {
    id: '#V-1047',
    date: bogotaTodayStr,
    time: '11:15 a.m.',
    channel: 'Transferencia',
    items: [
      {
        code: 'KIT-ESC-PRI',
        name: '1 Kit Escolar Primaria 2024',
        quantity: 1,
        unitPrice: 45000,
        subtotal: 45000,
        isKit: true
      }
    ],
    subtotal: 45000,
    total: 45000,
    responsible: 'Carlos M.',
    location: 'Torreón El Roble, Ibagué'
  },
  {
    id: '#V-1046',
    date: bogotaTodayStr,
    time: '10:58 a.m.',
    channel: 'Efectivo',
    items: [
      {
        code: 'CUA-100-CD',
        name: 'Cuaderno Cuadriculado 100h Norma',
        quantity: 2,
        unitPrice: 8500,
        subtotal: 17000
      },
      {
        code: 'REG-MET-30',
        name: 'Regla Metálica 30cm',
        quantity: 1,
        unitPrice: 2400,
        subtotal: 2400
      }
    ],
    subtotal: 20000,
    total: 20000,
    responsible: 'Carlos M.',
    location: 'Torreón El Roble, Ibagué'
  },
  {
    id: '#V-1045',
    date: bogotaTodayStr,
    time: '10:22 a.m.',
    channel: 'Mostrador',
    items: [
      {
        code: 'PLI-CART-BL',
        name: 'Pliego Cartulina Kimberly',
        quantity: 4,
        unitPrice: 2200,
        subtotal: 8800
      },
      {
        code: 'COL-PEQ-PGA',
        name: 'Colbón Líquido Escolar',
        quantity: 1,
        unitPrice: 3200,
        subtotal: 3200
      }
    ],
    subtotal: 12000,
    total: 12000,
    responsible: 'Carlos M.',
    location: 'Torreón El Roble, Ibagué'
  },
  {
    id: '#V-1044',
    date: bogotaYesterdayStr,
    time: '05:10 p.m.',
    channel: 'Efectivo',
    items: [
      {
        code: 'KIT-ART-CRE',
        name: 'Kit Arte y Creatividad',
        quantity: 1,
        unitPrice: 38500,
        subtotal: 38500,
        isKit: true
      }
    ],
    subtotal: 38500,
    total: 38500,
    responsible: 'Carlos M.',
    location: 'Torreón El Roble, Ibagué'
  },
  {
    id: '#V-1043',
    date: bogotaYesterdayStr,
    time: '02:40 p.m.',
    channel: 'Mostrador',
    items: [
      {
        code: 'BOL-KIL-AZ',
        name: 'Bolígrafo Kilométrico 1.0mm',
        quantity: 6,
        unitPrice: 1800,
        subtotal: 10800
      }
    ],
    subtotal: 10800,
    total: 10800,
    responsible: 'Carlos M.',
    location: 'Torreón El Roble, Ibagué'
  },
  {
    id: '#V-1042',
    date: bogotaYesterdayStr,
    time: '10:15 a.m.',
    channel: 'Efectivo',
    items: [
      {
        code: 'TIJ-ESC-PTA',
        name: 'Tijera Escolar Punta Roma',
        quantity: 1,
        unitPrice: 3000,
        subtotal: 3000
      },
      {
        code: 'CAR-BLA-PLI',
        name: 'Carpetas de presentación',
        quantity: 2,
        unitPrice: 3250,
        subtotal: 6500
      }
    ],
    subtotal: 9500,
    total: 9500,
    responsible: 'Carlos M.',
    location: 'Torreón El Roble, Ibagué'
  }
];

export const INITIAL_ADMINS: AdminUser[] = [
  {
    id: 'ADM-01',
    name: 'Carlos Mario Mendoza',
    username: 'carlosm',
    email: 'carlos.mendoza@papelerianico.com',
    role: 'Administrador principal',
    status: 'activo_online',
    lastAccess: 'Sesión actual',
    avatar: 'CM'
  },
  {
    id: 'ADM-02',
    name: 'Andrea Gómez Torres',
    username: 'andreag',
    email: 'andrea.gomez@papelerianico.com',
    role: 'Administrador',
    status: 'activo',
    lastAccess: 'Ayer, 05:40 p.m.',
    avatar: 'AG'
  },
  {
    id: 'ADM-03',
    name: 'Natalia Rodríguez P.',
    username: 'natalia_r',
    email: 'n.rodriguez@papelerianico.com',
    role: 'Administrador',
    status: 'activo',
    lastAccess: '22/10/2024',
    avatar: 'NR'
  }
];

export function formatCOP(value: number): string {
  return `$ ${value.toLocaleString('es-CO')} COP`;
}
