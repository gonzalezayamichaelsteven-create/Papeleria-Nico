# Papelería Nico: revisión de la copia exportada

Fecha: 1 de octubre de 2026.

## Correcciones realizadas

- Las alertas de productos ahora abren Inventario con la búsqueda del código correspondiente. La vista general abre todas las existencias y limpia los filtros anteriores.
- La navegación desde Productos recibe una función obligatoria, en lugar de recurrir a una función vacía cuando falta la conexión.
- Las categorías de Registrar venta ocupan varias filas cuando es necesario. Adhesivos y pegantes y Escolar quedan accesibles sin desplazamiento horizontal oculto.

Archivos modificados: `src/App.tsx`, `src/components/AdminProducts.tsx` y `src/components/AdminPos.tsx`.

## Comprobaciones realizadas

- `pnpm run lint`: correcto (TypeScript, sin errores).
- `pnpm run build`: correcto. Vite muestra una advertencia de compatibilidad futura sobre `__dirname`; no impide generar la aplicación.
- Navegador local: una alerta del marcador MAR-PERM-NG abre su único resultado en Inventario.
- Navegador local: Abrir vista general de Inventario muestra las 12 referencias y la búsqueda vacía.
- Navegador local: Escolar muestra tijeras, regla y kits; Adhesivos y pegantes muestra los tres productos correspondientes. Las categorías se ven completas.
- La dirección solicitada ya aparece en la cabecera y el pie del catálogo exportado.

Estas comprobaciones cubren los cambios indicados; no equivalen a una auditoría completa de las nueve pantallas ni a una prueba de uso simultáneo.

## Estado de los datos

La aplicación usa React y TypeScript. Productos, kits, ventas, movimientos y administradores se inicializan desde `src/data/mockData.ts` y se mantienen en memoria mediante `useState`. No hay conexión a una base de datos ni persistencia local implementada. Al recargar se vuelven a cargar los ejemplos iniciales; las operaciones hechas en la demostración no son registros permanentes.

El acceso de administrador sigue siendo de demostración. La integración posterior debe incorporar autenticación real y permisos antes de usar datos del negocio.

## Modelo propuesto para la siguiente etapa

Este es un borrador adaptado a los campos existentes; todavía no se ha creado ni conectado una base de datos.

| Tabla propuesta | Datos principales |
| --- | --- |
| Categorías | Identificador estable, nombre, descripción e icono |
| Productos | Código único, nombre, categoría, precio COP, existencias, mínimo, descripción e imagen |
| Kits | Identificador, nombre, descripción, edad objetivo, imagen y estado publicado/oculto |
| Componentes de kits | Kit, producto y cantidad necesaria |
| Perfiles de administradores | Usuario autenticado, nombre, rol y estado; las contraseñas corresponden al servicio de autenticación |
| Ventas | Número, fecha y hora, canal, responsable, sede y totales |
| Detalles de venta | Producto o kit, nombre y precio al vender, cantidad y subtotal |
| Componentes vendidos de un kit | Productos y cantidades efectivamente descontados; conservar la composición histórica |
| Movimientos de inventario | Producto, cantidad con signo, tipo, referencia, responsable y fecha/hora |

Reglas que debe conservar la integración:

1. Registrar una venta y descontar todas sus existencias en una única operación de base de datos. Sumar el consumo de productos sueltos y de todos los kits del mismo ticket y rechazar cantidades insuficientes sin guardar una venta parcial.
2. Derivar la disponibilidad de cada kit de sus componentes. Su precio actual usa los precios actuales de los productos; las ventas anteriores conservan sus precios históricos.
3. Usar identificadores de categoría para evitar filtros basados en nombres diferentes. Calcular las cifras del inicio y las alertas a partir de los mismos datos de inventario y ventas.
4. Mantener los kits ocultos fuera del catálogo público. Restringir las operaciones administrativas a usuarios autorizados y exponer públicamente solo lo necesario para consultar el catálogo.
5. Guardar fechas con zona horaria y aplicar los rangos del negocio en America/Bogota.
6. Separar los datos de prueba de los registros reales. Las ventas de ejemplo del ZIP no deben importarse como ventas reales de la papelería.

## Entrega

El ZIP corregido contiene código fuente, el archivo de bloqueo de dependencias y esta nota. No incluye dependencias instaladas, cachés ni archivos compilados. El ZIP original se conserva sin cambios. Estas correcciones solo están en la copia local; no se han enviado a Google AI Studio.
